#######################################################################################
#                                                                                     
#               Tool Name  	:  STRUCTURING-DOI-01-04.pl                                   
#               Version       :  Version 1.0                                          
#               Purpose      :  
#                                
#               Copyrights    :  Integra
#               Developed By  :  (Sathish V.)                       
#               Started On    :  20 - 06 - 2023                                                  
#               Completed On  :                                                   
#               Last Modified :  
#                                                                                     
#######################################################################################

#use strict;
#use warnings;
use Win32;
use File::Copy;
use File::Path;
use File::Basename;
use DBI;
use DBD::mysql;
use LWP::Simple;
#use JSON::Any;
use XML::Simple;
use MongoDB;
use Data::Dumper qw(Dumper);
use HTML::Entities;
use Array::Utils qw(:all);
use List::MoreUtils qw(uniq);
use DateTime;
use Text::Hunspell;
use HTML::Strip;
use DateTime;
use Roman;

use Array::Split qw( split_into );
	
binmode STDOUT, ":utf8";		
			
use Encode qw(encode decode);


my ($filename, $path, $header, $matchtxt, $headinfo, $fpath1)=("","","","","","");
my ($curlcount, $tabcount, $eqcol, $inlinecount, $auxfind, $nonlatex)=(0, 0, 0, 1, 0, 0);
my ($Line, $Variable, $PreMatch, $Curr, $bbox, $fm, $filepath, $fpath, $bbox1, $journaltext, $journaltext1, $snocnt3, $hglt, $bibtext);
my ($Line1, $Variable1, $PreMatch1, $Curr1);
my $ijdata; 
my @jsautr;
my @psautr;
my (@equationcol, @defcollect, @inlinecol, @inlinecol2, @mathconten, @tempmt)=("", "", "", "", "", "");
my %math_remov_ins;
my %tex_link;
my $headcss="";
my $refcontent="";
my $refcontent1="";
my $refcontent2="";



$fpath1 = $ARGV[0];

my $pubname = $ARGV[1];
my $jname = $ARGV[2];
my $functiontype = $ARGV[3];
my $functiontext = $ARGV[4];
my $functiontext2 = $ARGV[4];
my $pubtype = $ARGV[5];


my $outfpath1 = $fpath1;
my $outfpath2 = $fpath1;
my $querypath = $fpath1;

my $dirs = dirname($fpath1);

my $dirs1 = dirname($fpath1);

$dirs1=~s/^(.*?)\\Files\\(.*?)$/$2/sgi;
$dirs1=~s/^(.*?)\/Files\/(.*?)$/$2/sgi;

#print "$dirs1\n\n";
#exit;
my @fnarray="";

my @fildirna = (split/\\/, $dirs);
my $dirnamex = $fildirna[-1];

my $filenamex = basename($fpath1, ".html");

if (-e "$fpath1")
{
}
else
{
	print "File not found";
	exit;
}



$outfpath1=~s/\.html$//g;
$outfpath2=~s/\\document\.html$//g;

undef $/;


my $reftypeb="JOURNAL|BOOK|EDBK|PROC|OTHER|THESIS|WEB|BKSERIES|WKPAPER|SOFT|TECH";

my $serverpath="D\:/Integra/STRUCTURING/ini";
my $exepath="D\:/Integra/STRUCTURING/Exe";


my $rubypath="C\:\\Ruby26\-x64\\bin";


my $filetype="WORD";


my $frontmatter="";

open(ERR, ">:encoding(UTF-8)", "$outfpath1\_Error\.xml")|| die print("Can't open input file!!!");

#open(EX, ">:encoding(UTF-8)", "$outfpath1_GEN\.xml")|| die print("Can't open input file $fpath1.tex!!!");


open(QXX, "<$serverpath/journalinfo\.xml") or die print("$serverpath/journalinfo\.xml NOT FOUND, update the Journal Database!!!");
my $stdata = <QXX>;
close (QXX);	



open(QSS, "<$serverpath/AUTO-EDITING/UNITS\.html") or die print("AUTO-EDITING\/UNITS\.html NOT FOUND, update the Journal Database!!!");
my $units = <QSS>;
close (QSS);

open(CET, "<$serverpath/TEXTENTITIES\.xml") or die print("TEXTENTITIES\.xml NOT FOUND, update the Journal Database!!!");
my $Combine_Entity = <CET>;
close (CET);

open(WYY, "<$serverpath/AUTO-EDITING/$pubtype/$pubname/$jname\.xml");
my $jornalconfig = <WYY>;
close (WYY);

open(HEXA, "<:encoding(UTF-8)", "$serverpath/ENTITIES\-DATA\.xml") or die print("ENTITIES\-DATA\.xml NOT FOUND, update the Journal Database!!!");
my $entities = <HEXA>;
close (HEXA);

open(TXX, "<$serverpath/REFERENCE\-CONFIG/Journals/$pubname/$jname\.ini") or die print("$jname\.ini NOT FOUND, update the Journal Database!!!");
my $bbox4 = <TXX>;
close (TXX);



open(FIN, "<:encoding(UTF-8)", "$fpath1")|| die print("Can't open input file $fpath1!!!");
#open(OUT1, ">$fpath1\.xml")|| die print("$fpath1!!!");
$/="\0";

%Name_NUM=('A'=>1, 'B'=>2, 'C'=>3, 'D'=>4, 'E'=>5, 'F'=>6, 'G'=>7, 'H'=>8, 'I'=>9, 'J'=>10, 'K'=>11, 'L'=>12, 'M'=>13, 'N'=>14, 'O'=>15, 'P'=>16, 'Q'=>17, 'R'=>18, 'S'=>19, 'T'=>20, 'U'=>21, 'V'=>22, 'W'=>23, 'X'=>24, 'Y'=>25, 'Z'=>26);


while(<FIN>)
{
	ELEMENTNUMBERING();
	SPLITJOURNAL();



	FinalCleanup();
	

	
	open(XMLCONTENT, ">:encoding(UTF-8)", "$outfpath1-STEP4\.html")|| die print("Can't open input file !!!");
	print XMLCONTENT "$_";
	close(XMLCONTENT);
	
	exit;
}


sub GETDOINEW
{
   my $text = shift;
   
   #print ERR "$text\n\n\n";
   #exit;

	my $tocrmaintext;
	
	$Line=$text;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"(JOURNAL\d+)\"(.*?)<\/p\[\1\]>/sg)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		my $tocrtext;
		my $id1="$2";

		if($Curr!~/<TempMT/i)
		{
			if ($Curr=~/<span\[(\d+)\] class\=\"JTITLE\">(.*?)<\/span\[\1\]>/si)
			{
				my $jtit="$2";
				$tocrtext .= "<journal\_title match\=\"fuzzy\">$jtit<\/journal_title>";
			}
			if ($Curr=~/<span\[(\d+)\] class\=\"ATITLE\">(.*?)<\/span\[\1\]>/si)
			{
				my $atitle="$2";
				$tocrtext .= "<article\_title match\=\"fuzzy\">$atitle<\/article\_title>";
			}

			if ($Curr=~/<span\[(\d+)\] class\=\"SNM\">(.*?)<\/span\[\1\]>/si)
			{
				my $snm="$2";
				$tocrtext .= "<author search\-all\-authors\=\"true\">$snm<\/author>";
			}
				
			if ($Curr=~/<span\[(\d+)\] class\=\"VOLUME\">(.*?)<\/span\[\1\]>/si)
			{
				my $vol="$2";
				$tocrtext .= "<volume match\=\"fuzzy\">$vol<\/volume>";
			}

			if ($Curr=~/<span\[(\d+)\] class\=\"FPAGE\">(.*?)<\/span\[\1\]>/si)
			{
				my $fpage="$2";
				$tocrtext .= "<first_page>$fpage<\/first_page>";
			}
	
			if ($Curr=~/<span\[(\d+)\] class\=\"YEAR\">(.*?)<\/span\[\1\]>/si)
			{
				my $year="$2";
				$tocrtext .= "<year>$year<\/year>";
			}
			if($tocrtext=~/(<journal\_title|<article\_title match)/si or $tocrtext=~/<author/si)
			{
				$tocrmaintext .= "<query enable\-multiple\-hits\=\"false\" secondary\-query\=\"author\-title\" key\=\"$id1\">$tocrtext<\/query>";
			}

		}	
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$text = $Variable;	
	
	if(defined($tocrmaintext))
	{
		$tocrmaintext=~s/<(i|b|sup|sub)>//g;
		while($tocrmaintext=~/\n\n/g)
		{
			$tocrmaintext=~ s/\n\n/\n/g;
		}
		$tocrmaintext=~ s/^\s*//g;
		$tocrmaintext=~s/\n//g;
		$tocrmaintext=~s/\&amp\;/\%26amp\;/g;
		$tocrmaintext = HTML::Entities::decode($tocrmaintext);

	
		####ATITLE, JTITLE, SNM -  Crossref
	
		my $url = 'http://doi.crossref.org/servlet/query?pid=sathish.velu@integra.co.in&format=unixref&qdata=<?xml version="1.0"?><query_batch version="2.0" xsi:schemaLocation="http://www.crossref.org/qschema/2.0 http://www.crossref.org/qschema/crossref_query_input2.0.xsd" xmlns="http://www.crossref.org/qschema/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><head><email_address>sathish.velu@integra.co.in</email_address><doi_batch_id>01032012</doi_batch_id></head><body>'.$tocrmaintext.'</body></query_batch>';	
		#print ERR "$url\n\n\n";
		
		my $cftext = get $url;

		$Line=$cftext;	
		$Variable="";	
		while($Line =~/<journal\_issue>(.*?)<\/journal\_issue>/sg)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			$Curr=~s/<doi\_data>(.*?)<\/doi\_data>//sg;
			
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$cftext = $Variable;	
		
		$Line=$cftext;	
		$Variable="";	
		while($Line =~/<doi\_record key\=\"(\w+)\"(.*?)<\/doi\_record>/sg)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			my $jid="$1";
			
			
			$Curr=~ s/<citation\_list>(.*?)<\/citation\_list>//sg;
			$Curr=~s/<contributors>/<AUGRP>/gi;
			$Curr=~s/<\/contributors>/<\/AUGRP>/gi;
			$Curr=~s/<person\_name /<AUTHOR /g;
			$Curr=~s/<\/person\_name>/<\/AUTHOR>/g;
			$Curr=~s/<given\_name>/<INITS>/g;
			$Curr=~s/<\/given\_name>/<\/INITS>/g;
			$Curr=~s/<surname>/<SURNAME>/g;
			$Curr=~s/<\/surname>/<\/SURNAME>/g;
			$Curr=~s/<ORCID>(.*?)<\/ORCID>//g;
			
			if($Curr=~/<doi>(.*?)<\/doi>/)
			{
				my $doi="$1";
				#print "$doi\n\n";
				if ($_=~/<p\[(\d+)] class\=\"$jid\">(.*?)<span\[(\d+)\] class\=\"REFDOI\">(.*?)<\/span\[\3\]>(.*?)<\/p\[\1\]>/s)
				{
					#print "$jid\t$doi\n\n";
					$_=~s/<p\[(\d+)] class\=\"$jid\">(.*?)<span\[(\d+)\] class\=\"REFDOI\">(.*?)<\/span\[\3\]>(.*?)<\/p\[\1\]>/<p\[$1] class\=\"$jid\">$2<span\[$3\] class\=\"REFDOI\">$doi<\/span\[$3\]>$5<\/p\[$1\]>/g;
				}	
				elsif ($_=~/<p\[(\d+)] class\=\"$jid\">(.*?)<span\[(\d+)\] class\=\"SEP\">([^<]+)<\/span\[\3\]><\/p\[\1\]>/s)
				{
					$_=~s/<p\[(\d+)] class\=\"$jid\">(.*?)<span\[(\d+)\] class\=\"SEP\">([^<]+)<\/span\[\3\]><\/p\[\1\]>/<p\[$1] class\=\"$jid\">$2<span class\=\"SEP\"> DOI <\/span><span class\=\"REFDOI\">$doi<\/span><span\[$3\] class\=\"SEP\">$4<\/span\[$3\]><\/p\[$1\]>/g;
				}	
				
			}				
			
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$cftext = $Variable;
		
		$_=~s/<span\[(\d+)\] class\=\"SEP\"><\/span\[\1\]><span\[(\d+)\] class\=\"REFDOI\">/<span\[$1\] class\=\"SEP\"> DOI <\/span\[$1\]><span\[$2\] class\=\"REFDOI\">/g;
	

	
	
		while($tocrmaintext=~/\n\n/g)
		{
			$tocrmaintext=~ s/\n\n/\n/g;
		}

	}
	return $_;
}




sub SPLITJOURNAL
{

	my $bibcount=0;
	while($_=~/<p\[(\d+)\] class\=\"JOURNAL\"/g)
	{
		$bibcount++;
		$_=~s/<p\[(\d+)\] class\=\"JOURNAL\"/<p\[$1\] class\=\"JOURNAL$bibcount\"/;
	}
	
	my $datas="$_";

	if ($bibcount >= 6)
	{
		
		my $spbib = ($bibcount)/5;
		
		my $svalue=0;
		if($spbib=~/(\d+)\.(\d+)/g)
		{
			$svalue = $1 + 1;
		}
		else
		{
			$svalue = $spbib;
		}
	
		my @refs;
		while($_=~/(<p\[(\d+)\] class\=\"JOURNAL(\d+)\"(.*?)<\/p\[\2\]>)/sg)
		{
			my $refpara="$1";
			push(@refs, "$refpara");
		}

		my $numberofarrays = $svalue;

		my @arrayrefs = split_into($numberofarrays,@refs);
		
		my $doitext;
		for (my $i=0; $i < $numberofarrays; $i++)
		{
			my $reftext="";
			my $refcontents= (Dumper @arrayrefs[$i]);
			
			my $refstext;
			while($refcontents=~/(<p\[(\d+)\] class\=\"JOURNAL(\d+)\"(.*?)<\/p\[\2\]>)/sg)
			{
				my $refpara="$1";
				$refstext .= "$refpara\n";
			}
			
			
			$doitext .= GETDOINEW($refstext);
			
		}

		while($doitext=~/(<p\[(\d+)\] class\=\"JOURNAL(\d+)\"(.*?)<\/p\[\2\]>)/sgi)
		{
			my $refpara="$1";
			my $refparaid="$3";
			#print "$refparaid\n\n";
			
			$datas=~s/(<p\[(\d+)\] class\=\"JOURNAL$refparaid\"(.*?)<\/p\[\2\]>)/$refpara/si;
		}

		$datas =~ s/<p\[(\d+)\] class\=\"(JOURNAL\d+)\"/<p\[$1\] class\=\"JOURNAL\"/g;
		
		#print ERR "$datas\n";	
		#exit;
		
		$_ = $datas; 	
	}
	else
	{
		my $reftext="";
		while($_=~/(<p\[(\d+)\] class\=\"JOURNAL(\d+)\"(.*?)<\/p\[\2\]>)/sg)
		{
			$reftext .= "$1\n";
		}

		my $doitext = GETDOINEW($reftext);
		while($doitext=~/(<p\[(\d+)\] class\=\"JOURNAL(\d+)\"(.*?)<\/p\[\2\]>)/sgi)
		{
			my $refpara="$1";
			my $refparaid="$3";
			#print "$refparaid\n\n";
			
			$datas=~s/(<p\[(\d+)\] class\=\"JOURNAL$refparaid\"(.*?)<\/p\[\2\]>)/$refpara/si;
		}

		$datas =~ s/<p\[(\d+)\] class\=\"(JOURNAL\d+)\"/<p\[$1\] class\=\"JOURNAL\"/g;
		
		#print ERR "$datas\n";	
		#exit;
		$_ = $datas; 	
	}
}



sub FinalCleanup
{
	

	while($_ =~ m/<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>/sgi)
	{
		$_=~s/<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>/<$1>$3<\/$1>/sgi;
	}
	
	
	$_=~s/<(\w+)\[(\d+)\]/<$1/g;
	$_=~s/<\/(\w+)\[(\d+)\]>/<\/$1>/g;
	$_=~s/\s*<\/p>/<\/p>/g;
	$_=~s/  / /g;
	$_=~s/<divx /<div /g;
	$_=~s/<\/divx>/<\/div>/g;
	$_=~s/<supr>/<sup>/g;
	$_=~s/<\/supr>/<\/sup>/g;

	
	$Line=$_;
	$Variable="";
	while($Line =~/<head>(.*?)<\/head>/sgi)
	{
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		$Curr=~s/\&\#x0027\;/\'/gi;

	$Variable .=$PreMatch .$Curr;
	}
	$Variable .=$Line;
	$_ = $Variable;	
	
}



sub CUT_N_JOIN
{
	my ($data, $element, $class, $rep_identy, $count, $switch, %join_hash) = (shift, shift, shift, shift, shift, shift, @_);
	my $cut_data;
	if ($switch eq 'CUT')
	{
		if($data=~/<\Q$element\E(\[\d+\])[^><]*class="\Q$class\E"[^><]*>.*?<\/\Q$element\E\1>/si)
		{
			$cut_data = $&;
			$data=~s/<\Q$element\E(\[\d+\])[^><]*class="\Q$class\E"[^><]*>.*?<\/\Q$element\E\1>/$rep_identy$count$rep_identy/si;
		}	
		return ($data, $cut_data);
	}
	elsif($switch eq 'JOIN')
	{
		while ($data=~/\Q$rep_identy\E(\d+)\Q$rep_identy\E/sgi)
		{
			my $co = $1;
			foreach my $key (keys %join_hash)
			{
				$data=~s/\Q$rep_identy$co$rep_identy\E/$join_hash{$key}/sgi if($key == $co);
			}
		}
		return ($data);
	}
	else
	{
		print "Invalid Switch $switch!!";
	}
}



sub ELEMENTNUMBERING
{
	
	
	open(ELIST, "<", "$serverpath/elements\.txt") or die print("$serverpath/elements\.txt NOT FOUND!!!");
	my $elements = <ELIST>;
	close (ELIST);

	$_=~s/\&\#x0?2103\;/\&\#x00B0\;C/g;
	$_=~s/<\/i>\.<i>/\./g;
	$_=~s/<(span|strong|sup|sub|sc|monospace)>/<$1 class\=\"dummy\">/g;
	

	$Line=$elements;	
	$Variable="";	
	while($Line =~/(\w+)/g)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		my $e2="$1";
		

		my $strongcount = 0;
		my $brk = 1;
		strongStart:
		if($brk >= 10)	{ print "\nUNexPectedBreak!!! for element - $e2"; print ERR $_; exit; goto BBREAK; }
		$_ =~ s{<$e2\s+([^<>]*>((?:(?!<$e2\s+\b).)*?))<\/$e2>}
				{
					my $strong = $&;
					#print "$strong\n\n";
					$strongcount++;
					$strong =~ s/<$e2\s+([^<>]*>((?:(?!<$e2\s+\b).)*?))<\/$e2>/<$e2\[$strongcount\] $1<\/$e2\[$strongcount\]>/msi;
					$strong;
				}emsgi;
		$brk++;
		goto strongStart if($_ =~ m/<$e2\s+/msi);		
		BBREAK:		
		
		
			
	#$Variable .=$PreMatch .$Curr;	
	}	
	#$Variable .=$Line;	
	#$_ = $Variable;

	
		while($_=~/<span\[(\d+)\] class\=\"dummy\">(.*?)<\/span\[\1\]>/sgi)
		{
			$_=~s/<span\[(\d+)\] class\=\"dummy\">(.*?)<\/span\[\1\]>/$2/sgi;	
		}
		

}

sub MOVE_OUT_QUERY
{
	my $temp = shift;
	my %ref_hash;
	if($temp == 1)
	{
		if($_=~/<div\[(\d+)\] class="references">(.*?)<\/div\[\1\]>/si)
		{
			my $ref_cnt = $2;
			if($ref_cnt=~/<span\[(\d+)\] class="QUERY">/si)
			{
				my $count = 1;
				
				$Line=$ref_cnt;	
				$Variable="";	
				#while($Line =~/<p\[(\d+)\] class=\"ref[^\"]+\">(.*?)<\/p\[\1\]>/sgi)	
				while($Line =~/<p\[(\d+)\] class=\"[^\"]+\">(.*?)<\/p\[\1\]>/sgi)	
				{	
					$PreMatch = $`;
					$Curr = $&;
					$Line = $';
				
					if($Line=~/^(\s*(?:<span\[(\d+)\] class="QUERY">.*?<\/span\[\2\]>\s*)+)/si)
					{
						$ref_hash{$count} = $1;
						$Line=~s/^(\s*(?:<span\[(\d+)\] class="QUERY">.*?<\/span\[\2\]>\s*)+)//si;
					}
					$count++;
				
				$Variable .=$PreMatch .$Curr;	
				}	
				$Variable .=$Line;	
				$ref_cnt = $Variable;	
				
				$ref_cnt=~s/(<\/p\[\d+\]>)\n\s*(<p\b)/$1\n$2/sgi;
				$ref_cnt=~s/(<\/p\[\d+\]>)\s*(<p\b)/$1\n$2/sgi;
				$ref_cnt=~s/><p/>\n<p/si;
		#print $ref_cnt;
				$_=~s/<div\[(\d+)\] class="references">(.*?)<\/div\[\1\]>/<div\[$1\] class="references">$ref_cnt<\/div\[$1\]>/si;
			}
		}

		return %ref_hash;
	}
	else
	{
		$_ =~s/((?:\s*<span\[(\d+)\] class\=\"QUERY\">.*?<\/span\[\2\]>\s*)+)(<\/p\[\d+\]>)/$3$1/sgi;
	}
}


sub MOVE_IN_QUERY
{
	my ($temp, %ref_hash) = (shift, @_);
	
	#print $_;
	
	if($temp == 1)
	{
		if($_=~/<div\[(\d+)\] class="references">(.*?)<\/div\[\1\]>/si)
		{
			my $ref_cnt = $2;
			my $count = 1;
			while($ref_cnt=~/<p class=\"[^\"]+\">((?:(?!<\/p>).)*?)<\/p>/sgi)
			{
				my $ref_while = $&;
				foreach my $key (%ref_hash)
				{
					if($key == $count)
					{
						$ref_while=~s/(<p class=\"[^\"]+\">((?:(?!<\/p>).)*?)<\/p>)/$1\n$ref_hash{$key}/si;
					}
				}
				$count++;
				$ref_while=~s/<(\/)?p\b/<$1Xp/sgi;
				$ref_cnt=~s/<p class=\"[^\"]+\">((?:(?!<\/p>).)*?)<\/p>/$ref_while/si;
			}
			$ref_cnt=~s/<(\/)?Xp\b/<$1p/sgi;
			$ref_cnt=~s/<\/p>\s*<span/<\/p>\n<span/sgi;
			$ref_cnt=~s/<\/(span\[\d+\])>\s*<p/<\/$1>\n<p/sgi;
			$_=~s/<div\[(\d+)\] class="references">(.*?)<\/div\[\1\]>/<div\[$1\] class="references">$ref_cnt<\/div\[$1\]>/si;
		}
	}
	else
	{
		$_ =~s/(<\/p\[\d+\]>)((?:\s*<span\[(\d+)\] class\=\"QUERY\">.*?<\/span\[\3\]>\s*)+)/$2$1/sgi;	
	}
}

sub CHAR2ENTITY
{
	while($_ =~ m/[\x{A0}-\x{FFDC}]/g)
	{
		my $findchar = $&;
		my $ent = uc(sprintf("%x", ord($findchar)));

		if(defined $ent)
		{
			if(length($ent) == 1)
			{
				$ent = "&#x0000$ent;";
			}
			elsif(length($ent) == 2)
			{
				$ent = "&#x000$ent;";
			}
			elsif(length($ent) == 3)
			{
				$ent = "&#x00$ent;";
			}
			elsif(length($ent) == 4)
			{
				$ent = "&#x0$ent;";
			}
			$_ =~ s/$findchar/$ent/g;
		}
		else
		{
			$_ =~ s/$findchar/<SRN\/>/;
		}
	}


	$_ =~ s/<NOTCONVERTED>([\&\#\w\;]+)<\/NOTCONVERTED>/$1/gi;
	$_ =~ s{<NOTCONVERTED>\\x(\w+)<\/NOTCONVERTED>}
	{
		my $NTent = "&#x0000" . $1;
		$NTent =~ s/^\&\#x0+([a-z0-9]{4})$/<NOTCONVERTED>\&\#x$1\;<\/NOTCONVERTED>/gi;
		$NTent;
	}iseg;

	$_ =~ s{<NOTCONVERTED>((\\x|\w)+)<\/NOTCONVERTED>}
	{
		my $test = $1;
		my @NTent = map {$_ =~ s/\\x(\w+)/\&\#x0000$1/i;$_ =~ s/^\&\#x0+([a-z0-9]{4})$/<NOTCONVERTED>\&\#x$1\;<\/NOTCONVERTED>/gi; $_} split(/(\\x\w+)/i, $test);
		my $finjoin = join "", @NTent;
		$finjoin;
	}iseg;

	$_ =~ s{<NOTCONVERTED>(&[\#\w]+;| )+<\/NOTCONVERTED>}
		{
			my $notconv = $&;
			$notconv =~ s/<\/?NOTCONVERTED>//gi;
			$notconv;
		}gie;

	$_ =~ s{<NOTCONVERTED>([^<>]+)<\/NOTCONVERTED>}
	{
		my $notc = $1;
		$notc =~ s{.}
			{
				my $findchar = $&;
				my $ent = uc(sprintf("%x", ord($findchar)));
				#print "$ent\n";
				if(defined $ent)
				{
					if(length($ent) == 1)
					{
						$ent = "&#x0000$ent;";
					}
					elsif(length($ent) == 2)
					{
						$ent = "&#x000$ent;";
					}
					elsif(length($ent) == 3)
					{
						$ent = "&#x00$ent;";
					}
					elsif(length($ent) == 4)
					{
						$ent = "&#x0$ent;";
					}
				}
				$ent;
			}eg;
		$notc;
	}iseg;
	
}


