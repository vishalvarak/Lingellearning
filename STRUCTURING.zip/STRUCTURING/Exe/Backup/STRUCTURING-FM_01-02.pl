#######################################################################################
#                                                                                     
#               Tool Name  	:  STRUCTURING-FM-01-02.pl                                   
#               Version       :  Version 1.0                                          
#               Purpose      :  
#                                
#               Copyrights    :  Integra
#               Developed By  :  (Sathish V.)                       
#               Started On    :  10 - 05 - 2023                                                  
#               Completed On  :                                                   
#               Last Modified :  
#                                                                                     
#######################################################################################

#use strict;
#use warnings;
use Win32;
use File::Copy;
use File::Path;
use File::Basename;
use DBI;
use DBD::mysql;
use LWP::Simple;
#use JSON::Any;
use XML::Simple;
use MongoDB;
use Data::Dumper qw(Dumper);
use HTML::Entities;
use Array::Utils qw(:all);
use List::MoreUtils qw(uniq);
use DateTime;
use Text::Hunspell;
use HTML::Strip;
use DateTime;
use Roman;

use Array::Split qw( split_into );
	
binmode STDOUT, ":utf8";		
			
use Encode qw(encode decode);


my ($filename, $path, $header, $matchtxt, $headinfo, $fpath1)=("","","","","","");
my ($curlcount, $tabcount, $eqcol, $inlinecount, $auxfind, $nonlatex)=(0, 0, 0, 1, 0, 0);
my ($Line, $Variable, $PreMatch, $Curr, $bbox, $fm, $filepath, $fpath, $bbox1, $journaltext, $journaltext1, $snocnt3, $hglt, $bibtext);
my ($Line1, $Variable1, $PreMatch1, $Curr1);
my $ijdata; 
my @jsautr;
my @psautr;
my (@equationcol, @defcollect, @inlinecol, @inlinecol2, @mathconten, @tempmt)=("", "", "", "", "", "");
my %math_remov_ins;
my %tex_link;
my %query_content;
my $headcss="";

$fpath1 = $ARGV[0];

my $pubname = $ARGV[1];
my $jname = $ARGV[2];
my $functiontype = $ARGV[3];
my $functiontext = $ARGV[4];
my $functiontext2 = $ARGV[4];
my $pubtype = $ARGV[5];



my $outfpath1 = $fpath1;
my $outfpath2 = $fpath1;
my $querypath = $fpath1;

my $dirs = dirname($fpath1);

my $dirs1 = dirname($fpath1);

$dirs1=~s/^(.*?)\\Files\\(.*?)$/$2/sgi;
$dirs1=~s/^(.*?)\/Files\/(.*?)$/$2/sgi;

#print "$dirs1\n\n";
#exit;
my @fnarray="";

my @fildirna = (split/\\/, $dirs);
my $dirnamex = $fildirna[-1];

my $filenamex = basename($fpath1, ".html");

if (-e "$fpath1")
{
}
else
{
	print "File not found";
	exit;
}


$outfpath1=~s/\.html$//g;
$outfpath2=~s/\\document\.html$//g;

undef $/;


my $reftypeb="JRNL|BOOK|EDBK|PROC|OTHER|THESIS|WEB|BKSERIES|WKPAPER|SOFT|TECH";

my $serverpath="D\:/Integra/STRUCTURING/ini";
my $exepath="D\:/Integra/STRUCTURING/Exe";


my $rubypath="C\:\\Ruby26\-x64\\bin";


my $filetype="WORD";


my $frontmatter="";

open(ERR, ">:encoding(UTF-8)", "$outfpath1\_Error\.xml")|| warn print("Can't open input file!!!");

#open(EX, ">:encoding(UTF-8)", "$outfpath1_GEN\.xml")|| die print("Can't open input file $fpath1.tex!!!");


open(QXX, "<$serverpath/journalinfo\.xml") or warn print("$serverpath/journalinfo\.xml NOT FOUND, update the Journal Database!!!");
my $stdata = <QXX>;
close (QXX);	


open(QSS, "<$serverpath/AUTO-EDITING/UNITS\.html") or warn print("AUTO-EDITING\/UNITS\.html NOT FOUND, update the Journal Database!!!");
my $units = <QSS>;
close (QSS);

open(CET, "<$serverpath/TEXTENTITIES\.xml") or warn print("TEXTENTITIES\.xml NOT FOUND, update the Journal Database!!!");
my $Combine_Entity = <CET>;
close (CET);

open(WYY, "<$serverpath/AUTO-EDITING/$pubtype/$pubname/$jname\.xml");
my $jornalconfig = <WYY>;
close (WYY);

open(HEXA, "<:encoding(UTF-8)", "$serverpath/ENTITIES\-DATA\.xml") or warn print("ENTITIES\-DATA\.xml NOT FOUND, update the Journal Database!!!");
my $entities = <HEXA>;
close (HEXA);


open(FIN, "<:encoding(UTF-8)", "$fpath1")|| warn print("Can't open input file $fpath1!!!");
#open(OUT1, ">$fpath1\.xml")|| die print("$fpath1!!!");
$/="\0";

%Name_NUM=('A'=>1, 'B'=>2, 'C'=>3, 'D'=>4, 'E'=>5, 'F'=>6, 'G'=>7, 'H'=>8, 'I'=>9, 'J'=>10, 'K'=>11, 'L'=>12, 'M'=>13, 'N'=>14, 'O'=>15, 'P'=>16, 'Q'=>17, 'R'=>18, 'S'=>19, 'T'=>20, 'U'=>21, 'V'=>22, 'W'=>23, 'X'=>24, 'Y'=>25, 'Z'=>26);

while(<FIN>)
{

	if ($functiontype == 2)
	{
		$_=~s/<(strong|sup|sub|sc|monospace|b|i)>/<$1 class\=\"dummy\">/g;

		ELEMENTNUMBERING();
		PLACEMENT();
		my $FMDATA="$_";
		ENDNOTE2REF();
		CITSTYLE();	

		if($_=~/<div\[(\d+)\] class\=\"front\">(.*?)<\/div\[\1\]>/si)
		{
			$frontmatter="$2";
				$frontmatter=~s/(<\/p\[\d+\]>)((?:\s*<span(\[\d+\]) class="QUERY">.*?<\/span\3>\s*)+)/$2$1/sgi;
			FMSTYLING();
				$frontmatter=~s/((?:\s*<span(\[\d+\]) class="QUERY">.*?<\/span\2>\s*)+)(<\/p\[\d+\]>)/$3$1/sgi;
			FMAUTHORGROUPING();
			FMSTYLING2();
			FMKEYWORDSET();		
			FMAFFILIATION();
			FMAUAFF();
			FMFINALCLEANUP();
			FMFINALCLEANUP2();
		}


		CHAR2ENTITY();
		FOOTNOTES();
		TABLESNOTES();
		RUNNINGHEAD();
		
		####
		TESTSUB();
		####
		FinalCleanup();
		
		open(XMLCONTENT, ">:encoding(UTF-8)", "$outfpath1-STEP2\.html")|| die print("Can't open input file");
		print XMLCONTENT "$_";
		close(XMLCONTENT);

		$FMDATA=~s/<div\[(\d+)\] class\=\"(bodymatter|back|floats)\">(.*?)<\/div\[\1\]>//sgi;
		$_= "$FMDATA";
		FinalCleanup();
		
		open(XMLCONTENT, ">:encoding(UTF-8)", "$outfpath1-FM\.html")|| die print("Can't open input file");
		print XMLCONTENT "$_";
		close(XMLCONTENT);
		exit;
	
	}	
	exit;
}

#####################
sub ELEMENTNUMBERING
{
	
	
	open(ELIST, "<", "$serverpath/elements\.txt") or die print("$serverpath/elements\.txt NOT FOUND!!!");
	my $elements = <ELIST>;
	close (ELIST);

	$_=~s/\&\#x0?2103\;/\&\#x00B0\;C/g;
	$_=~s/<\/i>\.<i>/\./g;
	$_=~s/<(span|strong|sup|sub|sc|monospace)>/<$1 class\=\"dummy\">/g;
	

	$Line=$elements;	
	$Variable="";	
	while($Line =~/(\w+)/g)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		my $e2="$1";
		

		my $strongcount = 0;
		my $brk = 1;
		strongStart:
		if($brk >= 10)	{ print "\nUNexPectedBreak!!! for element - $e2"; print ERR $_; exit; goto BBREAK; }
		$_ =~ s{<$e2\s+([^<>]*>((?:(?!<$e2\s+\b).)*?))<\/$e2>}
				{
					my $strong = $&;
					#print "$strong\n\n";
					$strongcount++;
					$strong =~ s/<$e2\s+([^<>]*>((?:(?!<$e2\s+\b).)*?))<\/$e2>/<$e2\[$strongcount\] $1<\/$e2\[$strongcount\]>/msi;
					$strong;
				}emsgi;
		$brk++;
		goto strongStart if($_ =~ m/<$e2\s+/msi);		
		BBREAK:		
		
		
			
	#$Variable .=$PreMatch .$Curr;	
	}	
	#$Variable .=$Line;	
	#$_ = $Variable;

	
		while($_=~/<span\[(\d+)\] class\=\"dummy\">(.*?)<\/span\[\1\]>/sgi)
		{
			$_=~s/<span\[(\d+)\] class\=\"dummy\">(.*?)<\/span\[\1\]>/$2/sgi;	
		}
		

}

sub PLACEMENT
{
	
	my $appendix=$& if($_=~/<div\[(\d+)\] class=\"APP\-GROUP\" data\-id="appg\d+">(.*?)<\/div\[\1\]>/sgi);
	my $reference=$& if($_=~/<div\[(\d+)\] class=\"references\">(.*?)<\/div\[\1\]>/sgi);
		
	if($jornalconfig =~m/<appendix>\s*<order>References|Appendix<\/order>\s*<\/appendix>/i)
	{
		$_=~s/\Q$appendix\E\s*//sgi;
		$_=~s/\Q$reference\E/$reference\n$appendix/sgi;
	}
	elsif($jornalconfig =~m/<appendix>\s*<order>Appendix|References<\/order>\s*<\/appendix>/i)
	{
		$_=~s/\Q$reference\E\s*//sgi;
		$_=~s/\Q$appendix\E/$appendix\n$reference/sgi;
	}
}

sub ENDNOTE2REF
{
	if($_ =~/<div\[(\d+)\] class\=\"references\">\s*<\/div\[\1\]>/si)
	{
		my $refs="";
		$Line=$_;	
		$Variable="";	
		while($Line =~/<div\[(\d+)\] class\=\"endnote\" id\=\"endnote(\d+)\">(.*?)<\/div\[\1\]>/s)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			my $ref="$3";
			my $refid="$2";
			
			$ref=~s/(\-)<\/p\[\d+\]>\s*<p\[(\d+)] class\=\"([^\"]+)\">/$1/sgi;
			$ref=~s/<\/p\[\d+\]>\s*<p\[(\d+)] class\=\"([^\"]+)\">//sgi;
			
			$ref=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(.*?)<\/p\[(\d+)]>/<p\[$1\] class\=\"$2\">$3<\/p\[$1]>/sgi;
			
			$ref=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*/<p\[$1\] class\=\"$2\">$refid /gi;
			
			
			
			$refs.="$ref";
			
			$_=~s/<div\[(\d+)\] class\=\"endnote\" id\=\"endnote$refid\">(.*?)<\/div\[(\d+)\]>//sgi;
			#<a class="REFLINK" href="#bib1">
			$_=~s/<a\[(\d+)\] class\=\"endnote\" href\=\"\#endnote$refid\">/<a\[$1\] class\=\"REFLINK\" href\=\"\#bib$refid\">/gi;

	
			
		$Variable .=$PreMatch .$Curr;	
		}	
		#$Variable .=$Line;	
		#$_ = $Variable;
		
		$_=~s/<div\[(\d+)\] class\=\"references\">\s*<\/div\[\1\]>/<div\[$1\] class\=\"references\">$refs<\/div\[\1\]>/si;
		
		#print ERR $_;
		#exit;		
	}

}

sub CITSTYLE
{

	$Line=$_;	
	$Variable="";	
	while($Line =~/<a\[(\d+)\] class\=\"FIGLINK\" href\=\"\#fig\-(\d+)\">(.*?)<\/a\[\1\]>/gi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';		
		my $text="$3";

		$Curr=~s/<a\[(\d+)\] class\=\"FIGLINK\" href\=\"\#fig\-(\d+)\">(.*?)<\/a\[\1\]>/<a\[$1\] class\=\"FIGLINK\" href\=\"\#fig\-$2\">$text<\/a\[$1\]>/i;
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;

		
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<a\[(\d+)\] class\=\"TABLINK\" href\=\"\#table\-(\d+)\">(.*?)<\/a\[\1\]>/gi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		my $text="$3";

		$Curr=~s/<a\[(\d+)\] class\=\"TABLINK\" href\=\"\#table\-(\d+)\">(.*?)<\/a\[\1\]>/<a\[$1\] class\=\"TABLINK\" href\=\"\#table\-$2\">$text<\/a\[$1\]>/i;
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	
	
	$_=~s/<del>/<del class\=\"crins\">/g;
	$_=~s/<ins>/<ins class\=\"crins\">/g;
	


}

sub FMSTYLING
{
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<ol\[(\d+)\] type\=\"([^\"]+)\">(.*?)<\/ol\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		my $olcounter=0;
		while($Curr=~/<li>/g)
		{
			$olcounter++;
			$Curr=~s/<li>/<p\[00\] class\=\"normal\"><sup\[00\] class\=\"dummy\">$olcounter<\/sup\[00\]>/i;
		}	
		
		
		$Curr=~s/<\/li>/<\/p\[00\]>/gi;
		$Curr=~s/<ol\[(\d+)\] type\=\"([^\"]+)\">//gi;
		$Curr=~s/<\/ol\[(\d+)\]>//gi;
		#print ERR "$Curr\n";
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;


	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"normal\">/gi;
	$frontmatter=~s/\, \, /\, /gi;
	
	
	$frontmatter=~s/<p class\=\"([^\"]+)\"><i>Abstract<\/i><\/p>/<p class\=\"$1\"><b>Abstract<\/b><\/p>/sgi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"normal\"><b\[(\d+)\] class\=\"dummy\">\[Abstract\]<\/b\[\2\]><\/p\[\1\]>/<p\[$1\] class\=\"normal\"><b\[$2\] class\=\"dummy\">Abstract<\/b\[$2\]><\/p\[$1\]>/sgi;
	

	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(Short title\:?|Shortenened Title|Running head|Running title|Brief Title)(.*?)<\/p\[\1\]>(.*?)$/$5\n<p\[$1\] class\=\"RunningHead\">$3$4<\/p\[$1\]>/si;
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)\] class\=\"dummy\">(Short title\:?|Shortenened Title|Running head|Running title|Brief Title)(.*?)<\/p\[\1\]>(.*?)$/$6\n<p\[$1\] class\=\"RunningHead\"><b\[$3\] class\=\"dummy\">$4$5<\/p\[$1\]>/si;
	
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((.*?) (et al|subtitle)(.*?))<\/p\[\1\]>/<p\[$1\] class\=\"RunningHead\">$3<\/p\[$1\]>/gi;
	#print ERR "$frontmatter";
	#exit;


	$frontmatter=~s/<p\[(\d+)\] class\=\"normal\"><b\[(\d+)\] class\=\"dummy\">ABSTRACT\: <i\[(\d+)\]/<p\[0000\] class\=\"normal\"><b\[000\] class\=\"dummy\">Abstract<\/b\[000\]><\/p\[0000\]>\n<p\[$1\] class\=\"normal\"><b\[$2\] class\=\"dummy\"><i\[$3\]/gi;
	
	$frontmatter=~s/(<p\[\d+\] class\=\")normal\">(\s*<b\[\d+\] class\=\"dummy\">Funding:)/$1funding\-group\" data\-element\=\"funding\-group\">$2/si;
	
	my $unwantedpara="Author List\|Authors\|Author Affiliations?\|Affiliations?\|Title page\|Number of references\|Number of figures\|Number of tables\|Title\|Author Details\|Institutions and Affiliations|Author affiliations|Author contact";
		
	
	$frontmatter=~s/<p\[(\d+)\] class\=\"normal\"><b\[(\d+)\] class\=\"dummy\">($unwantedpara)\:?<\/b\[\2\]>\:?( ?(\d+)?)?<\/p\[\1\]>\s*//sgi;	
	$frontmatter=~s/<p\[(\d+)\] class\=\"normal\"><b\[(\d+)\] class\=\"dummy\"><i\[(\d+)\] class\=\"dummy\">($unwantedpara)\:?<\/i\[(\d+)\]><\/b\[(\d+)\]>\:?( ?(\d+)?)?<\/p\[\1\]>\s*//sgi;	

	$frontmatter=~s/<p\[(\d+)\] class\=\"normal\"><i\[(\d+)\] class\=\"dummy\">($unwantedpara)\:?<\/i\[\2\]>( ?(\d+)?)?<\/p\[\1\]>\s*//sgi;	
	$frontmatter=~s/<p\[(\d+)\] class\=\"normal\">($unwantedpara)\:? ?( ?(\d+)?)?<\/p\[\1\]>\s*//sgi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"normal\"><[b|i]\[(\d+)\] class\=\"dummy\">Word count\:? ?( words\.?)?<\/[b|i]\[\2\]>\:?\.? ?(\d+)<\/p\[\1\]>\s*//gi;	
	$frontmatter=~s/<p\[(\d+)\] class\=\"normal\">\(?Word counts?\:? ? ?(\d+)( words\.?)?\)?<\/p\[\1\]>\s*//gi;	
	$frontmatter=~s/<b\[\d+\] class\=\"dummy\"><\/b\[\d+\]>//gi;


	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\"> ?<b\[(\d+)\] class\=\"dummy\">Authors ?\: ?/<p\[$1\] class\=\"PAuthorGroup\"><b\[$3\] class\=\"dummy\">/si;
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)\] class\=\"dummy\">Affiliations? ?\: ?/<p\[$1\] class\=\"Affiliation\"><b\[$3\] class\=\"dummy\">/si;

	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\"> ?<b\[(\d+)\] class\=\"dummy\">Authors ?\: ?/<p\[$1\] class\=\"PAuthorGroup\"><b\[$3\] class\=\"dummy\">/si;
	$frontmatter=~s/<p\[(\d+)\] class\=\"normal\">\s*<b\[\d+\] class\=\"dummy\"><i\[\d+\] class\=\"dummy\">(Title|Authors|Affiliation) ?\:?<\/i\[\d+\]><\/b\[\d+\]>\s*/<p\[$1\] class\=\"normal\">/gi; 
	
	
	$frontmatter=~s/<p\[(\d+)\] class\=\"normal\"><b\[(\d+)\] class\=\"dummy\">(TITLE)\:? ?<\/b\[\2\]>\:? ?/<p\[$1\] class\=\"normal\">/gi; 

	
	$frontmatter=~s/<p class\=\"normal\"><b>ABSTRACT\: <i>//gi;
	
	$frontmatter=~s/<i\[(\d+)\] class\=\"dummy\">\.<\/i\[\1\]>/\./ig;

	$frontmatter=~s/<p\[(\d+)\] class\=\"RunningHead\">(.*?)<\/p\[\1\]>\s*(.*?)$/$3\n<p\[$1\] class\=\"RunningHead\">$2<\/p\[$1\]>/si;
	
	#print ERR "$frontmatter";
	#exit;

	if($frontmatter=~/^\s*<p\[(\d+)\] class\=\"([^\"]+)\">((<(b|i)\[(\d+)\] class\=\"dummy\">)?(COMMENTARY|Research Article|Review Article|Discussion|Methodologies or Methods|Reports?|Letters|Letter to the Editor|Case Study|Case Studies|Original Research|Research|Book Review|Data( Paper)?|Educational( Paper)?|Short Communication|Theory( Paper)?|Case Study|Review( Paper)?|Original( Paper)?|Original Article|Article|Standard( Paper)?|(The )?Research( Paper)?|(The )?Methods( Paper)?|Experimental( Paper)?|(The )?Review( Paper)?|Literature Review|Systematic Review|Overview( Paper)?|Survey( Paper)?|Meta\-Analysis|(The )?Short Communication|Letters|Rapid Communication|Brief Communication|Short Reports|Brief( Clinical)? Reports?|Micro Article|Research Note|(The )?Discussion( Paper)?|Perspective( Paper)?|Hypothesis( Paper)?|Opinion( Paper)?|Commentary|(The )?Data( Paper)?|Resource( Paper)?|(The )?Theory( Paper)?|(The )?Case Study|Clinical Case Studies|Clinical Trials|Case Report|(The )?Educational( Paper)?|Tutorial( Paper)?|How\-to\-Paper|Original Study|Concise communication|Cardiology in the Young Manuscript|Research brief|Regular Paper|Paper|Chapter (\d+))(<\/(b|i)\[(\d+)\]>)?)<\/p\[\1\]>/si)
	{
		$frontmatter=~s/^\s*<p\[(\d+)\] class\=\"([^\"]+)\">(.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"Supertitle\">$3<\/p\[$1\]>\n<p\[$4\] class\=\"ArticleTitleHead\" data-element\=\"article\-title\">/sgi;
	}
	elsif($frontmatter=~/^\s*<p\[(\d+)\] class\=\"([^\"]+)\">((<(b|i)\[(\d+)\] class\=\"dummy\">)?(Short title|Shortenened Title|Running head|Short running title|Running title))/si)
	{
		$frontmatter=~s/^\s*<p\[(\d+)\] class\=\"([^\"]+)\">(.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\">/<xp\[$1\] class\=\"RunningHead\">$3<\/xp\[$1\]>\n<p\[$4\] class\=\"ArticleTitleHead\" data-element\=\"article\-title\">/sgi;
	}
	elsif($frontmatter=~/^\s*<p\[(\d+)\] class\=\"([^\"]+)\">((<(b|i)\[(\d+)\] class\=\"dummy\">)?(Article Type))/si)
	{
		$frontmatter=~s/^\s*<p\[(\d+)\] class\=\"([^\"]+)\">(.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"Supertitle\">$3<\/p\[$1\]>\n<p\[$4\] class\=\"ArticleTitleHead\" data-element\=\"article\-title\">/sgi;
	}
	else
	{
		$frontmatter=~s/^\s*<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"ArticleTitleHead\" data-element\=\"article\-title\">/g;
	}
	#$frontmatter=~s/^\s*<p\[(\d+)\] class\=\"ArticleTitleHead\" data-element\=\"article\-title\">(<b class\=\"dummy\">)?(Research Article|Research article|Case Report|Case report|Editorial|Original Article|Original article|Original paper|Review Article|Review article|Essay|Commentary|Obituary|Award|Article|New Methods)(<\/b>)?<\/p\[\1\]>\s*\n*<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"SuperTitle\">$3<\/p\[$1\]>\n<p\[$5\] class\=\"ArticleTitleHead\" data-element\=\"article\-title\">/sgi;
	#print ERR "$frontmatter";
	#exit;

	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)">(Authors|Affiliations)\.?\:?<\/p\[\1\]>//g;
	
	

	$frontmatter=~s/<sup\[(\d+)\] class\=\"dummy\">\_\_\_\_.*?\s*<\/sup\[\1\]>//ig;
	$frontmatter=~s/\,([A-Z])([a-z])/\, $1$2/g;
	
	
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(Prof\. ?|Ms. ?)/<p\[$1\] class\=\"PAuthorGroup\">$3/gi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><\/p\[\1\]>//sgi;
	$frontmatter=~s/<i\[(\d+)\] class\=\"dummy\">(\d+)<\/i\[\1\]>/$2/gi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(Short title\:?|Shortenened Title|Running head|Running title)/<p\[$1\] class\=\"RunningHead\">$3/gi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)\] class\=\"dummy\">(Short title\:?|Shortenened Title|Running head|Running title)/<p\[$1\] class\=\"RunningHead\"><b\[$3\] class\=\"dummy\">$4/gi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(Submitted date)/<p\[$1\] class\=\"REC-DATE\">$3/gi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(Accepted date)/<p\[$1\] class\=\"ACC-DATE\">$3/gi;
	
	
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(<sup\[(\d+)\] class\=\"dummy\">\*<\/sup\[19\]>Current address)/<p\[$1\] xclass\=\"AUTHORFOOTNOTE\">$3/gi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(<sup\[(\d+)\] class\=\"dummy\">\&\#x0?002A\;<\/sup\[\4\]>)/<p\[$1\] xclass\=\"AUTHORFOOTNOTE\">$3/gi;
	
	$frontmatter=~s/<p\[(\d+)\] class\=\"normal\">\s*<b\[\d+\] class\=\"dummy\"><i\[\d+\] class\=\"dummy\">Keywords ?\:?<\/i\[\d+\]><\/b\[\d+\]><\/p\[\1\]>/<p\[$1\] class\=\"normal\">Keywords\:<\/p\[$1\]>/gi;

	
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((<(b|i)\[(\d+)\] class\=\"dummy\">)?Received\:)/<p\[$1\] class\=\"ArticleHistory\">$3/gi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((<(b|i)\[(\d+)\] class\=\"dummy\">)?(DOI|DOI ?NUMBER)\:)/<p\[$1\] class\=\"ArticleDOI\">$3/gi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((<(b|i)\[(\d+)\] class\=\"dummy\">)?(Cite this article))/<p\[$1\] class\=\"CITEARTICLE\">$3/gi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((<(b|i)\[(\d+)\] class\=\"dummy\">)?(\&\#x000A9\; Copyright))/<p\[$1\] class\=\"Copyright\">$3/gi;


	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"(ArticleHistory|ArticleDOI|CITEARTICLE|Copyright)\">(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/<i\[(\d+)\] class\=\"dummy\">//gi;	
		$Curr=~s/<\/i\[(\d+)\]>//gi;	
		$Curr=~s/<i>//gi;	
		$Curr=~s/<\/i>//gi;
		$Curr=~s/<p\[(\d+)\] class\=\"(CITEARTICLE)\">(Cite this article as\:)/<p\[$1\] class\=\"$2\"><span\[000\] class\=\"citeinline\">$3<\/span\[000\]>/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"ArticleDOI\">DOI\: (.*?)<\/p\[\1\]>/<p\[$1\] class\=\"ArticleDOI\"><DOITITLE>DOI\:<\/DOITITLE> <ADOINUMBER>$2<\/ADOINUMBER><\/p\[\1\]>/gi;
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;
	
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"(ArticleHistory)\">(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/Received\: (January|February|March|April|May|June|July|August|September|October|November|December) (\d+)\, (\d{4})/<span\[0000\] class\=\"RECD\-DATE\"><RECD\-month>$1<\/RECD\-month> <RECD\-day>$2<\/RECD\-day>\, <RECD\-year>$3<\/RECD\-year><\/span\[0000\]>/gi;
		
		$Curr=~s/Accepted\: (January|February|March|April|May|June|July|August|September|October|November|December) (\d+)\, (\d{4})/<span\[0000\] class\=\"ACC-DATE\"><ACC\-month>$1<\/ACC\-month> <ACC\-day>$2<\/ACC\-day>\, <ACC\-year>$3<\/ACC\-year><\/span\[0000\]>/gi;	
		
		$Curr=~s/Available online date\: (January|February|March|April|May|June|July|August|September|October|November|December) (\d+)\, (\d{4})/<span\[0000\] class\=\"ONL-DATE\"><ONL\-month>$1<\/ONL\-month> <ONL\-day>$2<\/ONL\-day>\, <ONL\-year>$3<\/ONL\-year><\/span\[0000\]>/gi;	
				
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;
	
	
	$frontmatter=~s/<p\[(\d+)\] class\=\"heading(\w+)\">/<p\[$1\] class\=\"normal\">/gi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*/<p\[$1\] class\=\"$2\">/g;
	
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<sup\[(\d+)\] class\=\"dummy\">([a-z],?)+/ig)
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		my $id1="$1";
		
		$Curr =~s/\,/<\/sup\[$id1\]><sup\[$id1\] class\=\"dummy\">/g;
		$Curr =~s/$/<\/sup\[$id1\]><sup\[$id1\] class\=\"dummy\">/g;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;		

	$frontmatter=~s/<sup\[(\d+)\] class\=\"dummy\">(<i\[\d+\] class\=\"dummy\">)?a(<\/i\[\d+\]>)?<\/sup\[\1\]>/<sup\[$1\] class\=\"dummy\">1<\/sup\[$1\]>/sgi;
	$frontmatter=~s/<sup\[(\d+)\] class\=\"dummy\">(<i\[\d+\] class\=\"dummy\">)?b(<\/i\[\d+\]>)?<\/sup\[\1\]>/<sup\[$1\] class\=\"dummy\">2<\/sup\[$1\]>/sgi;
	$frontmatter=~s/<sup\[(\d+)\] class\=\"dummy\">(<i\[\d+\] class\=\"dummy\">)?c(<\/i\[\d+\]>)?<\/sup\[\1\]>/<sup\[$1\] class\=\"dummy\">3<\/sup\[$1\]>/sgi;
	$frontmatter=~s/<sup\[(\d+)\] class\=\"dummy\">(<i\[\d+\] class\=\"dummy\">)?d(<\/i\[\d+\]>)?<\/sup\[\1\]>/<sup\[$1\] class\=\"dummy\">4<\/sup\[$1\]>/sgi;
	$frontmatter=~s/<sup\[(\d+)\] class\=\"dummy\">(<i\[\d+\] class\=\"dummy\">)?e(<\/i\[\d+\]>)?<\/sup\[\1\]>/<sup\[$1\] class\=\"dummy\">5<\/sup\[$1\]>/sgi;
	$frontmatter=~s/<sup\[(\d+)\] class\=\"dummy\">(<i\[\d+\] class\=\"dummy\">)?f(<\/i\[\d+\]>)?<\/sup\[\1\]>/<sup\[$1\] class\=\"dummy\">6<\/sup\[$1\]>/sgi;
	$frontmatter=~s/<sup\[(\d+)\] class\=\"dummy\">(<i\[\d+\] class\=\"dummy\">)?g(<\/i\[\d+\]>)?<\/sup\[\1\]>/<sup\[$1\] class\=\"dummy\">7<\/sup\[$1\]>/sgi;
	$frontmatter=~s/<sup\[(\d+)\] class\=\"dummy\">(<i\[\d+\] class\=\"dummy\">)?h(<\/i\[\d+\]>)?<\/sup\[\1\]>/<sup\[$1\] class\=\"dummy\">8<\/sup\[$1\]>/sgi;
	$frontmatter=~s/<sup\[(\d+)\] class\=\"dummy\">(<i\[\d+\] class\=\"dummy\">)?i(<\/i\[\d+\]>)?<\/sup\[\1\]>/<sup\[$1\] class\=\"dummy\">9<\/sup\[$1\]>/sgi;
	$frontmatter=~s/<sup\[(\d+)\] class\=\"dummy\">(<i\[\d+\] class\=\"dummy\">)?j(<\/i\[\d+\]>)?<\/sup\[\1\]>/<sup\[$1\] class\=\"dummy\">10<\/sup\[$1\]>/sgi;
	


	if($frontmatter=~/<p\[(\d+)\] class\=\"ArticleTitleHead\" (.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"normal\">/si)
	{
		$frontmatter=~s/<p\[(\d+)\] class\=\"ArticleTitleHead\" (.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"normal\">/<p\[$1\] class\=\"ArticleTitleHead\" $2<\/p\[\1\]>\n<p\[$3\] class\=\"PAuthorGroup\">/sgi;
	}
	elsif($frontmatter=~/<p\[(\d+)\] class\=\"ArticleTitleHead\" (.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"RunningHead\">/si)
	{
		$frontmatter=~s/<p\[(\d+)\] class\=\"ArticleTitleHead\" (.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"RunningHead\"(.*?)<\/p\[\3\]>\s*<p\[(\d+)\] class\=\"normal\">/<p\[$3\] class\=\"RunningHead\"$4<\/p\[$3\]>\n<p\[$1\] class\=\"ArticleTitleHead\" $2<\/p\[$1\]>\n<p\[$5\] class\=\"PAuthorGroup\">/sgi;
	}


	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"PAuthorGroup\">(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		
		$Curr=~s/([a-z])(\d+)\,(\d+)\,(\d+)(\, |<)/$1<sup\[000\] class\=\"dummy\">$2\,$3\,$4<\/sup\[000\]>$5/gi;	
		$Curr=~s/([a-z])(\d+)\,(\d+)(\, |<)/$1<sup\[000\] class\=\"dummy\">$2\,$3<\/sup\[000\]>$4/gi;	
		$Curr=~s/([a-z])(\d+)(\, |<)/$1<sup\[000\] class\=\"dummy\">$2<\/sup\[000\]>$3/gi;	
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;
	
	while($frontmatter=~/<p\[(\d+)\] class\=\"PAuthorGroup\">(.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"normal\">(.*?<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\5\]>)<\/p\[\3\]>/si)
	{
		$frontmatter=~s/<p\[(\d+)\] class\=\"PAuthorGroup\">(.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"normal\">(.*?<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\5\]>)<\/p\[\3\]>/<p\[$1\] class\=\"PAuthorGroup\">$2\, $4<\/p\[\1\]>/sgi;
	}
	
	


}



sub FMAUTHORGROUPING
{
	
	$frontmatter=~s/<p\[(\d+)\] class\=\"PAuthorGroup\"><b\[(\d+)\] class\=\"dummy\">Abstract/<p\[$1\] class\=\"normal\"><b\[$2\] class\=\"dummy\">Abstract/gi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"PAuthorGroup\"><i\[(\d+)\] class\=\"dummy\">Abstract/<p\[$1\] class\=\"normal\"><i\[$2\] class\=\"dummy\">Abstract/gi;
	$frontmatter=~s/<p\[(\d+)\] class\=\"PAuthorGroup\">Abstract/<p\[$1\] class\=\"normal\">Abstract/gi;

	my $degrees="Msc\|Mph\|Phd\|Md\|PharmD\|Mba\|Au\.D\.\|Art\.D\.\|D\.Arch\.\|D\.Chem\.\|D\.Crim\.\|D\.Des\.\|D\.Ed\.\|D\.Eng\.\|D\.Env\.\|D\.Sc\.\|Sc\.D\.\|D\.Sc\.H\.\|Mus\.D\.\|Ph\.D\.\|Sc\.D\.\|S\.Sc\.D\.\|DNP\|MEd\|MSCE\|DM\|FRCSC\|MBBS|FRCPC\|FCCP\|FCCM\|FIDSA\|FACEP\|FIFEM\|FAEMS\|\\\(Hon\.\\\)\|MSHPEd\|HMDC\|MSW\|LCSW\|FAAP\|Jr\.\|DTM\|MSPH\|BSFS\|BS\|MS";


	my $UNSTRUCTAUT="";
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"PAuthorGroup\">(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		$UNSTRUCTAUT="$2";
		

		#$Curr=~s/([A-z]+)(\d+)\,(\d+)\,(\d+)\, ([A-z]+)/([A-z]+)(\d+)\,(\d+)\,(\d+)\, ([A-z]+)/gi;
		#print ERR "$Curr\n";
		$Curr=~s/\, ?(<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\2\]>)(\, |<\/p\[\d+\]>)/$1$4/gi;
		#print ERR "$Curr\n";
		$Curr=~s/\,?<\/sup\[(\d+)\]>\*/\,\*<\/sup\[$1\]>/gi;
		$Curr=~s/<\/sup\[(\d+)\]>(\d+)/$2<\/sup\[$1\]>/gi;
		if($Curr=~/<p\[(\d+)\] class\=\"PAuthorGroup\"><sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\2\]>/si)
		{
			$Curr=~s/<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\1\]>(.*?)\,/$3<sup\[$1\] class\=\"dummy\">$2<\/sup\[$1\]>\,/gi;
			$Curr=~s/<\/sup\[(\d+)\]>\, <sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\2\]>(.*?)<\/p\[(\d+)\]>/<\/sup\[$1\]>\, $4<sup\[$2\] class\=\"dummy\">$3<\/sup\[$2\]><\/p\[$5\]>/sgi;
			
		}
		
		$Curr=~s/([A-Za-z]+)\*/$1<sup\[0000\] class\=\"dummy\">\*<\/sup\[0000\]>/gi;
		$Curr=~s/<\/sup\[(\d+)\]>\*/\*<\/sup\[$1\]>/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"PAuthorGroup\"> ?<b\[(\d+)\] class\=\"dummy\"> ?Authors ?\:? ?<\/b\[\2\]>\:? /<p\[$1\] class\=\"PAuthorGroup\">/gi;
		$Curr=~s/ <sup\[(\d+)\] class\=\"dummy\">/<sup\[$1\] class\=\"dummy\">/gi;
		
		$Curr=~s/<sub\[(\d+)\] class\=\"dummy\">\,<\/sub\[\1\]>/\,/gi;
		$Curr=~s/<i\[(\d+)\] class\=\"dummy\">//gi;
		$Curr=~s/<i>//gi;
		$Curr=~s/<\/i\[(\d+)\]>//gi;
		$Curr=~s/<\/i>//gi;

		$Curr=~s/<b\[(\d+)\] class\=\"dummy\">//gi;
		$Curr=~s/<b>//gi;
		$Curr=~s/<\/b\[(\d+)\]>//gi;
		$Curr=~s/<\/b>//gi;
		$Curr=~s/\, and / and /gi;
		$Curr=~s/<\/sup\[(\d+)\]>and /<\/sup\[$1\]> and /gi;
		$Curr=~s/<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\1\]>\, ($degrees)(\,|<)/\, $3<sup\[$1\] class\=\"dummy\">$2<\/sup\[$1\]>$4/gi; 		

		if($Curr=~/ (\w+)\; /si)
		{
			$Curr=~s/<p\[(\d+)\] class\=\"PAuthorGroup\">(.*?)<\/p\[\1]>/<p\[$1\] class\=\"PAuthorGroup\"><Author>$2<\/Author><\/p\[$1]>/gi;
			$Curr=~s/( and )/<\/Author><SEP>$2<\/SEP><Author>/gi;
			$Curr=~s/( (\w+))(\,\; )/$1<\/Author><SEP>$3<\/SEP><Author>/gi;
			$Curr=~s/( (\w+))(\; )/$1<\/Author><SEP>$3<\/SEP><Author>/gi;
		}
		elsif($Curr=~/<sup\[(\d+)\] class\=\"dummy\">/si)
		{
			$Curr=~s/<p\[(\d+)\] class\=\"PAuthorGroup\">(.*?)<\/p\[\1]>/<p\[$1\] class\=\"PAuthorGroup\"><Author>$2<\/Author><\/p\[$1]>/gi;
			$Curr=~s/( and |\, |\; )/<\/Author><SEP>$1<\/SEP><Author>/gi;
			$Curr=~s/<\/(sup|a)\[(\d+)\]>(\, | and | )/<\/$1\[$2\]><\/Author><SEP>$3<\/SEP><Author>/g;
		}
		else
		{
			$Curr=~s/<p\[(\d+)\] class\=\"PAuthorGroup\">(.*?)<\/p\[\1]>/<p\[$1\] class\=\"PAuthorGroup\"><Author>$2<\/Author><\/p\[$1]>/gi;
			$Curr=~s/( and |\, |\; )/<\/Author><SEP>$1<\/SEP><Author>/gi;
		}

		
		$Curr=~s/\,<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\1\]><\/Author><SEP> <\/SEP>/<sup\[$1\] class\=\"dummy\">$2<\/sup\[$1\]><\/Author><SEP>\, <\/SEP>/gi;
		$Curr=~s/\,<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\1\]><\/Author><SEP> and <\/SEP>/<sup\[$1\] class\=\"dummy\">$2<\/sup\[$1\]><\/Author><SEP> and <\/SEP>/gi;
		$Curr=~s/<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\1\]>(\; ?|\, ?)(on\-? ?behalf)/<sup\[$1\] class\=\"dummy\">$2<\/sup\[$1\]><\/Author><SEP>$3<\/SEP><Author>$4/gi;
		$Curr=~s/(\&\#?\w+)<\/Author><SEP>(\;\s*)<\/SEP><Author>/$1$2/gi;
		
	
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;
	
	#exit;
	
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<Author>(.*?)<\/Author>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';

		$Curr=~s/\,(<sup\[(\d+)\] class\=\"dummy\">(\w+)<\/sup\[\2\]>)/$1\,/gi;
		$Curr=~s/<Author>(Prof\. ?|Ms\. ?|Ms )/<Prefix>$1<\/Prefix><Author>/gi;
		$Curr=~s/<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\1\]>(.*?)<\/Author>/$3<sup\[$1\] class\=\"dummy\">$2<\/sup\[$1\]><\/Author>/gi;
		$Curr=~s/<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\1\]>(.*?)<\/Author>/$3<sup\[$1\] class\=\"dummy\">$2<\/sup\[$1\]><\/Author>/gi;
		$Curr=~s/<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\1\]>(.*?)<\/Author>/$3<sup\[$1\] class\=\"dummy\">$2<\/sup\[$1\]><\/Author>/gi;
		$Curr=~s/<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\1\]>(.*?)<\/Author>/$3<sup\[$1\] class\=\"dummy\">$2<\/sup\[$1\]><\/Author>/gi;
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;
	
	$frontmatter=~s/(\&\#x)([A-Z0-9]{2}\;)/${1}00${2}/sgi;

	$Line1=$frontmatter;	
	$Variable1="";	
	while($Line1 =~/<Author>((?:(?!(<\/Author>)).)*?)<\/Author>/gi)	
	{	
		$PreMatch1 = $`;
		$Curr1 = $&;
		$Line1 = $';

		$Curr1=~s/\&(\w+)\;/tplamp$1tplcolon/g;
		$Curr1=~s/\&\#(\w+)\;/tplamphash$1tplcolon/g;
		

		if($Curr1=~/<Author>(<[^<>]*>)*(.*?)<(sup|a)\[(\d+)\] /si)
		{
			my $Authorxx="$2";
			my $role="<Role><\/Role>";
			
			my @rolex="";
			while($Authorxx=~/((\,)? ($degrees))$/gi)
			{
				$role1="$1";
				push(@rolex, "$role1");
				$Authorxx=~s/\Q$role1\E$//gi;
			}
			
			my @reversedNames = reverse(@rolex);

			my $jxml="";
			if($Authorxx=~/on behalf/si)
			{
				$Authorxx=~s/<Author>/<AUTHOR><COLLAB>/g;
				$Authorxx=~s/<\/Author>/<\/COLLAB><SEP><\/SEP><\/AUTHOR>/g;
				$jxml="$Authorxx";
			}
			else
			{
			#$jxml = qx("C\:\\Ruby26\-x64\bin\\ruby\.exe \"C\:\\Ruby26\-x64\\lib\\ruby\\gems\\2\.6\.0\\gems\\namae\-1\.0\.1\\lib\\NAMEPARSER\.rb\" \'$Authorxx\'");
			#$jxml = system("ruby C\:\\Ruby26\-x64\\lib\\ruby\\gems\\2\.6\.0\\gems\\namae\-1\.0\.1\\lib\\NAMEPARSER\.rb \'$Authorxx\'");
			$jxml = qx("\"D\:\\Ruby32\-x64\\bin\\ruby\.exe \"D\:\\Ruby32\-x64\\lib\\ruby\\gems\\3\.2\.0\\gems\\namae\-1\.1\.1\\lib\\NAMEPARSER\.rb\" \'$Authorxx\'");
			}

			$jxml=~s/^\[\#//gi;
			$jxml=~s/\]$//gi;

			
			$jxml=~s/<Name (.*?)>/<author $1\/>/gi;
			
			$jxml=~s/<AUGRP>\s*//gi;
			$jxml=~s/\s*<\/AUGRP>\s*//gi;
			$jxml=~s/<(snm|inits)>/<\U$1\E>/gi;
			$jxml=~s/<\/(snm|inits)>/<\/\U$1\E>/gi;
			$jxml=~s/<x>(.*?)<\/x>/<SEP><\/SEP>/gi;

			
			$jxml=~s/<author family\=\"([^\"]+)\" given\=\"([^<]+)\&amp\; ([^<]+)\"\s*\/><SEP><\/SEP>\s*<author given\=\"([^\"]+)\"\s*\/>/<author family\=\"$1\" given\=\"$2\" \/><SEP><\/SEP>\n<author family\=\"$3\" given\=\"$4\" \/>/sg;
	
			$jxml=~s/<author family\=\"([^\"]+)\" particle\=\"\&amp\;\"\s*\/><SEP><\/SEP>\s*<author given\=\"([^\"]+)\"\s*\/>/<author family\=\"$1\" given\=\"$2\" \/>/sg;
			
			$jxml=~s/<author family\=\"([^\"]+)\" given\=\"([^\"]+)\" suffix\=\"([^\"]+)\" \/><SEP><\/SEP>\n<author given\=\"([^\"]+)\"\s*\/>/<author family\=\"$1\" given\=\"$3\" \/><SEP><\/SEP>\n<author family\=\"$2\" given\=\"$4\" \/>/sg;
			$jxml=~s/ particle\=\"(\&amp\;|ed\.|eds\.)\"//g;
			
			if($jxml =~ m/ family\=\"([^\"]+)\" given\=\"([^\"]+)\"/si)
			{
				my $snm="$1";
				my $fnm="$2";
				
				if($snm !~ m/([a-z])/)
				{
					$jxml=~s/ family\=\"([^\"]+)\" given\=\"([^\"]+)\"/ family\=\"$2\" given\=\"$1\"/g;
				}
				
				if($snm =~ m/^(\&(\w+)\;\.?|\&(\w+)\;\.?\&(\w+)\;\.?|\&(\w+)\;\.?\&(\w+)\;\.?\&(\w+)\;\.?)$/)
				{
					$jxml=~s/ family\=\"([^\"]+)\" given\=\"([^\"]+)\"/ family\=\"$2\" given\=\"$1\"/g;
				}
			}		
			
			$jxml=~s/<(author|editor) family\=\"([^\"]+)\" given\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><\/AUTHOR>/g;
			
			$jxml=~s/<(author|editor) family\=\"([^\"]+)\" given\=\"([^\"]+)\" suffix\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><SEP><\/SEP><SUFFIX>$4<\/SUFFIX><\/AUTHOR>/g;
			
			$jxml=~s/<(author|editor) family\=\"([^\"]+)\" suffix\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><\/AUTHOR>/g;
			
			$jxml=~s/<(author|editor) family\=\"([^\"]+)\" given\=\"([^\"]+)\" particle\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$4 $2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><SEP><\/SEP><\/AUTHOR>/g;
			
			
			$jxml=~s/<(author|editor) family\=\"([^\"]+) ([^\"]+)\" particle\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$4 $2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><SEP><\/SEP><\/AUTHOR>/sg;
			
			$jxml=~s/<(author|editor) family\=\"([^\"]+)\" particle\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$3<\/SNM><SEP><\/SEP><INITS>$2<\/INITS><SEP><\/SEP><\/AUTHOR>/sg;
			
			
			if($jxml =~ m/<author given\=\"([^\"]+)\"\s*\/>/sgi)
			{
				my $givenn="$1";
				$givenn=~s/\.//g;
				
				$jxml=~s/<author given\=\"([^\"]+)\"\s*\/>/<AUTHOR><COLLAB>$givenn<\/COLLAB><SEP><\/SEP><\/AUTHOR>/i;
				
			}
			$jxml=~s/<AUTHOR><SNM>\&\#(\w+)\;<\/SNM><SEP><\/SEP><INITS>(.*?)<\/INITS><\/AUTHOR>/<AUTHOR><SNM>$2<\/SNM><SEP><\/SEP><INITS>\&\#$1\;<\/INITS><\/AUTHOR>/sg;
			
			while($jxml =~ m/ ([A-Z])\.?<\/SNM><SEP><\/SEP><INITS>/sgi)
			{
				$jxml=~s/ ([A-Z])\.?<\/SNM><SEP><\/SEP><INITS>/<\/SNM><SEP><\/SEP><INITS>$1/g;
			}

			if($jxml =~ m/<AUTHOR>(.*?)<\/AUTHOR>/si)
			{
				my $newauthor="$1";
				$newauthor=~s/<SEP><\/SEP>/<SEP> <\/SEP>/g;
				$Curr1=~s/<Author>(.*?)<(sup|a)\[(\d+)\] /<Author>$newauthor<Role>@reversedNames<\/Role><$2\[$3\] /sgi;
				$Curr1=~s/<Role><\/Role>//g;
				$Curr1=~s/<Role>(\W+)(\s*)/<SEP>$1$2<\/SEP><Role>/g;
				$Curr1=~s/(\s+)<\/Role><\/Author>/<\/Role><\/Author><SEP>$1<\/SEP>/gi;
				$Curr1=~s/(\s+)<\/Role>/<\/Role>/gi;
				$Curr1=~s/ \,/\,/g;
			}					
		}
		elsif($Curr1=~/<Author>(.*?)<\/Author>/si)
		{
			my $Authorxx="$1";
			my $role="<Role><\/Role>";
			
			my @rolex="";
			while($Authorxx=~/((\,)? ($degrees))$/gi)
			{
				$role1="$1";
				push(@rolex, "$role1");
				$Authorxx=~s/\Q$role1\E$//gi;
			}

			my @reversedNames = reverse(@rolex);

			my $jxml="";
			if($Authorxx=~/on behalf/si)
			{
				$Authorxx=~s/^/<AUTHOR><COLLAB>/i;
				$Authorxx=~s/$/<\/COLLAB><SEP><\/SEP><\/AUTHOR>/i;
				$jxml="$Authorxx";
			}
			else
			{
				#$jxml = qx("ruby \"C\:\\Ruby26\-x64\\lib\\ruby\\gems\\2\.6\.0\\gems\\namae\-1\.0\.1\\lib\\NAMEPARSER\.rb\" \'$Authorxx\'");
			$jxml = qx("\"D\:\\Ruby32\-x64\\bin\\ruby\.exe \"D\:\\Ruby32\-x64\\lib\\ruby\\gems\\3\.2\.0\\gems\\namae\-1\.1\.1\\lib\\NAMEPARSER\.rb\" \'$Authorxx\'");
			}

			$jxml=~s/^\[\#//gi;
			$jxml=~s/\]$//gi;
			$jxml=~s/<Name (.*?)>/<author $1\/>/gi;
			
			$jxml=~s/<AUGRP>\s*//gi;
			$jxml=~s/\s*<\/AUGRP>\s*//gi;
			$jxml=~s/<(snm|inits)>/<\U$1\E>/gi;
			$jxml=~s/<\/(snm|inits)>/<\/\U$1\E>/gi;
			$jxml=~s/<x>(.*?)<\/x>/<SEP><\/SEP>/gi;
			
			$jxml=~s/<author family\=\"([^\"]+)\" given\=\"([^<]+)\&amp\; ([^<]+)\"\s*\/><SEP><\/SEP>\s*<author given\=\"([^\"]+)\"\s*\/>/<author family\=\"$1\" given\=\"$2\" \/><SEP><\/SEP>\n<author family\=\"$3\" given\=\"$4\" \/>/sg;
	
			$jxml=~s/<author family\=\"([^\"]+)\" particle\=\"\&amp\;\"\s*\/><SEP><\/SEP>\s*<author given\=\"([^\"]+)\"\s*\/>/<author family\=\"$1\" given\=\"$2\" \/>/sg;
			
			$jxml=~s/<author family\=\"([^\"]+)\" given\=\"([^\"]+)\" suffix\=\"([^\"]+)\" \/><SEP><\/SEP>\n<author given\=\"([^\"]+)\"\s*\/>/<author family\=\"$1\" given\=\"$3\" \/><SEP><\/SEP>\n<author family\=\"$2\" given\=\"$4\" \/>/sg;
			$jxml=~s/ particle\=\"(\&amp\;|ed\.|eds\.)\"//g;
			
			if($jxml =~ m/ family\=\"([^\"]+)\" given\=\"([^\"]+)\"/si)
			{
				my $snm="$1";
				my $fnm="$2";

				if($snm !~ m/([a-z])/)
				{
					$jxml=~s/ family\=\"([^\"]+)\" given\=\"([^\"]+)\"/ family\=\"$2\" given\=\"$1\"/g;
				}
				
				if($snm =~ m/^(\&(\w+)\;\.?|\&(\w+)\;\.?\&(\w+)\;\.?|\&(\w+)\;\.?\&(\w+)\;\.?\&(\w+)\;\.?)$/)
				{
					$jxml=~s/ family\=\"([^\"]+)\" given\=\"([^\"]+)\"/ family\=\"$2\" given\=\"$1\"/g;
				}
			}		
			
			$jxml=~s/<(author|editor) family\=\"([^\"]+)\" given\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><\/AUTHOR>/g;
			
			$jxml=~s/<(author|editor) family\=\"([^\"]+)\" given\=\"([^\"]+)\" suffix\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><SEP><\/SEP><SUFFIX>$4<\/SUFFIX><\/AUTHOR>/g;
			
			$jxml=~s/<(author|editor) family\=\"([^\"]+)\" suffix\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><\/AUTHOR>/g;
			
			$jxml=~s/<(author|editor) family\=\"([^\"]+)\" given\=\"([^\"]+)\" particle\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$4 $2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><SEP><\/SEP><\/AUTHOR>/g;
			
			
			$jxml=~s/<(author|editor) family\=\"([^\"]+) ([^\"]+)\" particle\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$4 $2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><SEP><\/SEP><\/AUTHOR>/sg;
			
			$jxml=~s/<(author|editor) family\=\"([^\"]+)\" particle\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$3<\/SNM><SEP><\/SEP><INITS>$2<\/INITS><SEP><\/SEP><\/AUTHOR>/sg;
			
			
			if($jxml =~ m/<author given\=\"([^\"]+)\"\s*\/>/sgi)
			{
				my $givenn="$1";
				$givenn=~s/\.//g;
				
				$jxml=~s/<author given\=\"([^\"]+)\"\s*\/>/<AUTHOR><COLLAB>$givenn<\/COLLAB><SEP><\/SEP><\/AUTHOR>/i;
				
			}
			$jxml=~s/<AUTHOR><SNM>\&\#(\w+)\;<\/SNM><SEP><\/SEP><INITS>(.*?)<\/INITS><\/AUTHOR>/<AUTHOR><SNM>$2<\/SNM><SEP><\/SEP><INITS>\&\#$1\;<\/INITS><\/AUTHOR>/sg;
			
			while($jxml =~ m/ ([A-Z])\.?<\/SNM><SEP><\/SEP><INITS>/sgi)
			{
				$jxml=~s/ ([A-Z])\.?<\/SNM><SEP><\/SEP><INITS>/<\/SNM><SEP><\/SEP><INITS>$1/g;
			}


			if($jxml =~ m/<AUTHOR>(.*?)<\/AUTHOR>/si)
			{
				my $newauthor="$1";
				$newauthor=~s/<SEP><\/SEP>/<SEP> <\/SEP>/g;
				$Curr1=~s/<Author>(.*?)<\/Author>/<Author>$newauthor<Role>@reversedNames<\/Role><\/Author>/sgi;
				$Curr1=~s/<Role><\/Role>//g;
				$Curr1=~s/<Role>(\W+)(\s*)/<SEP>$1$2<\/SEP><Role>/g;
				$Curr1=~s/(\s+)<\/Role><\/Author>/<\/Role><\/Author><SEP>$1<\/SEP>/gi;
				$Curr1=~s/ \,/\,/g;
			}					
		}
		
		
		$Curr1=~s/<sup\[(\d+)\] class\=\"dummy\">(.*?)<\/sup\[\1\]>/<AFFID>$2<\/AFFID>/gi;
		$Curr1=~s/tplamphashx(\w{5})tplcolon/\&\#x$1\;/g;
		$Curr1=~s/tplamphashx(\w{4})tplcolon/\&\#x$1\;/g;
		$Curr1=~s/tplamphashx(\w{3})tplcolon/\&\#x$1\;/g;
		$Curr1=~s/tplamphash(\w+)tplcolon/\&\#$1\;/g;
		$Curr1=~s/tplamp(\w+)tplcolon/\&$1\;/g;
		$Curr1=~s/tplamp/\&/g;
		$Curr1=~s/tplcolon/\;/g;
		
		
	$Variable1 .=$PreMatch1 .$Curr1;	
	}	
	$Variable1 .=$Line1;	
	$frontmatter = $Variable1;


	$frontmatter=~s/<SEP>\,\; <\/SEP>/<SEP>\; <\/SEP>/g;
	$frontmatter=~s/<SEP> <\/SEP><SEP>\; <\/SEP>/<SEP>\; <\/SEP>/gi;
	$frontmatter=~s/<SEP>/<FMSEP>/gi;
	$frontmatter=~s/<\/SEP>/<\/FMSEP>/gi;
	$frontmatter=~s/\,<\/Author><FMSEP>/<\/Author><FMSEP>\,/gi;
	$frontmatter=~s/\,<\/Author><\/p\[(\d+)\]>/<\/Author><\/p\[$1\]>/gi;
	$frontmatter=~s/<Prefix>(.*?) ?<\/Prefix><Author>/<Author><span class\=\"Prefix\">$1<\/span><FMSEP> <\/FMSEP>/gi;
	$frontmatter=~s/<\/Author><SEP><\/SEP><Role>(.*?)(\,? ?)<\/Role>/<FMSEP>$2<\/FMSEP><Role>$1 <\/Role><\/Author><SEP><\/SEP>/gi;
	$frontmatter=~s/<\/Author><SEP><\/SEP><Author>/<\/Author><SEP>\, <\/SEP><Author>/gi;
	$frontmatter=~s/<\/Author><FMSEP><\/FMSEP><Author>/<\/Author><FMSEP>\, <\/FMSEP><Author>/gi;
	$frontmatter=~s/<\/Author><FMSEP> and <\/FMSEP>/<\/Author>/gi;
	
	open(TXX, "<$serverpath/FM\-CONFIG/Journals/$pubname/$jname\.ini") or warn print("$jname\.ini NOT FOUND, update the Journal Database!!!");
	my $fmdetails = <TXX>;
	close (TXX);
	
	
	if ($fmdetails=~m/<AUORDER><given\-names\/><surname\/><\/AUORDER>/si)
	{
		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<Author>(.*?)<\/Author>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			
			$Curr=~s/<SNM>(.*?)<\/SNM>(.*?)<INITS>(.*?)<\/INITS>/<INITS>$3<\/INITS>$2<SNM>$1<\/SNM>/sgi;
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;

	}


	##NEW FM INITIAL Conversion
	if($fmdetails=~m/<INITIALS><(\w+)\/>(<(\w+)\/>)?<\/INITIALS>/i)
	{
		my $fnmformat1 = "$1";
		my $fnmformat2 = "$3";
		
		$Line=$frontmatter;
		$Variable="";
		while($Line =~/<INITS>(.*?)<\/INITS>/g)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $intext="$1";
			
			#to abbrivated
			if($fmdetails=~m/<INITIALS type="ABBR"\/>/i)
			{
				$intext =~ s/^([A-Z])([a-z]+)/$1\./g;
				$intext =~ s/ ([A-Z])([a-z]+)/ $1\./g;
				$intext =~ s/ ([A-Z])([a-z]+)/ $1\./g;
				$intext =~ s/\-([A-Z])([a-z]+)/\-$1\./g;
				$intext =~ s/\.([A-Z])([a-z]+)/\.$1\./g;
				$intext =~ s/\-([a-z])([a-z]+)/\-\U$1\E\./g;
			}
			
			if($fnmformat1=~m/^DOTTED/i)
			{
				$intext=~s/([^\&\#x(\w+)])([A-Z])([A-Z])\.?/$1$2\.$3\./g;
				$intext=~s/([^\&\#x(\w+)])([A-Z])([A-Z])\.?/$1$2\.$3\./g;
				$intext=~s/([A-Z])([A-Z])\.?/$1\.$2\./g;
				$intext=~s/([A-Z])([A-Z])\.?/$1\.$2\./g;
				$intext=~s/([A-Z]) ([A-Z])\.?/$1\.$2\./g;
				$intext=~s/([A-Z]) ([A-Z])\.?/$1\.$2\./g;
				$intext=~s/([A-Z])$/$1\./g;
			}
			elsif($fnmformat1=~m/^NODOTTED/i)
			{
				$intext=~s/([A-Z])\./$1/g;
			}
	
			if($fnmformat2=~m/^SPACED/i)
			{
				$intext=~s/([A-Z])\.([A-Z])/$1\. $2/g;
				$intext=~s/([A-Z])\.([A-Z])/$1\. $2/g;
				$intext=~s/([^\&\#x(\w+)])([A-Z])([A-Z])/$1$2 $3/g;
				$intext=~s/([^\&\#x(\w+)])([A-Z])([A-Z])/$1$2 $3/g;
			}
	
			elsif($fnmformat2=~m/^CLOSEDUP/i)
			{
				$intext=~s/([A-Z])\. ([A-Z])/$1\.$2/g;
				$intext=~s/([A-Z])\. ([A-Z])/$1\.$2/g;
				$intext=~s/([A-Z]) ([A-Z])/$1$2/g;
				$intext=~s/([A-Z]) ([A-Z])/$1$2/g;
			}
				
			$Curr=~s/<INITS>(.*?)<\/INITS>/<INITS>$intext<\/INITS>/i;

			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$frontmatter = $Variable;
	}

	
	
	my $aucount=0;
	while($frontmatter =~ m/<Author>/gi)
	{
		$aucount++;
		$frontmatter=~s/<Author>/<span class\=\"Author\" data\-element\=\"contrib\" data\-attribs\-id\=\"author\-$aucount\" data\-attribs\-contrib\-type\=\"author\"><span class\=\"name\" data\-element\=\"name\" data\-attribs\-name\-style\=\"western\">/i;
	}
	
	
	$frontmatter=~s/<xp\[/<p\[/sgi;
	$frontmatter=~s/<\/xp\[/<\/p\[/sgi;
	$frontmatter=~s/<\/Author>/<\/span><\/span>/sgi;	
	$frontmatter=~s/<SNM>/<span class\=\"surname\" data\-element\=\"surname\">/sgi;	
	$frontmatter=~s/<INITS>/<span class\=\"given\-names\" data\-element\=\"given\-names\">/sgi;	
	$frontmatter=~s/<Role>/<span class\=\"role\" data\-element\=\"degrees\">/sgi;	
	$frontmatter=~s/<prefix>/<span class\=\"Prefix\" data\-element\=\"prefix\">/sgi;	
	$frontmatter=~s/<\/SNM>/<\/span>/sgi;	
	$frontmatter=~s/<\/Role>/<\/span>/sgi;	
	$frontmatter=~s/<\/prefix>/<\/span>/sgi;	
	$frontmatter=~s/<\/INITS>/<\/span>/sgi;
	$frontmatter=~s/<span class\=\"Institution\" data\-element\=\"institution\">(Corresponding Author|Co\-Correspondence|Correspondence)\: /$1\: <span class\=\"Institution\" data\-element\=\"institution\">/gi;
	
	
}

sub FMSTYLING2
{
		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<AFFID>(.*?)<\/AFFID>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			$Curr=~s/\, ?/<\/AFFID><AFFID>/g;
			#$Curr=~s/<AFFID>/<span class\=\"AFFID\">/g;
			#$Curr=~s/<\/AFFID>/<\/span>/g;
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;


		my $affgroup="";
		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<p\[(\d+)\] class\=\"PAuthorGroup\">(.*?)<\/p\[\1\]>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			
			my $afffn="";
			while($Curr =~ m/<a\[(\d+)\] class\=\"footnote\" href\=\"\#([^\"]+)\">/sgi)
			{
				my $fnid="$2";
				
				if($_=~m/(<div\[(\d+)\] class\=\"footnote\" id\=\"$fnid\">(.*?)<\/div\[\2\]>)/si)
				{
					my $fnpara="$1";
					push(@fnarray, "$fnid");
					$affgroup .="$fnpara\n";
				}
				$Curr=~s/<a\[(\d+)\] class\=\"footnote\" href\=\"\#([^\"]+)\">/<a\[$1\] class\=\"xfootnote\" href\=\"\#$2\">/;
				
			}

							
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;
		
		
		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<p(\[\d+\]) class="funding\-group" data-element="funding\-group">(.*?)<\/p\1>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';

			$Curr=~s/<p(\[\d+\]) class="funding\-group" data-element="funding\-group">(.*?)<\/p\1>/<div class="funding\-group" data-element="funding\-group">\n<p$1 class\=\"funding-statement\" data\-element\=\"funding\-statement\">$2<\/p$1>\n<\/div>/si;

		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;
		
		
		$affgroup=~s/<div\[(\d+)\] class\=\"footnote\" id\=\"footnote(\d+)\">\s*<p\[(\d+)\] class\=\"([^\"]+)\">(.*?)<\/div\[\1\]>/<p\[$3\] class\=\"Affiliation\"><sup\[111111\] class\=\"dummy\">$2<\/sup\[111111\]>$5/sgi;
		$frontmatter=~s/<a\[(\d+)\] class\=\"xfootnote\" href\=\"\#footnote\d+">(\d+)<\/a\[\1\]>/<AFFID>$2<\/AFFID>/gi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"PAuthorGroup\">(.*?)<\/p\[\1\]>/<p\[$1\] class\=\"PAuthorGroup\">$2<\/p\[$1\]>\n$affgroup/si;
		$frontmatter=~s/<b\[(\d+)\] class\=\"dummy\"><i\[(\d+)\] class\=\"dummy\">(Key ?words\:?)<\/i\[\2\]><\/b\[\1\]>/$3/gi;
		$frontmatter=~s/<i\[(\d+)\] class\=\"dummy\">(Keywords)<\/i\[\1\]>/$2/sgi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"\w+\"><b\[(\d+)\] class\=\"dummy\">Address\:<\/b\[\2\]><\/p\[\1\]>\s*//sg;
		$frontmatter=~s/<p\[(\d+)\] class\=\"[^\"]+\"><b\[(\d+)\] class\=\"dummy\">Subjects/<p\[$1\] class\=\"SUBJECTS\" data\-element\=\"SUBJECTS\" data\-attribs\-subj\-group\-type\=\"categories\"><b\[$2\] class\=\"dummy\">Subjects/gi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"[^\"]+\">Subjects/<p\[$1\] class\=\"SUBJECTS\" data\-element\=\"SUBJECTS\" data\-attribs\-subj\-group\-type\=\"categories\">Subjects/gi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"normal\"><b\[(\d+)\] class\=\"dummy\"><i\[(\d+)\] class\=\"dummy\">Keywords\: ?/<p\[$1\] class\=\"normal\">Keywords\: <b\[$2\] class\=\"dummy\"><i\[$3\] class\=\"dummy\">/sgi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"[^\"]+\"><b\[(\d+)\] class\=\"dummy\">Key ?words\:?<\/b\[\2\]><\/p\[\1\]>\s*<p\[(\d+)\] class\=\"[^\"]+\">/<p\[$3\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\">/sgi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"[^\"]+\">Keywords\:<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"[^\"]+\">/<p\[$2\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\">/sgi;		
		$frontmatter=~s/<p\[(\d+)\] class\=\"[^\"]+\"><i\[(\d+)\] class\=\"dummy\">Key ?words\:?<\/i\[\2\]>\:?<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"[^\"]+\">/<p\[$3\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\">/sgi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"[^\"]+\"><b\[(\d+)\] class\=\"dummy\">Keywords/<p\[$1\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\"><b\[$2\] class\=\"dummy\">Keywords/gi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"[^\"]+\"><i\[(\d+)\] class\=\"dummy\">Keywords/<p\[$1\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\"><i\[$2\] class\=\"dummy\">Keywords/gi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"[^\"]+\">Keywords/<p\[$1\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\">Keywords/gi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"[^\"]+\"><b\[(\d+)\] class\=\"dummy\">Key ?words(.*?)<\/p\[\1\]>/<p\[$1\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\"><b\[$2\] class\=\"dummy\">Keywords$3<\/p\[\1\]>/sgi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"[^\"]+\">Key ?words(.*?)<\/p\[\1\]>/<p\[$1\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\">Keywords$2<\/p\[$1\]>/sgi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"(\w+)\"><i\[(\d+)\] class\=\"dummy\">(Abstract\:? ?)<\/i\[\3\]><\/p\[\1\]>/<p\[$1\] class\=\"$2\"><b\[$3\] class\=\"dummy\">$4<\/b\[$3\]><\/p\[$1\]>/g;
		$frontmatter=~s/<div\[(\d+)\] class\=\"abstract\" data\-element\=\"abstract\">(.*?)<p\[(\d+)\] class\=\"RunningHead\">(.*?)<\/p\[\3\]>/<p\[$3\] class\=\"RunningHead\">$4<\/p\[$3\]>\n<div\[$1\] class\=\"abstract\" data\-element\=\"abstract\">$2/sgi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"\w+\"><b\[(\d+)\] class\=\"dummy\">(Abstract\:? ?)<\/b\[\2\]><\/p\[\1\]>\s*(.*?)(<p\[(\d+)\] class\=\"(SUBJECTS|Keywords|RunningHead)\"|$)/<adiv class\=\"abstract\" data\-element\=\"abstract\">\n$4<\/adiv>\n$5/si;
		$frontmatter=~s/<p\[(\d+)\] class\=\"\w+\">(Abstract\:?)<\/p\[\1\]>\s*(.*?)(<p\[(\d+)\] class\=\"(SUBJECTS|Keywords|RunningHead)\"|$)/<adiv class\=\"abstract\" data\-element\=\"abstract\">\n$3<\/adiv>\n$4/si;
		$frontmatter=~s/<p\[(\d+)\] class\=\"\w+\"><b\[(\d+)\] class\=\"dummy\">(Abstract\:?)<\/b\[\2\]>\:? ?(.*?)<\/p\[\1\]>\s*(.*?)(<p\[(\d+)\] class\=\"(SUBJECTS|Keywords|RunningHead)\"|$)/<adiv class\=\"abstract\" data\-element\=\"abstract\">\n<p\[$1\] class\=\"Abstractpara\">$4$5<\/p\[$1\]><\/adiv>\n$6/si;
		$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(Postal address)\:<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\">(.*?)<\/p\[\4\]>/<p\[$1\] class\=\"AuthorNotes\">$6<\/p\[$1\]>/sgi;
		
		$frontmatter=~s/<b\[(\d+)\] class\=\"dummy\">\*?(Corresponding author|Correspondence|Co\-Correspondence)\:? ?<\/b\[\1\]>\:?/$2\:/gi;
		##Corresponding Author Merging
		
		$frontmatter=~s/<p\[(\d+)\] class\=\"normal\"><b\[\d+\] class\=\"dummy\">(Tel|Fax|email|E\-mail)\:?<\/b\[\d+\]>/<p\[$1\] class\=\"normal\">$2\:/gi;
		
		#print ERR "ss$frontmatter\n";
		#exit;
		
		#$frontmatter=~s/<p class="normal"><b>E-mail:</b>
		while ($frontmatter=~/\.?\s*<\/p\[(\d+)\]>\s*<p\[(\d+)\] class\=\"normal\">((Tel|Fax|email|E\-mail)\:? .*?)<\/p\[\2\]>/sgi)
		{
			$frontmatter=~s/\.?\s*<\/p\[(\d+)\]>\s*<p\[(\d+)\] class\=\"normal\">((Tel|Fax|email|E\-mail)\:? .*?)<\/p\[\2\]>/\, $3<\/p\[$1\]>/sgi;
		}
			
			
		$frontmatter=~s/<p\[(\d+)\] class\=\"normal\">((Correspondence|Co\-Correspondence)\:? .*?)\,?\.?\s*<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"normal\">(.*?)<\/p\[\4\]>/<p\[$1\] class\=\"normal\">$2\, $5<\/p\[\1\]>/sgi;
		#print ERR "ss$frontmatter\n";
		#exit;
		
		
}



sub FMKEYWORDSET
{
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"(SUBJECTS)\"(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		
		$Curr=~s/<b\[(\d+)\] class\=\"dummy\">Subjects\:?<\/b\[\1\]> //sgi;
		$Curr=~s/Subjects\:? //sgi;
		$Curr=~s/<p\[(\d+)\] class\=\"SUBJECTS\" data\-element\=\"SUBJECTS\" data\-attribs\-subj\-group\-type\=\"categories\">(.*?)<\/p\[\1\]>/<p\[$1\] class\=\"SUBJECTS\" data\-element\=\"SUBJECTS\" data\-attribs\-subj\-group\-type\=\"categories\"><SUB\-TEXT>$2<\/SUB\-TEXT><\/p\[\1\]>/sgi;
		$Curr=~s/\, /<\/SUB\-TEXT><SUB\-TEXT>/sgi;	
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;

	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"(KEYWORDS)\"(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		
		$Curr=~s/<b\[(\d+)\] class\=\"dummy\">KEYWORDS\:?<\/b\[\1\]>\;?\:? ?//sgi;
		$Curr=~s/<i\[(\d+)\] class\=\"dummy\">KEYWORDS\:?<\/i\[\1\]>\;?\:? ?//sgi;
		$Curr=~s/KEYWORDS\:? //sgi;
		$Curr=~s/<p\[(\d+)\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\"><i\[(\d+)\] class\=\"dummy\">(.*?)<\/i\[\2\]><\/p\[\1\]>/<p\[$1\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\">$3<\/p\[\1\]>/sgi;
		$Curr=~s/<p\[(\d+)\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\"><b\[(\d+)\] class\=\"dummy\">(.*?)<\/b\[\2\]><\/p\[\1\]>/<p\[$1\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\">$3<\/p\[\1\]>/sgi;
		$Curr=~s/<p\[(\d+)\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\">(.*?)<\/p\[\1\]>/<p\[$1\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\"><kwd>$2<\/kwd><\/p\[\1\]>/sgi;
		
		
		if($Curr =~ m/\, /i)
		{
		$Curr=~s/\, /<\/kwd><FMSEP>\, <\/FMSEP><kwd>/sgi;
		}
		elsif($Curr =~ m/\; /i)
		{
			if($pubname=~/^(ASP)$/)
			{
				$Curr=~s/\; /<\/kwd><FMSEP>\, <\/FMSEP><kwd>/sgi;
			}
			else
			{
				$Curr=~s/\; /<\/kwd><FMSEP>\; <\/FMSEP><kwd>/sgi;
			}
		}
		
		$Curr=~s/\.<\/kwd>/<\/kwd>/gi;
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;


	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<adiv (.*?)<\/adiv>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		if ($Curr=~m/<br><\/br>/i)
		{
			$Curr=~s/<br><\/br>/<\/p\[0\]>\n<p\[0\] class\=\"normal\">/sgi;
			$Curr=~s/<p\[(\d+)\] /<p\[0\] /gi; 
			$Curr=~s/<\/p\[(\d+)\]>/<\/p\[0\]>/gi; 

		}
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"/<p\[$1\] class\=\"Abstractpara\"/gi;
		$Curr=~s/<adiv (.*?)<\/adiv>/<div $1<\/div>/sgi;
				
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;
	
		$frontmatter=~s/<p\[(\d+)\] class\=\"(Abstractpara|Keywords|PAuthorGroup)\">/<xp\[$1\] class\=\"$2\">/g;
		
		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<p\[(\d+)\] class\=\"([^\"]+)\">(.*?)<\/p\[\1\]>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			
			
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20) ?/<p\[$1\] class\=\"$2\"><sup\[00\] class\=\"dummy\">$3<\/sup\[00\]>/gi;
			
			if($Curr =~ m/(?:<[^<]+>)(Department of|universitaire|University|Institute of|Investigaci|Department|Centre for|Institute for|College of|Dept|Laboratory|Laboratoire|Faculty of|Facultad|Universidad|Institute|Research|school|Partners|Society for|Instituto|USERN|Clinical Psychologist|Medical Center|Tecnologico|Graduate School|Institut|Paediatric Cardiology Department|Pediatric Cardiology Department|Division of|Desenvolvimento)/sgi)
			{
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"Affiliation\">/g;
			}
			if($Curr =~ m/((\d+)\, )(Department of|universitaire|University|Institute of|Investigaci|Department|Centre for|Institute for|College of|Dept|Laboratory|Laboratoire|Faculty of|Facultad|Universidad|Institute|Research|school|Partners|Society for|Instituto|USERN|Clinical Psychologist|Medical Center|Tecnologico|Graduate School|Institut|Paediatric Cardiology Department|Pediatric Cardiology Department|Division of|Desenvolvimento)/sgi)
			{
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"Affiliation\">/g;
			}
			
			
			if($Curr =~ m/<p\[(\d+)\] class\=\"normal\">(Department of|universitaire|University|Institute of|Investigaci|Department|Centre for|Institute for|College of|Dept|Laboratory|Laboratoire|Faculty of|Facultad|Universidad|Institute|Research|school|Partners|Society for|Instituto|USERN|Clinical Psychologist|Medical Center|Tecnologico|Graduate School|Institut|Paediatric Cardiology Department|Pediatric Cardiology Department|Division of|Desenvolvimento)/sgi)
			{
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"Affiliation\">/g;
			}
			
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><sup\[(\d+)\] class\=\"dummy\">/<p\[$1\] class\=\"Affiliation\"><sup\[$3\] class\=\"dummy\">/g;
			
			
			if($Curr =~ m/(Corresponding Author|correspondence |Author for correspondence|for correspondence|ADDRESS OF CORRESPONDENCE|Correspondence|Co\-Correspondence)/sgi)
			{
				if($Curr !~ m/<p\[\d+\] class="[^\"]+">\s*<sup(\[\d+\]) class="dummy">\w<\/sup\1>/si)
				{
					if($pubname!~/^(SIAM)$/si)
					{
						$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"CAUTHOR\">/g;
					}
				}
			}
			
			if($Curr =~ m/(Postal|Present) address:/si)
			{
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"AuthorFootnotes\">/g;
			}
			
			if($Curr =~ m/^<p\[(\d+)\] class\=\"([^\"]+)\">(\s*<sup(\[\d+\]) class="dummy">(?:(?!<\/?sup).)*?<\/sup\4>)\s*This (article|work) is/si)
			{
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] xclass\=\"AuthorFootnotes\">/g;
			}
			
			if($Curr =~ m/Action Editor:/si)
			{
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"AuthorFootnotes\">/g;
			}
			
			if($Curr =~ m/Declarations of interest:/si)
			{
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"AuthorFootnotes\">/g;
			}

			if($Curr =~ m/(?:Received by the editor|accepted for publication|published electronically)/si)
			{
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"AuthorFootnotes\">/g;
			}
			

		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;
	
		$frontmatter=~s/<xp\[(\d+)\] /<p\[$1\] /g;
		$frontmatter=~s/xclass="CAUTHOR/class="CAUTHOR/sgi;
		
		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<p\[(\d+)\] class\=\"CAUTHOR\">(.*?)<\/p\[\1\]>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			
			$Curr=~s/((?:[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\]))/<EMAIL>$1<\/EMAIL>/g;
			$Curr=~s/<p\[(\d+)\] class\=\"CAUTHOR\">((\w+)\@(\w+)\.(\w+)\.?(\w+)?\.?(\w+)?)/<p\[$1\] class\=\"CAUTHOR\"><EMAIL>$2<\/EMAIL>/g;
			$Curr=~s/(\w+)\.<EMAIL>/<EMAIL>$1\./g;
			$Curr=~s/<\/EMAIL>\s*<sup\[(\d+)\] class\=\"dummy\">([a-z])\*<\/sup\[\1\]>/<CORR\/><\/EMAIL><sup\[$1\] class\=\"dummy\">$2\*<\/sup\[$1\]>/gi;
			#print ERR "$Curr\n";
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;
		
		#exit;

		


		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<EMAIL>(.*?)<\/EMAIL>/gi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			
			if($Curr=~m/(<CORR\/>)/sgi)
			{
				$Curr=~s/<CORR\/>//g;
				$Curr=~s/<EMAIL>//g;
				$Curr=~s/<\/EMAIL>//g;
				$cemail="$Curr";
				goto LOOP11;
			}
			else
			{
				$Curr=~s/<CORR\/>//g;
				$Curr=~s/<EMAIL>//g;
				$Curr=~s/<\/EMAIL>//g;
				$cemail="$Curr";
				goto LOOP11;
			}
			
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;	

LOOP11:

		
		$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(<b\[(\d+)\] class\=\"dummy\">Acknowledgment<\/b\[\4\]>)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"Affiliation\">/<p\[$1\] class\=\"UNSTYLED\">$3<\/p\[$1\]>\n<p\[$5\] class\=\"UNSTYLED\">/sgi;
		

		if($frontmatter =~ m/(Public interest statement)/sgi)
		{
			$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)\] class\=\"dummy\">About the authors\:?<\/b\[\3\]><\/p\[\1\]>(.*?)<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)\] class\=\"dummy\">Public interest statement\:?/<BIOGRAPHY>\n<p\[$1\] class\=\"$2\"><b\[$3\] class\=\"dummy\">About the authors\:<\/b\[$3\]><\/p\[$1\]>$4<\/BIOGRAPHY>\n<p\[$5\] class\=\"$6\"><b\[$7\] class\=\"dummy\">Public interest statement\:/sgi;
			$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)\] class\=\"dummy\">About the author\:?<\/b\[\3\]><\/p\[\1\]>(.*?)<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)\] class\=\"dummy\">Public interest statement\:?/<BIOGRAPHY>\n<p\[$1\] class\=\"$2\"><b\[$3\] class\=\"dummy\">About the author\:<\/b\[$3\]><\/p\[$1\]>$4<\/BIOGRAPHY>\n<p\[$5\] class\=\"$6\"><b\[$7\] class\=\"dummy\">Public interest statement\:/sgi;
		}
		else
		{
			$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)\] class\=\"dummy\">About the authors\:?<\/b\[\3\]><\/p\[\1\]>(.*?)$/<BIOGRAPHY>\n<p\[$1\] class\=\"$2\"><b\[$3\] class\=\"dummy\">About the authors\:<\/b\[$3\]><\/p\[$1\]>$4<\/BIOGRAPHY>/si;
			$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)\] class\=\"dummy\">About the author\:?<\/b\[\3\]><\/p\[\1\]>(.*?)$/<BIOGRAPHY>\n<p\[$1\] class\=\"$2\"><b\[$3\] class\=\"dummy\">About the author\:<\/b\[$3\]><\/p\[$1\]>$4<\/BIOGRAPHY>/si;
			$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">About the author\:?<\/p\[\1\]>(.*?)$/<BIOGRAPHY>\n<p\[$1\] class\=\"$2\">About the author\:<\/p\[$1\]>$3<\/BIOGRAPHY>/si;
			$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">About the authors\:?<\/p\[\1\]>(.*?)$/<BIOGRAPHY>\n<p\[$1\] class\=\"$2\">About the authors\:<\/p\[$1\]>$3<\/BIOGRAPHY>/si;
		}
		
		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<BIOGRAPHY>(.*?)<\/BIOGRAPHY>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"BIO-PARA\">/gi;
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)] class\=\"dummy\">About the author/<p\[$1\] class\=\"BIO-TITLE\"><b\[$3] class\=\"dummy\">About the author/gi;
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">About the author/<p\[$1\] class\=\"BIO-TITLE\">About the author/gi;

				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;		
		
		$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)\] class\=\"dummy\">Public interest statement\:<\/b\[\3\]><\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"CISTATEMENT-TITLE\"><b\[$3\] class\=\"dummy\">Public interest statement\:<\/b\[$3\]><\/p\[$1\]>\n<p\[$4\] class\=\"CISTATEMENT\">/gi;
		$frontmatter=~s/<BIOGRAPHY>(.*?)<\/BIOGRAPHY>/<div class\=\"BIOGRAPHY\">$1<\/div>/sgi;
		
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"normal\"(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		if($Curr =~/JEL (codes?|Classifications?)?/sgi)
		{
			$Curr=~s/<b\[(\d+)\] class\=\"dummy\">JEL Classifications\:?<\/b\[\1\]>\;?\:? ?//sgi;
			$Curr=~s/<i\[(\d+)\] class\=\"dummy\">JEL Classifications\:?<\/i\[\1\]>\;?\:? ?//sgi;
			$Curr=~s/JEL Classifications\:? //sgi;
	
			$Curr=~s/<p\[(\d+)\] class\=\"normal\"><i\[(\d+)\] class\=\"dummy\">(.*?)<\/i\[\2\]><\/p\[\1\]>/<p\[$1\] class\=\"Jel_Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"jelclassification\">$3<\/p\[\1\]>/sgi;
			$Curr=~s/<p\[(\d+)\] class\=\"normal\"><b\[(\d+)\] class\=\"dummy\">(.*?)<\/b\[\2\]><\/p\[\1\]>/<p\[$1\] class\=\"Jel_Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"jelclassification\">$3<\/p\[\1\]>/sgi;
			$Curr=~s/<p\[(\d+)\] class\=\"normal\">(.*?)<\/p\[\1\]>/<p\[$1\] class\=\"Jel_Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"jelclassification\">$2<\/p\[\1\]>/sgi;
			$Curr=~s/<p\[(\d+)\] class\=\"Jel_Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"jelclassification\">(.*?)<\/p\[\1\]>/<p\[$1\] class\=\"Jel_Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"jelclassification\"><kwd>$2<\/kwd><\/p\[\1\]>/sgi;
			
			
			if($Curr =~ m/\, /i)
			{
			$Curr=~s/\, /<\/kwd><FMSEP>\, <\/FMSEP><kwd>/sgi;
			}
			elsif($Curr =~ m/\; /i)
			{
				if($pubname=~/^(ASP)$/)
				{
					$Curr=~s/\; /<\/kwd><FMSEP>\, <\/FMSEP><kwd>/sgi;
				}
				else
				{
					$Curr=~s/\; /<\/kwd><FMSEP>\; <\/FMSEP><kwd>/sgi;
				}
			}
			
			$Curr=~s/\.<\/kwd>/<\/kwd>/gi;
		
		}	
			

		if($Curr =~/(Subject|AMS|MSC) (Code|Classification)s?/si)
		{
		
			$Curr=~s/<\/?p\b[^><]*>//sgi;
			$Curr = '<p class="keyword-subclass" data-element="kwd-group">'.$Curr.'</p>';
			$Curr=~s/<\/?i\[(\d+)\]( class\=\"dummy\")?>//sgi;
			$Curr=~s/(<\/b\[\d+\]>)([^<>]+)<\/p>/$1<kwd>$2<\/kwd><\/p>/sgi;
			

			$Curr=~s/<p class="keyword-subclass" data-element="kwd-group">\s*<b\[(\d+)\] class="dummy">(.*?)<\/b\[\1\]>/<p class="keyword-subclass" data-element="kwd-group"><span class="Keywordtext" data-element="title">$2<\/span>/si;
		
			
			if($Curr =~ m/\, /i)
			{
			$Curr=~s/\, /<\/kwd><FMSEP>\, <\/FMSEP><kwd>/sgi;
			}
			elsif($Curr =~ m/\; /i)
			{
				if($pubname=~/^(ASP)$/)
				{
					$Curr=~s/\; /<\/kwd><FMSEP>\, <\/FMSEP><kwd>/sgi;
				}
				else
				{
					$Curr=~s/\; /<\/kwd><FMSEP>\; <\/FMSEP><kwd>/sgi;
				}
			}
			
			$Curr=~s/\.<\/kwd>/<\/kwd>/gi;
			$Curr=~s/<\/span>(\s*)((?:(?!<\/?kwd>).)*?)<\/kwd>/<\/span><kwd>$2<\/kwd>/si;
			$Curr=~s/<kwd>(?!.*<\/?kwd>)(.*?)<\/p>$/<kwd>$1<\/kwd><\/p>/si;
		}	

	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;

}

sub FMAFFILIATION
{
	


	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"Affiliation\">(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		my $paraid="$1";
		
		$Curr=~s/<i\[(\d+)\] class\=\"dummy\">//gi;
		$Curr=~s/<\/i\[(\d+)\]>//gi;
		$Curr=~s/<b\[(\d+)\] class\=\"dummy\">//gi;
		$Curr=~s/<\/b\[(\d+)\]>//gi;
		$Curr=~s/<br><\/br><br><\/br>/<br><\/br>/gi;
		$Curr=~s/<br><\/br><br><\/br>/<br><\/br>/gi;
		$Curr=~s/<br><\/br><br><\/br>/<br><\/br>/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"Affiliation\"><sup\[(\d+)] class\=\"dummy\">(\d+)<\/sup\[\2\]>\-\s*/<p\[$1\] class\=\"Affiliation\"><sup\[$2] class\=\"dummy\">$3<\/sup\[$2\]>/gi;
		#print ERR "$Curr\n";
		$Curr=~s/(\; |\, | and ?|<br><\/br>)<sup\[(\d+)\] class\=\"dummy\">(\d+)<\/sup\[\2\]>/<\/p\[$paraid\]>\n<p\[$paraid\] class\=\"Affiliation\"><sup\[$2\] class\=\"dummy\">$3<\/sup\[$2\]>/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"Affiliation\">(\d+)([a-zA-Z])/<p\[$1\] class\=\"Affiliation\"><sup\[000\] class\=\"dummy\">$2<\/sup\[000\]>$3/gi;
		
		if($Curr =~ m/<p\[(\d+)\] class\=\"Affiliation\"> ?(\d+)(\,|\.) /si)
		{
			$Curr=~s/<p\[(\d+)\] class\=\"Affiliation\"> ?(\d+)(\,|\.) /<p\[$1\] class\=\"Affiliation\"><sup\[000\] class\=\"dummy\">$2<\/sup\[000\]>/gi;
			$Curr=~s/(\.|\;) (1|2|3|4|5|6|7|8|9|10|11|12|13|14)(\,|\.) /<\/p\[$paraid\]>\n<p\[$paraid\] class\=\"Affiliation\"><sup\[000\] class\=\"dummy\">$2<\/sup\[000\]>/gi;
			$Curr=~s/(\.|\;) and (1|2|3|4|5|6|7|8|9|10|11|12|13|14)(\,|\.) /<\/p\[$paraid\]>\n<p\[$paraid\] class\=\"Affiliation\"><sup\[000\] class\=\"dummy\">$2<\/sup\[000\]>/gi;
		}
		
		
		$Curr=~s/<p(\[\d+\]) class\=\"Affiliation\">(<sup(\[\d+\]) class\=\"dummy\">[^><]+<\/sup\3>\s*These authors contributed)/<p$1 class\=\"AUTHORFOOTNOTE\">$2/gi;
		
		#print ERR "$Curr\n\n";
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;		
	#exit;
	
	$frontmatter=~s/<p\[(\d+)\] class\=\"CAUTHOR\">/<CAUTHOR\/><p\[$1\] class\=\"Affiliation\">/gi;
	
	
			
	



	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"AuthorNotes\">(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/<i\[(\d+)\] class\=\"dummy\">//gi;
		$Curr=~s/<i>//gi;
		$Curr=~s/<\/i\[(\d+)\]>//gi;
		$Curr=~s/<\/i>//gi;

		$Curr=~s/<b\[(\d+)\] class\=\"dummy\">//gi;
		$Curr=~s/<b>//gi;
		$Curr=~s/<\/b\[(\d+)\]>//gi;
		$Curr=~s/<\/b>//gi;
		
		
		#$Curr=~s/<p\[(\d+)\] class\=\"AuthorNotes\"><sup\[(\d+)\] class\=\"dummy\">(\d+)\.?<\/sup\[\2\]>\.?/<p\[$1\] class\=\"AuthorNotes\"><span class\=\"FMLABEL\" data\-element\=\"label\">$3<\/span>/gi;
		
		#$Curr=~s/<p\[(\d+)\] class\=\"AuthorNotes\">(\d+)\.? ?/<p\[$1\] class\=\"AuthorNotes\"><span class\=\"FMLABEL\" data\-element\=\"label\">$2<\/span>/gi;
		

		#$Curr=~s/<p\[(\d+)\] class\=\"AuthorNotes\"><sup\[(\d+)\] class\=\"dummy\"><i\[(\d+)\] class="dummy">(\d+)\.?<\/i\[\3\]>\.?<\/sup\[\2\]>/<p\[$1\] class\=\"AuthorNotes\"><span class\=\"FMLABEL\" data\-element\=\"label\">$4<\/span>/gi;

		$Curr=~s/<p\[(\d+)\] class\=\"AuthorNotes\">(.*?)<\/p\[\1\]>/<p\[$1\] class\=\"AuthorNotes\"><AFFTEMP>$2<\/AFFTEMP><\/p\[$1\]>/sgi;
		
		
		$Curr=~s/<AFFTEMP>(<span class\=\"FMLABEL\" data\-element\=\"label\">(.*?)<\/span>)/$1<AFFTEMP>/sgi;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;


	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"Affiliation\">(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/<p\[(\d+)\] class\=\"Affiliation\"> /<p\[$1\] class\=\"Affiliation\">/gi;
		$Curr=~s/<i\[(\d+)\] class\=\"dummy\">//gi;
		$Curr=~s/<i>//gi;
		$Curr=~s/<\/i\[(\d+)\]>//gi;
		$Curr=~s/<\/i>//gi;

		$Curr=~s/<b\[(\d+)\] class\=\"dummy\">//gi;
		$Curr=~s/<b>//gi;
		$Curr=~s/<\/b\[(\d+)\]>//gi;
		$Curr=~s/<\/b>//gi;
		$Curr=~s/ (\w+)\;<\/p\[(\d+)\]>/ $1<\/p\[$2\]>/gi;
		
		
		$Curr=~s/<p\[(\d+)\] class\=\"Affiliation\"><sup\[(\d+)\] class\=\"dummy\">(\d+)\.?<\/sup\[\2\]>\.?/<p\[$1\] class\=\"Affiliation\"><span class\=\"FMLABEL\" data\-element\=\"label\">$3<\/span>/gi;
		
		$Curr=~s/<p\[(\d+)\] class\=\"Affiliation\">(\d+)\.? /<p\[$1\] class\=\"Affiliation\"><span class\=\"FMLABEL\" data\-element\=\"label\">$2<\/span>/gi;
		

		$Curr=~s/<p\[(\d+)\] class\=\"Affiliation\"><sup\[(\d+)\] class\=\"dummy\"><i\[(\d+)\] class="dummy">(\d+)\.?<\/i\[\3\]>\.?<\/sup\[\2\]>/<p\[$1\] class\=\"Affiliation\"><span class\=\"FMLABEL\" data\-element\=\"label\">$4<\/span>/gi;

		$Curr=~s/<p\[(\d+)\] class\=\"Affiliation\">(.*?)<\/p\[\1\]>/<p\[$1\] class\=\"Affiliation\"><AFFTEMP>$2<\/AFFTEMP><\/p\[$1\]>/sgi;
		
		
		$Curr=~s/<AFFTEMP>(<span class\=\"FMLABEL\" data\-element\=\"label\">(.*?)<\/span>)/$1<AFFTEMP>/sgi;
		
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;
	




	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<AFFTEMP>(.*?)<\/AFFTEMP>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/<AFFTEMP>Current Address\: ?/<AFFTEMP>/gi;
		$Curr=~s/\.\, /DUMMYDOTINTEGRA\, /gi;
		$Curr=~s/(\, |\. )/<\/AFFTEMP><FMSEP>$1<\/FMSEP><AFFTEMP>/gi;
		$Curr=~s/<AFFTEMP> /<AFFTEMP>/g;
		$Curr=~s/(\.|\,)<\/AFFTEMP>/<\/AFFTEMP><FMSEP>$1<\/FMSEP>/g;
		$Curr=~s/ (Province|City)<\/AFFTEMP><FMSEP>/<\/AFFTEMP><FMSEP> $1/gi;
		$Curr=~s/<\/AFFTEMP><FMSEP>\, <\/FMSEP><AFFTEMP>and /, and /gi;
		#print ERR "$Curr\n";
		#$Curr=~s/(\,? |\-)((\d{3}) (\d+))<\/AFFTEMP>/<\/AFFTEMP><FMSEP>$1<\/FMSEP><POSTALCODE>$2<\/POSTALCODE>/g;
		#$Curr=~s/(\,? |\-)((\d{2})(\d+))<\/AFFTEMP>/<\/AFFTEMP><FMSEP>$1<\/FMSEP><POSTALCODE>$2<\/POSTALCODE>/g;

		#$Curr=~s/(\s*)(\d+)<\/AFFTEMP><FMSEP>-<\/FMSEP><POSTALCODE>/<\/AFFTEMP><FMSEP>$1<\/FMSEP><POSTALCODE>$2-/g;
		
		#$Curr=~s/(\s*\(<EMAIL>(\w+)\@(\w+)\.(\w+)\.?(\w+)?\.?(\w+)?<\/EMAIL>\))<\/AFFTEMP>/<\/AFFTEMP>$1/sgi;
		$Curr=~s/(\s*\(<EMAIL>(?:(?:[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\]))<\/EMAIL>(?:(?:(?:\,|\;)\s*<EMAIL>(?:(?:[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\]))<\/EMAIL>)+)?\))(<\/AFFTEMP>)/$2$1/sgi;
		$Curr=~s/DUMMYDOTINTEGRA/\./gi;
		$Curr=~s/<\/AFFTEMP><FMSEP>\, <\/FMSEP><AFFTEMP>(Ltd.?)<\/AFFTEMP>/\, $1<\/AFFTEMP>/gi;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;
	#exit;
	
	#print ERR "$frontmatter";
	#exit;

	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<AFFTEMP>(.*?)<\/AFFTEMP>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		if($Curr =~ m/(District|Campus|road)/si)
		{
			$Curr=~s/<AFFTEMP>(.*?)<\/AFFTEMP>/<addr\-line>$1<\/addr\-line>/si;
		}
		
		
		#print ERR "$Curr\n";
			
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;		
	
	
	
	#exit;

	
	my @AFFTEMPVALUE;
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<AFFTEMP>(.*?)<\/AFFTEMP>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		push(@AFFTEMPVALUE, "$1");				
		
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;
	
	
	
	#print ERR "@AFFTEMPVALUE\n";
	#exit;
	
	my $client = MongoDB::MongoClient->new(host => 'localhost', port => 27017);
	my $db = $client->get_database("Integra_DB");
	
	
	
	
	
	####CNY DB
	my $table_call = $db->get_collection('countries');
	my $tablevalue1 = $table_call->find({"name" => {'$in' => [@AFFTEMPVALUE]}});
	my $tablevalue11 = $table_call->find({"sortname" => {'$in' => [@AFFTEMPVALUE]}});
	my $tablevalue111 = $table_call->find({"sortname1" => {'$in' => [@AFFTEMPVALUE]}});
	
	my $cnydata="";
	while (my $finalvalue1 = $tablevalue1->next) {
		$cnydata .= Dumper $finalvalue1;
	}	
	
	

	$Line=$cnydata;	
	$Variable="";	
	while($Line =~/\'name\'\s*\=\>\s*\'(.*?)\'\,?/gi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		my $cny="$1";
		
		$frontmatter=~s/<AFFTEMP>$cny<\/AFFTEMP>/<country>$cny<\/country>/gi;
		
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$cnydata = $Variable;	

	my $cnydata1="";
	while (my $finalvalue11 = $tablevalue11->next) {
		$cnydata1 .= Dumper $finalvalue11;
	}	
	

	my $cnydata11="";
	while (my $finalvalue111 = $tablevalue111->next) {
		$cnydata11 .= Dumper $finalvalue111;
	}	

	
	$Line=$cnydata1;	
	$Variable="";	
	while($Line =~/\'sortname\'\s*\=\>\s*\'(.*?)\'\,?/gi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		my $cny="$1";
		
		$frontmatter=~s/<AFFTEMP>$cny<\/AFFTEMP>/<country>$cny<\/country>/gi;
		
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$cnydata1 = $Variable;		

	
	
	$Line=$cnydata11;	
	$Variable="";	
	while($Line =~/\'sortname1\'\s*\=\>\s*\'(.*?)\'\,?/gi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		my $cny="$1";
		
		$frontmatter=~s/<AFFTEMP>$cny<\/AFFTEMP>/<country>$cny<\/country>/gi;
		
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$cnydata11 = $Variable;		


	#print ERR "$cnydata1\n";
	#exit;
	
	
	####///CNY DB


	####universities DB
	my $table_call2 = $db->get_collection('UNIVERSITIES');
	my $tablevalue2 = $table_call2->find({"uname" => {'$in' => [@AFFTEMPVALUE]}});

	my $udata="";
	while (my $finalvalue2 = $tablevalue2->next) {
		$udata .= Dumper $finalvalue2;
	}	
	
	#print ERR "$udata";
	#exit;
	
	$Line=$udata;	
	$Variable="";	
	while($Line =~/\'uname\'\s*\=\>\s*\'(.*?)\'\,?/gi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		my $cny="$1";
		
		$frontmatter=~s/<AFFTEMP>$cny<\/AFFTEMP>/<institution>$cny<\/institution>/gi;
		
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$udata = $Variable;		
			
	
	
	####///universities DB
	
	
	
	####cities DB
	my $table_call3 = $db->get_collection('cities');
	my $tablevalue3 = $table_call3->find({"name" => {'$in' => [@AFFTEMPVALUE]}});

	my $citydata="";
	while (my $finalvalue3 = $tablevalue3->next) {
		$citydata .= Dumper $finalvalue3;
	}	

	
	$Line=$citydata;	
	$Variable="";	
	while($Line =~/\'name\'\s*\=\>\s*\'(.*?)\'\,?/gi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		my $cny="$1";
		
		$frontmatter=~s/<AFFTEMP>$cny<\/AFFTEMP>/<city>$cny<\/city>/g;
		
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$citydata = $Variable;		
		


	####//cities DB


	####states DB
			
	my $table_call4 = $db->get_collection('states');
	my $tablevalue4 = $table_call4->find({"name" => {'$in' => [@AFFTEMPVALUE]}});
	


	my $statedata="";
	while (my $finalvalue4 = $tablevalue4->next) {
		$statedata .= Dumper $finalvalue4;
	}	
	
	$Line=$statedata;	
	$Variable="";	
	while($Line =~/\'name\'\s*\=\>\s*\'(.*?)\'\,?/gi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		my $cny="$1";
		
		
		
		$frontmatter=~s/<AFFTEMP>$cny<\/AFFTEMP>/<state>$cny<\/state>/g;
		
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$citydata = $Variable;		
				
	
	
	####///STATES DB
	
	
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<AFFTEMP>(.*?)<\/AFFTEMP>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		if($Curr =~ m/(Department|Center|Institute|Centre|School|Dept|Laboratory|Laboratoire|Faculty|Universidad|Facultad|Research|Partners|Administration|Program of|Advisory Unit|unit|Council|Clinical|Servicio|Service de|Ceref|Public Health|Tecnologico|Pediatrics?|Division|chirurgie|Desenvolvimento)/si)
		{
			$Curr=~s/<AFFTEMP>(.*?)<\/AFFTEMP>/<department>$1<\/department>/i;
		}
		elsif($Curr =~ m/(University|universitaire|Society of|Universit|Instituto|Institute|College|Hospital|Technology| Sciences |Society|Medical Center|Division of|Investigaci|Haute Ecole Louvain|Medicina|Institut|Immunology)/si)
		{
			$Curr=~s/<AFFTEMP>(.*?)<\/AFFTEMP>/<institution>$1<\/institution>/i;
		}
		elsif($Curr =~ m/<AFFTEMP>(UK|U\.K\.?)<\/AFFTEMP>/si)
		{
			$Curr=~s/<AFFTEMP>(UK|U\.K\.?)<\/AFFTEMP>/<country>UK<\/country>/i;
		}
		elsif($Curr =~ m/<AFFTEMP>(USA|U\.S\.A\.?)<\/AFFTEMP>/si)
		{
			$Curr=~s/<AFFTEMP>(USA|U\.S\.A\.?)<\/AFFTEMP>/<country>USA<\/country>/i;
		}
		elsif($Curr =~ m/(E\-?mail|(\w+)\@)/si)
		{
			$Curr=~s/<AFFTEMP>(.*?)<\/AFFTEMP>/<FMAFFEMAIL>$1<\/FMAFFEMAIL>/i;
			#print ERR "$Curr\n";
		}
		else
		{
			#print ERR "$Curr\n";
		}

		
		
		
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;
	

	$frontmatter=~s/([A-Z])<EMAIL>/<EMAIL>$1/gi;
	
	
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"Affiliation\">(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		
		$Curr=~s/<department>(.*?)<\/department><FMSEP>(.*?)<\/FMSEP><department>(.*?)<\/department>/<department>$1<\/department><FMSEP>$2<\/FMSEP><institution>$3<\/institution>/sgi;
		#print ERR "$Curr\n\n";
		
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;		
	#exit;

	#### STATE
	my $table_call9 = $db->get_collection('states');
	my $tablevalue9 = $table_call9->distinct('name');
	my $finalvalue9 = Dumper $tablevalue9;
	$finalvalue9=~s/^(.*?)\'\_docs\' \=\>\s*\[(.*?)\](.*?)$/$2/sg;
	$finalvalue9=~s/\s*\'/\'/g;
	$finalvalue9=~s/\'\,\'/<\/STATE>\n<STATE>/g;
	$finalvalue9=~s/^\'/<STATE>/g;
	$finalvalue9=~s/\'\s*/\'/g;
	$finalvalue9=~s/\'$/<\/STATE>/i;
	$finalvalue9=~s/<STATE>\s*<\/STATE>//gi;

	
	##### /STATE
	
	#### CITY
	my $table_call10 = $db->get_collection('cities');
	my $tablevalue10 = $table_call10->distinct('name');
	my $finalvalue10 = Dumper $tablevalue10;
	$finalvalue10=~s/^(.*?)\'\_docs\' \=\>\s*\[(.*?)\](.*?)$/$2/sg;
	$finalvalue10=~s/\s*\'/\'/g;
	$finalvalue10=~s/\'\,\'/<\/CITY>\n<CITY>/g;
	$finalvalue10=~s/^\'/<CITY>/g;
	$finalvalue10=~s/\'\s*/\'/g;
	$finalvalue10=~s/\'$/<\/CITY>/i;
	$finalvalue10=~s/<CITY>\s*<\/CITY>//gi;
	
	##### /CITY		

	#### CNY
	my $table_call11 = $db->get_collection('countries');
	my $tablevalue11 = $table_call11->distinct('name');
	my $finalvalue11 = Dumper $tablevalue11;
	$finalvalue11=~s/^(.*?)\'\_docs\' \=\>\s*\[(.*?)\](.*?)$/$2/sg;
	$finalvalue11=~s/\s*\'/\'/g;
	$finalvalue11=~s/\'\,\'/<\/CNY>\n<CNY>/g;
	$finalvalue11=~s/^\'/<CNY>/g;
	$finalvalue11=~s/\'\s*/\'/g;
	$finalvalue11=~s/\'$/<\/CNY>/i;
	$finalvalue11=~s/<CNY>\s*<\/CNY>//gi;
	
	##### /CNY		

	#print ERR "$finalvalue10\n";
			
	
	#print ERR "$finalvalue11\n";
	#exit;
	
	
	while($finalvalue9=~/<STATE>(.*?)<\/STATE>/g)
	{
		my $state="$1";
		#print "$state\n";
		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<AFFTEMP>(.*?)<\/AFFTEMP>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			
			#print ERR "$Curr\n\n";
			
			$Curr=~s/( |<AFFTEMP>)(\Q$state\E)(\,| |\.|\;)/$1<state>$state<\/state>$3/gi;
			#$Curr=~s/(\,? |\-)((\d{2})(\d+))<\/AFFTEMP>/<\/AFFTEMP><FMSEP>$1<\/FMSEP><POSTALCODE>$2<\/POSTALCODE>/g;
			
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;
	}



	#print ERR "$finalvalue10\n";
	#exit;


	while($finalvalue10=~/<CITY>(.*?)<\/CITY>/g)
	{
		my $city="$1";
		#print "$state\n";
		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<AFFTEMP>(.*?)<\/AFFTEMP>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			
			#print ERR "$Curr\n\n";
			
			$Curr=~s/( |<AFFTEMP>)(\Q$city\E)(\,| |\.|\;)/$1<city>$city<\/city>$3/g;
			#$Curr=~s/(\,? |\-)((\d{2})(\d+))<\/AFFTEMP>/<\/AFFTEMP><FMSEP>$1<\/FMSEP><POSTALCODE>$2<\/POSTALCODE>/g;
			
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;
	}



	while($finalvalue11=~/<CNY>(.*?)<\/CNY>/g)
	{
		my $city="$1";
		#print "$state\n";
		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<AFFTEMP>(.*?)<\/AFFTEMP>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			
			#print ERR "$Curr\n\n";
			
			$Curr=~s/(\Q$city\E)(\,| |\.|\;)/<country>$city<\/country>$3/g;
			#$Curr=~s/(\,? |\-)((\d{2})(\d+))<\/AFFTEMP>/<\/AFFTEMP><FMSEP>$1<\/FMSEP><POSTALCODE>$2<\/POSTALCODE>/g;
			
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;
	}

	

	#print ERR "$frontmatter\n\n";
	
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<AFFTEMP>(.*?)<\/AFFTEMP>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		
		$Curr=~s/<\/state> State<\/AFFTEMP>/<\/state><\/AFFTEMP>/gi;
		$Curr=~s/<AFFTEMP><(state|city|country)>(.*?)<\/\1><\/AFFTEMP>/<$1>$2<\/$1>/gi;
		
		#print ERR "$Curr\n\n";
		
		#$Curr=~s/(\,? |\-)((\d{3}) (\d+))<\/AFFTEMP>/<\/AFFTEMP><FMSEP>$1<\/FMSEP><POSTALCODE>$2<\/POSTALCODE>/g;
		#$Curr=~s/(\,? |\-)((\d{2})(\d+))<\/AFFTEMP>/<\/AFFTEMP><FMSEP>$1<\/FMSEP><POSTALCODE>$2<\/POSTALCODE>/g;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;		
	
	
	$frontmatter=~s/<CAUTHOR\/><p\[(\d+)\] class\=\"Affiliation\">/<p\[$1\] class\=\"CAUTHOR\">/g;
	
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"CAUTHOR\">(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		
		$Curr=~s/<(department|AFFTEMP|FMSEP)>//g;
		$Curr=~s/<\/(department|AFFTEMP|FMSEP)>//g;
		$Curr=~s/<city>Minas<\/city> Gerais/<state>Minas Gerais<\/state>/gi;
		#print ERR "$Curr\n\n";
		
		#placing bold tag in Author for correspondence
		$Curr=~s/(<p[^<>]*>)\s*(<sup[^<>]*>[^<>]*<\/sup[^<>]*>)?\s*(Author for correspondence\:|Address for correspondence\:|Corresponding author\:)/$1$2<b>$3<\/b>/sig;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;
	#exit;

	
	#print ERR "$frontmatter";
	#exit;
	
	$frontmatter=~s/<department>(<sup\[(\d+)\] class\=\"dummy\">(\w+)<\/sup\[\1\]>)/$1<department>/sgi;
	

	if($frontmatter !~ m/<div class\=\"abstract\"/si)
	{
		if($frontmatter =~ m/<\/p\[(\d+)\]>\s*<p\[(\d+)\] class\=\"Keywords\"/si)
		{
			my $paraid="$1";
			$frontmatter=~s/<p\[$paraid\] class\=\"normal\">(.*?)<\/p\[$paraid\]>/<div class\="abstract\" data\-element\=\"abstract\">\n<p\[$paraid\] class\=\"Abstractpara\">$1<\/p\[$paraid\]>\n<\/div>/si;
			
			#print ERR "$frontmatter\n";
			#exit;
		}
	}
	
	
	
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"Affiliation\">(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		
		$Curr=~s/\((\w+)<\/department><FMSEP>\, <\/FMSEP><AFFTEMP>(\w+)\)<\/AFFTEMP>/\($1\, $2\)<\/department>/gi;
		$Curr=~s/<AFFTEMP>T\&\#x000F8\;nsberg<\/AFFTEMP>/<city>T\&\#x000F8\;nsberg<\/city>/g;
		#print ERR "$Curr\n\n";
		
		
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;		
	
	#exit;

	$frontmatter=~s/<AFFTEMP><city>(.*?)<\/city>/<city>$1<\/city><AFFTEMP>/g;
	$frontmatter=~s/<state>(.*?)<\/state><\/AFFTEMP>/<\/AFFTEMP><state>$1<\/state>/g;
	$frontmatter=~s/<AFFTEMP>(\. )<\/AFFTEMP>/<FMSEP>$1<\/FMSEP>/g;
	$frontmatter=~s/<AFFTEMP>((P\. ?M\. ?B\. )?(\d{4})\-? ?(\d+)?)<\/AFFTEMP>/<postalcode>$1<\/postalcode>/g;
	$frontmatter=~s/<AFFTEMP>(\d{4}\-? ?\d+?)(\,| |\.|\;)/<postalcode>$1<\/postalcode><AFFTEMP>$2/g;
	$frontmatter=~s/<AFFTEMP> /<FMSEP> <\/FMSEP><AFFTEMP>/g;
	
	$frontmatter=~s/<EMAIL>(.*?)<\/EMAIL>/<email>$1<\/email>/gi;
	$frontmatter=~s/\.<\/email>/<\/email>\./g;

	
	
	
	$frontmatter=~s/<AFFTEMP>/<span class\=\"UNSTYLED\-S\">/gi;
	$frontmatter=~s/<\/AFFTEMP>/<\/span>/gi;
	#$frontmatter=~s/<AFFTEMP>/<span class\=\"UNSTYLED\-S\">/gi;
	#$frontmatter=~s/<\/AFFTEMP>/<\/span>/gi;

	
	#$frontmatter=~s/<p\[(\d+)\] class\=\"ArticleTitleHead\"(.*?)<\/p\[\1\]>/$fm1\n<p\[$1\] class\=\"ArticleTitleHead\"$2<\/p\[$1\]>\n<!--<\/title-group>-->/i;
	#$frontmatter=~s/<div class\=\"abstract\" /$fm2\n<div class\=\"abstract\" /gi;
	
	my $affcount=0;
	while($frontmatter =~ m/<p\[(\d+)\] class\=\"Affiliation\">/gi)
	{
		$affcount++;
		$frontmatter=~s/<p\[(\d+)\] class\=\"Affiliation\">/<p\[$1\] class\=\"Affiliation\" data\-element\=\"aff\" data\-attribs\-id\=\"aff\-$affcount\">/i;
		
	
	}
	
	$frontmatter=~s/<p\[(\d+)\] class\=\"PAuthorGroup\">/<p\[$1\] class\=\"AuthorGroup\" data\-element\=\"contrib\-group\" data\-attribs\-content\-type\=\"authors\">/sgi;

	$frontmatter=~s/<\/AFFTEMP><FMSEP>(\, )<\/FMSEP><AFFTEMP>/$1/g;
	$frontmatter=~s/<AFFTEMP>/<addr\-line>/g;
	$frontmatter=~s/<\/AFFTEMP>/<\/addr\-line>/g;
	$frontmatter=~s/<institution>(.*?)<\/institution><FMSEP>\, <\/FMSEP><institution>/<department>$1<\/department><FMSEP>\, <\/FMSEP><institution>/g;
	#$frontmatter=~s/<Author>//gi;
	$frontmatter=~s/<AFFID><\/AFFID>//g;
	$frontmatter=~s/<AFFID>\*(\d+)<\/AFFID>/<AFFID>\*<\/AFFID><AFFID>$1<\/AFFID>/g;
	$frontmatter=~s/<country>(.*?)<\/country><FMSEP>\, <\/FMSEP><country>(.*?)<\/country>/<city>$1<\/city><FMSEP>\, <\/FMSEP><country>$2<\/country>/g;
	#print ERR "$frontmatter";
	#exit;

	
	##Start: Domain tag updated by Selvam####
	if($pubname=~/(^HINDAWI$)/i)
	{
	$Line=$frontmatter;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"Affiliation\"([^<>]+)?>(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';

		if($Curr!~/<span class=\"DOMAIN\"> ?Enter Domain name here<\/span>/si)
		{
		$Curr=~s/<p\[(\d+)\] class\=\"Affiliation\"([^<>]+)?>(.*?)<\/p\[\1\]>/<p\[$1\] class\=\"Affiliation\"$2>$3 <span class="DOMAIN"> Enter Domain name here<\/span><\/p\[$1\]>/si;
		}
		
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$frontmatter = $Variable;
	}
	##End: Domain tag updated by Selvam####
	
	#$frontmatter=~s/<\/department><FMSEP>\, <\/FMSEP><addr\-line>(.*?)<\/addr\-line>/\, $1<\/department>/gi;
	#$frontmatter=~s/<\/department><FMSEP>\, <\/FMSEP><department>/\, /gi;
	
}




sub FMAUAFF
{
		
	if($frontmatter =~ m/<p\[(\d+)\] class="AuthorGroup" (.*?)<\/p\[\1\]>/si)
	{
		my $AUGRP="$2";
		
		if($AUGRP!~m/\*/)
		{

			$Line=$frontmatter;	
			$Variable="";	
			while($Line =~/<p\[(\d+)\] class="AuthorGroup" (.*?)<\/p\[\1\]>/sgi)	
			{	
				$PreMatch = $`;
				$Curr = $&;
				$Line = $';
				
				if($Curr =~ m/<\/Author><\/p\[(\d+)\]>/i)
				{
					$Curr=~s/<\/Author><\/p\[(\d+)\]>/<\/Author><span class\=\"Corresp\" data\-element\=\"email\">$cemail<\/span><\/p\[$1\]>/i;
				}
		
				
			$Variable .=$PreMatch .$Curr;	
			}	
			$Variable .=$Line;	
			$frontmatter = $Variable;			
		}
		else
		{
			
			$Line=$frontmatter;	
			$Variable="";	
			while($Line =~/<Author>(.*?)<\/Author>/sgi)	
			{	
				$PreMatch = $`;
				$Curr = $&;
				$Line = $';

				if($Curr =~ m/\*/i)
				{
					$Curr=~s/<AFFID>/<span class\=\"Corresp\" data\-element\=\"email\">$cemail<\/span><AFFID>/i;
					$Curr=~s/<Author>/<CR\/><Author>/i;
							$Curr=~s/\s*<AFFID>\*<\/AFFID>//i;
				}
		
				
			$Variable .=$PreMatch .$Curr;	
			}	
			$Variable .=$Line;	
			$frontmatter = $Variable;
		}
	}	
	
}

sub FMFINALCLEANUP
{

	my $fmelements="Author\|SNM\|INITS\|AFFID\|SEP\|FMSEP\|institution\|department\|city\|POSTALCODE\|country\|state\|addr\-line\|ABSTIT";
	
	$frontmatter=~s/<($fmelements)>/<span xclass\=\"$1\" data\-element\=\"$1\">/gi;
	$frontmatter=~s/<span xclass\=\"([a-z])/<span class\=\"\U$1\E/g;
	$frontmatter=~s/<span xclass\=\"([^\"]+)\"/<span class\=\"$1\"/gi;
	$frontmatter=~s/<span class\=\"FMSEP\" data\-element\=\"FMSEP\">/<span class\=\"FMSEP\">/gi;
	$frontmatter=~s/<\/($fmelements)>/<\/span>/gi;
	$frontmatter=~s/(<span class=\"AFFID\" data\-element=\"AFFID\">\d+)\#(((?:(?!<\/span>).)*?)<\/span>)/$1$2<span class=\"AFNID\"><sup>\#<\/sup><\/span>/gi;

		$frontmatter=~s/<(RECD\-month|RECD\-day|RECD\-year|ACC\-month|ACC\-day|ACC\-year|ONL\-month|ONL\-day|ONL\-year|DOITITLE|ADOINUMBER)>/<span class\=\"$1\">/sgi;	
		$frontmatter=~s/<\/(RECD\-month|RECD\-day|RECD\-year|ACC\-month|ACC\-day|ACC\-year|ONL\-month|ONL\-day|ONL\-year|DOITITLE|ADOINUMBER)>/<\/span>/sgi;

		$frontmatter=~s/<h1 class\=\"heading1\" data\-type\=\"([^\"]+)\">(.*?)<\/h1>/<p\[000\] class\=\"Abstractpara\">$2<\/p\[000\]>/sgi;


		open(SCT, "<", "$serverpath/sections\.txt") or die print("$serverpath/sections\.txt NOT FOUND!!!");
		my $sctypes = <SCT>;
		close (SCT);
		

		$Line=$sctypes;	
		$Variable="";	
		while($Line =~/<sec type\=\"([^\"]+)\">(.*?)<\/sec>/sg)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $sctype="$1";
			my $sectypes="$2";
			
			$frontmatter=~s/<p\[(\d+)\] class\=\"Abstractpara\"><i\[(\d+)] class\=\"dummy\">($sectypes)\:?\.?<\/i\[\2\]><\/p\[\1\]>\s*<p\[(\d+)\] class\=\"Abstractpara\">/<p\[$4\] class\=\"Abstractpara\"><ABSTIT>$3\:<\/ABSTIT> /gi;
			
			$frontmatter=~s/<p\[(\d+)\] class\=\"Abstractpara\"><b\[(\d+)] class\=\"dummy\">($sectypes)\:?\.?<\/b\[\2\]><\/p\[\1\]>\s*<p\[(\d+)\] class\=\"Abstractpara\">/<p\[$4\] class\=\"Abstractpara\"><ABSTIT>$3\:<\/ABSTIT> /gi;
			
			$frontmatter=~s/<p\[(\d+)\] class\=\"Abstractpara\"><b\[(\d+)] class\=\"dummy\">($sectypes)\:?\.?<\/b\[\2\]><\/p\[\1\]>\s*<p\[(\d+)\] class\=\"Abstractpara\">/<p\[$4\] class\=\"Abstractpara\"><ABSTIT>$3\:<\/ABSTIT> /gi;
			
			$frontmatter=~s/<p\[(\d+)\] class\=\"Abstractpara\"><b\[(\d+)] class\=\"dummy\">($sectypes)\:?\.?<\/b\[\2\]><\/p\[\1\]>\s*<p\[(\d+)\] class\=\"Abstractpara\">/<p\[$4\] class\=\"Abstractpara\"><ABSTIT>$3\:<\/ABSTIT> /gi;
			
			$frontmatter=~s/<p\[(\d+)\] class\=\"Abstractpara\"><i\[(\d+)] class\=\"dummy\">($sectypes)\: (.*?)<\/i\[\2\]><\/p\[\1\]>/<p\[$1\] class\=\"Abstractpara\"><ABSTIT>$3\:<\/ABSTIT> $4<\/p\[$1\]>/gi;
			
			$frontmatter=~s/<p\[(\d+)\] class\=\"Abstractpara\"><b\[(\d+)] class\=\"dummy\">($sectypes)\:? ?<\/b\[\2\]>\:?( (.*?))<\/p\[\1\]>/<p\[$1\] class\=\"Abstractpara\"><ABSTIT>$3\:<\/ABSTIT> $4<\/p\[$1\]>/gi;
			
			
			$frontmatter=~s/<p\[(\d+)\] class\=\"Abstractpara\">($sectypes)\:? ?( (.*?))<\/p\[\1\]>/<p\[$1\] class\=\"Abstractpara\"><ABSTIT>$2\:<\/ABSTIT> $3<\/p\[$1\]>/gi;
			
			$frontmatter=~s/<p\[(\d+)\] class\=\"Abstractpara\">($sectypes)\: ?<\/p\[\1\]>/<p\[$1\] class\=\"Abstractpara\"><ABSTIT>$2\:<\/ABSTIT><\/p\[$1\]>/gi;
			
				
		#$Variable .=$PreMatch .$Curr;	
		}	
		#$Variable .=$Line;	
		#$_ = $Variable;
		
		my $sectypes="Background\/Aims\|Materials and Methods\|Results\|Conclusion\|Objectives?\|Methods?\|Conclusions?\|Backgrounds\|Background\|Objective\|Introduction\|Discussion";
		
		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<p\[(\d+)\] class\=\"Abstractpara\">(.*?)<\/p\[\1\]>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			
			my $paraid="$1";
			
			$Curr=~s/\. <b\[(\d+)] class\=\"dummy\">($sectypes)\:? ?<\/b\[\1\]>\:?/\.<\/p\[$paraid\]>\n<p\[$paraid\] class\=\"Abstractpara\"><ABSTIT>$2\:<\/ABSTIT> /gi;
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;

		$frontmatter=~s/<\/ABSTIT>\:/\:<\/ABSTIT>/gi;
		
		my $fmelements="Author\|SNM\|INITS\|AFFID\|SEP\|FMSEP\|institution\|department\|city\|POSTALCODE\|country\|state\|addr\-line\|ABSTIT\|FMAFFEMAIL";
		
		$frontmatter=~s/<($fmelements)>/<span xclass\=\"$1\" data\-element\=\"$1\">/gi;
		$frontmatter=~s/<span xclass\=\"([a-z])/<span class\=\"\U$1\E/g;
		$frontmatter=~s/<span xclass\=\"([^\"]+)\"/<span class\=\"$1\"/gi;
		$frontmatter=~s/<span class\=\"AFFID\" data\-element\=\"AFFID\">/<span class\=\"AFFID\">/ig;
		$frontmatter=~s/<span class\=\"SEP\" data\-element\=\"SEP\">/<span class\=\"SEP\">/g;
		$frontmatter=~s/<SUB\-TEXT>/<span class\=\"SUB\-TEXT\">/g;
		$frontmatter=~s/<\/SUB\-TEXT>/<\/span>/g;
		$frontmatter=~s/<kwd>/<span class\=\"Keywordtext\" data\-element\=\"kwd\">/g;
		$frontmatter=~s/<\/kwd>/<\/span>/g;
		$frontmatter=~s/<span class\=\"FMSEP\" data\-element\=\"FMSEP\">/<span class\=\"FMSEP\">/gi;
		$frontmatter=~s/<\/($fmelements)>/<\/span>/gi;
		$frontmatter=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(Affiliation\:?)<\/p\[\1\]>/<p\[$1\] class\=\"UNSTYLED\">$3<\/p\[$1\]>/gi;
		$frontmatter=~s/<p\[(\d+)\] xclass\=\"([^\"]+)\">/<p\[$1\] class\=\"$2\">/gi;
		$frontmatter=~s/<a\[(\d+)\] class\=\"xfootnote\" href\=\"\#footnote\d+\">\w+<\/a\[\1\]>//sgi;
		
		
		####FM ADVANCED
		if ($frontmatter=~m/<p\[(\d+)\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\"><span class\=\"Keywordtext\" data\-element\=\"kwd\">\:?<\/span><\/p\[\1\]>/i)
		{
			$Line=$frontmatter;	
			$Variable="";	
			while($Line =~/<p\[(\d+)\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\"><span class\=\"Keywordtext\" data\-element\=\"kwd\">\:?<\/span><\/p\[\1\]>(.*?)$/si)	
			{	
				$PreMatch = $`;
				$Curr = $&;
				$Line = $';
				
				my $possiblekeywords="$2";
				
				$possiblekeywords=~s/<p\[(\d+)] class\=\"normal\">/<xp\[$1] class\=\"normal\">/gi;
				if ($possiblekeywords!~m/<p\[(\d+)] class\=\"normal\">/i)
				{
					$possiblekeywords=~s/\s*<xp\[(\d+)] class\=\"normal\">(.*?)<\/p\[\1\]>/<kwd>$2<\/kwd>/gi;
					$possiblekeywords=~s/<\/kwd>\s*<kwd>/<\/kwd><FMSEP>\, <\/FMSEP><kwd>/gi;
					$possiblekeywords=~s/<kwd>/<span class\=\"Keywordtext\" data\-element\=\"kwd\">/gi;
					$possiblekeywords=~s/<FMSEP>/<span class\=\"FMSEP\">/gi;
					$possiblekeywords=~s/<\/kwd>/<\/span>/gi;
					$possiblekeywords=~s/<\/FMSEP>/<\/span>/gi;
					
					$Curr=~s/<p\[(\d+)\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\"><span class\=\"Keywordtext\" data\-element\=\"kwd\">\:?<\/span><\/p\[\1\]>(.*?)$/<p\[$1\] class\=\"Keywords\" data\-element\=\"kwd\-group\" data\-attribs\-kwd\-group\-type\=\"author\">$possiblekeywords<\/p\[$1\]>/sgi;
				}
					
			$Variable .=$PreMatch .$Curr;	
			}	
			$Variable .=$Line;	
			$frontmatter = $Variable;
		
		}
		
		$Line=$frontmatter;	
		$Variable="";	
		while($Line =~/<p\[(\d+)\] class\=\"CAUTHOR\">(.*?)<\/p\[\1\]>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			
			$Curr=~s/<span class="(?:institution|fax|state|country|city|POSTALCODE|addr\-line|phone)"[^><]*>((?:(?!<\/?span\b).)*?)<\/span>/$1/sgi;

		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;	
		
		
		$frontmatter=~s/<p\[(\d+)\] class\=\"CAUTHOR\">(\*Corresponding Author)<\/p\[\1\]>/<p\[$1\] class\=\"normal\">$2<\/p\[$1\]>/gi;
		
		#print ERR "$frontmatter";
		#exit;

		if ($frontmatter!~m/<p\[(\d+)\] class\=\"CAUTHOR\">/i)
		{
			$Line=$frontmatter;	
			$Variable="";	
			while($Line =~/<p\[(\d+)\] class\=\"normal\">(.*?)<\/p\[\1\]>/si)	
			{	
				$PreMatch = $`;
				$Curr = $&;
				$Line = $';

				if ($Curr=~m/\@/i)
				{
					#$Curr=~s/<p\[(\d+)\] class\=\"normal\">/<p\[$1\] class\=\"CAUTHOR\">/gi;
				}
					
			$Variable .=$PreMatch .$Curr;	
			}	
			$Variable .=$Line;	
			$frontmatter = $Variable;
			

			$Line=$frontmatter;	
			$Variable="";	
			while($Line =~/<p\[(\d+)\] class\=\"CAUTHOR\">(.*?)<\/p\[\1\]>/sgi)	
			{	
				$PreMatch = $`;
				$Curr = $&;
				$Line = $';
				
				$Curr=~s/((\w+)\@(\w+)\.(\w+)\.?(\w+)?\.?(\w+)?)/<EMAIL>$1<\/EMAIL>/g;
				$Curr=~s/<p\[(\d+)\] class\=\"CAUTHOR\">((\w+)\@(\w+)\.(\w+)\.?(\w+)?\.?(\w+)?)/<p\[$1\] class\=\"CAUTHOR\"><EMAIL>$2<\/EMAIL>/g;
				$Curr=~s/(\w+)\.<EMAIL>/<EMAIL>$1\./g;
				$Curr=~s/<\/EMAIL>\s*<sup\[(\d+)\] class\=\"dummy\">([a-z])\*<\/sup\[\1\]>/<CORR\/><\/EMAIL><sup\[$1\] class\=\"dummy\">$2\*<\/sup\[$1\]>/gi;
				
				
				if($pubname=~/^(NOW)$/s)
				{
				$Curr=~s/<p\[(\d+)\] class\=\"CAUTHOR\">/<p\[$1\] class\=\"Affiliation\">/sgi;
				$Curr=~s/<EMAIL>(.*?)<\/EMAIL>/<span class\=\"Corresp\" data\-element\=\"email\">$1<\/span>/sgi;
				}
				
			$Variable .=$PreMatch .$Curr;	
			}	
			$Variable .=$Line;	
			$frontmatter = $Variable;	

			$frontmatter=~s/<p\[(\d+)\] class\=\"CAUTHOR\">/<CAUTHOR\/><p\[$1\] class\=\"Affiliation\">/gi;

			FMAFFILIATION();
			
			$Line=$frontmatter;	
			$Variable="";	
			while($Line =~/<p\[(\d+)\] class\=\"CAUTHOR\">(.*?)<\/p\[\1\]>/sgi)	
			{	
				$PreMatch = $`;
				$Curr = $&;
				$Line = $';

				$Curr=~s/Corresponding author\: <city>(.*?)<\/city>/Corresponding author\: $2/sgi;
				$Curr=~s/<country>(MD)<\/country>/$1/sgi;
				$Curr=~s/(\-|Mobile\: )<POSTALCODE>(.*?)<\/POSTALCODE>/$1$2/sgi;
	
					
			$Variable .=$PreMatch .$Curr;	
			}	
			$Variable .=$Line;	
			$frontmatter = $Variable;	
			
		}


		$Line=$frontmatter;	
		$Variable="";
		while($Line =~/<p\[(\d+)\] class\=\"(Affiliation|CAUTHOR)\"(.*?)<\/p\[\1\]>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
		
			if($Curr!~/<email/si)
			{
				$Curr=~s/((?:[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\]))/<email>$1<\/email>/g;
			}
			
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$frontmatter = $Variable;	


		while($frontmatter=~/<span class="FMAFFEMAIL" data-element="FMAFFEMAIL">((?:(?!<\/span>).)*?)<\/span>/sgi)
		{
			my $temp = $&;
			if($temp!~/<email/si)
			{
				#$temp=~s/((\w+)\@(\w+)\.(\w+)\.?(\w+)?\.?(\w+)?)/<EMAIL>$1<\/EMAIL>/g;
				$temp=~s/((?:[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\]))/<email>$1<\/email>/g;
			}
			$temp=~s/<(\/)?span/<$1XXXspan/sgi;
			$frontmatter=~s/<span class="FMAFFEMAIL" data-element="FMAFFEMAIL">((?:(?!<\/span>).)*?)<\/span>/$temp/si;
		}
		$frontmatter=~s/<(\/)?XXXspan/<$1span/sgi;

		
		my $correspwords="Corresponding author\|Author for correspondence\|Address for correspondence\|ADDRESS OF CORRESPONDENCE|Correspondence|Co-Correspondence";
		$frontmatter=~s/<p\[(\d+)\] class\=\"CAUTHOR\"><[b|i]\[(\d+)\] class\=\"dummy\">($correspwords) ?\:?\.? ?<\/[b|i]\[\2\]> ?\:?\.?\s*<\/p\[\1\]>/<p\[$1\] class\=\"CAUTHOR\">$3\:<\/p\[$1\]>/gi;
		

		if ($frontmatter=~m/<p\[(\d+)\] class\=\"normal\">(\*?$correspwords)\:?\s*<\/p\[\1\]>/i)
		{
			$Line=$frontmatter;	
			$Variable="";	
			while($Line =~/<p\[(\d+)\] class\=\"normal\">(\*?$correspwords)\:?\s*<\/p\[\1\]>(.*?)(<div class\=\"abstract\"|<p\[\d+\] class\=\"(Keywords|AFF|Au))/si)	
			{	
				$PreMatch = $`;
				$Curr = $&;
				$Line = $';

				my $possiblecauthor="$3";
				$possiblecauthor=~s/<p\[(\d+)\] class\=\"normal\">//gi;
				$possiblecauthor=~s/<\/p\[(\d+)\]>\s*/\, /gi;
				$possiblecauthor=~s/\,\s*$//gi;
				$possiblecauthor=~s/\n//gi;
	
				$Curr=~s/<p\[(\d+)\] class\=\"normal\">(\*?$correspwords)\:?\s*<\/p\[\1\]>(.*?)(<div class\=\"abstract\"|<p\[\d+\] class\=\"(Keywords|AFF|Au|R|S|D))/<p\[$1\] class\=\"CAUTHOR\">Corresponding author\: $possiblecauthor<\/p\[$1\]>\n$4/sgi;
					
			$Variable .=$PreMatch .$Curr;	
			}	
			$Variable .=$Line;	
			$frontmatter = $Variable;
			
			
			$frontmatter=~s/<p\[(\d+)\] class\=\"CAUTHOR\">(.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"Affiliation\" data\-element\=\"aff\" data\-attribs\-id\=\"aff\-\d+\">(.*?)<\/p\[\3\]>/<p\[$1\] class\=\"CAUTHOR\">$2\, $4<\/p\[$1\]>/sgi;

			while ($frontmatter=~m/<p\[(\d+)\] class\=\"CAUTHOR\">(.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"normal\">((Tel|Email)\:?\.? (.*?))<\/p\[\3\]>/sgi)
			{
				my $posscauthor2="$4";
				#$posscauthor2=~s/((\w+)\@(\w+)\.(\w+)\.?(\w+)?\.?(\w+)?)/<EMAIL>$1<\/EMAIL>/g;
				#$posscauthor2=~s/(\w+)\.<EMAIL>/<EMAIL>$1\./g;

				$frontmatter=~s/<p\[(\d+)\] class\=\"CAUTHOR\">(.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"normal\">((Tel|Email)\:?\.? (.*?))<\/p\[\3\]>/<p\[$1\] class\=\"CAUTHOR\">$2\, $posscauthor2<\/p\[\1\]>/sgi;
			}


			$Line=$frontmatter;	
			$Variable="";	
			while($Line =~/<p\[(\d+)\] class\=\"CAUTHOR\">(.*?)<\/p\[\1\]>/sgi)	
			{	
				$PreMatch = $`;
				$Curr = $&;
				$Line = $';

				
				$Curr=~s/((\w+)\@(\w+)\.(\w+)\.?(\w+)?\.?(\w+)?)/<EMAIL>$1<\/EMAIL>/g;
				$Curr=~s/<p\[(\d+)\] class\=\"CAUTHOR\">((\w+)\@(\w+)\.(\w+)\.?(\w+)?\.?(\w+)?)/<p\[$1\] class\=\"CAUTHOR\"><EMAIL>$2<\/EMAIL>/g;
				$Curr=~s/(\w+)\.<EMAIL>/<EMAIL>$1\./g;
				$Curr=~s/<\/EMAIL>\s*<sup\[(\d+)\] class\=\"dummy\">([a-z])\*<\/sup\[\1\]>/<CORR\/><\/EMAIL><sup\[$1\] class\=\"dummy\">$2\*<\/sup\[$1\]>/gi;
									
			$Variable .=$PreMatch .$Curr;	
			}	
			$Variable .=$Line;	
			$frontmatter = $Variable;

			$frontmatter=~s/<p\[(\d+)\] class\=\"CAUTHOR\">/<CAUTHOR\/><p\[$1\] class\=\"Affiliation\">/gi;
			
			FMAFFILIATION();

			$Line=$frontmatter;	
			$Variable="";	
			while($Line =~/<p\[(\d+)\] class\=\"CAUTHOR\">(.*?)<\/p\[\1\]>/sgi)	
			{	
				$PreMatch = $`;
				$Curr = $&;
				$Line = $';

				
				$Curr=~s/<\/?(institution|fax|state|country|city|postal\-code|addr\-line|phone)>//sgi;
					
			$Variable .=$PreMatch .$Curr;	
			}	
			$Variable .=$Line;	
			$frontmatter = $Variable;	
			
		}

		$frontmatter=~s/<($fmelements)>/<span xclass\=\"$1\" data\-element\=\"$1\">/gi;
		$frontmatter=~s/<span xclass\=\"([a-z])/<span class\=\"\U$1\E/g;
		$frontmatter=~s/<span xclass\=\"([^\"]+)\"/<span class\=\"$1\"/gi;
		$frontmatter=~s/<span class\=\"FMSEP\" data\-element\=\"FMSEP\">/<span class\=\"FMSEP\">/gi;
		$frontmatter=~s/<\/($fmelements)>/<\/span>/gi;
		
		#new generate aff id in html
=c
			$frontmatter=~s/(<span(?:\[\d+\])? class="AFFID")>/$1 data-element="AFFID">/gi;
			$frontmatter=~s/(<p\[\d+\][^><]*class="Affiliation"[^><]*data-attribs-id="[^"><]+">\s*)(<[^><]+>\s*)?(<sup[^><]*>((?:\&\#x[^\;><]+;)+)<\/sup\b[^><]*>)/$1<span class="FMLABEL" data-element="label">$4<\/span>$2/sgi;

			
			$frontmatter=~s#<span class="AFFID" data-element="AFFID">((?:(?!<\/span>).)*?)<\/span>#
			my ($cr, $val) = ($&, $1);
			if ($frontmatter=~/data-attribs-id="([^"]+)">\s*<span class="FMLABEL" data-element="label">\Q$val\E<\/span>/si)
			{
				my $id = $1;
				$cr=~s/<span class="AFFID" data-element="AFFID">/<span class="AFFID" data-element="AFFID" data-attribs-id="$id">/si;
			}
			("$cr");#sgie;
=cut
		
		
		$_=~s/<div\[(\d+)\] class\=\"front\">(.*?)<\/div\[\1\]>/<div\[$1\] class\=\"front\">\n$frontmatter\n<\/div\[$1\]>/si;
	
	
}

sub FMFINALCLEANUP2
{

	if(-e "$dirs\\articleinfo\.xml")
	{
		GIVEELEMENTNUMBERING("span");
		
		open(ATINFO, "<:encoding(UTF-8)", "$dirs\\articleinfo\.xml") or warn print ("$dirs\\articleinfo\.xml NOT FOUND, update the Journal Database!!!");
		my $artinfo = <ATINFO>;
		close (ATINFO);
		
		##CORRESPONDING AUTHOR###
		$Line=$artinfo;	
		$Variable="";	
		while($Line =~/<contrib (.*?)<\/contrib>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			
			my ($given_name, $sur_name);
			
			if($Curr =~/ corr\=\"((?!0")[^\"]*)\"/i || $Curr =~/ corresp\=\"yes\"/i)
			{
				$given_name = $1 if ($Curr =~/<given-names?>([^<>]*)<\/given-names?>/i);
				$sur_name = $1 if ($Curr =~/<surname>([^<>]*)<\/surname>/i);

			$Line1=$_;	
			$Variable1="";	
			while($Line1 =~/<span\[(\d+)\] class\=\"Author\"([^<>]*)>(.*?)<\/span\[\1\]>/sgi)	
			{	
				$PreMatch1 = $`;
				$Curr1 = $&;
				$Line1 = $';
				
				if($Curr1 =~/<span\[(\d+)\] class\=\"given-names\" data\-element\=\"given-names\">([^<>]*$given_name[^<>]*)<\/span\[\1\]>/i && $Curr1 !~/ data\-attribs\-corresp\=\"TYPE1\"/i)
				{
					$Curr1=~s/<span\[(\d+)\] class\=\"Author\"([^<>]*)>/<span\[$1\] class\=\"Author\"$2 data\-attribs\-corresp\=\"TYPE1\">/si if($given_name);
				}
				elsif($Curr1 =~/<span\[(\d+)\] class\=\"surname\" data\-element\=\"surname\">[^<>]*$sur_name[^<>]*<\/span\[\1\]>/i && $Curr1 !~/ data\-attribs\-corresp\=\"TYPE1\"/i)
				{
					$Curr1=~s/<span\[(\d+)\] class\=\"Author\"([^<>]*)>/<span\[$1\] class\=\"Author\"$2 data\-attribs\-corresp\=\"TYPE1\">/si  if($sur_name);
				}
				elsif($Curr1 =~/<span\[(\d+)\] class\=\"given-names\" data\-element\=\"given-names\">[^<>]*$sur_name[^<>]*<\/span\[\1\]>/i || $Curr1 =~/<span\[(\d+)\] class\=\"surname\" data\-element\=\"surname\">[^<>]*$given_name[^<>]*<\/span\[\1\]>/i && $Curr1 !~/ data\-attribs\-corresp\=\"TYPE1\"/i)
				{
					if($sur_name || $given_name)	{
						$Curr1=~s/<span\[(\d+)\] class\=\"Author\"([^<>]*)>/<span\[$1\] class\=\"Author\"$2 data\-attribs\-corresp\=\"TYPE1\">/si;
					}
				}

				if($Curr1=~/<span(\[\d+\]) class=\"AFFID\">\&\#x002A;<\/span\1>/si && $Curr1 !~/ data\-attribs\-corresp\=\"TYPE1\"/i)
				{
				$Curr1=~s/<span(\[\d+\]) class=\"AFFID\">\&\#x002A;<\/span\1>//si;
				$Curr1=~s/<span(\[\d+\]) class=\"AFFID\">\s*<\/span\1>//si;
				$Curr1=~s/( data\-attribs\-contrib\-type=\"author\")/$1 data\-attribs\-corresp=\"TYPE1\"/si;
				}

			$Variable1 .=$PreMatch1 .$Curr1;	
			}	
			$Variable1 .=$Line1;	
			$_ = $Variable1;
			}

			
			
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$artinfo = $Variable;

		##ORCID###
		$Line=$artinfo;	
		$Variable="";	
		while($Line =~/<contrib (.*?)<\/contrib>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			
			my ($given_name, $sur_name, $orcid);
			#if($Curr =~/<contributor\-id ([^<>]*)contrib\-id\-types?\=\"orcid\"([^<>]*)>(.*?)<\/contributor\-id>/si)
			if($Curr =~/<contrib([^<>]*)contrib\-id\-types?\=\"orcid\"([^<>]*)>(.*?)<\/contrib/si)
			{
				$orcid = $3;
				$given_name = $1 if ($Curr =~/<given-names?>([^<>]*)<\/given-names?>/i);
				$sur_name = $1 if ($Curr =~/<surname>([^<>]*)<\/surname>/i);


				$Line1=$_;	
				$Variable1="";	
				while($Line1 =~/<span\[(\d+)\] class\=\"Author\"([^<>]*)>(.*?)<\/span\[\1\]>/sgi)	
				{	
					$PreMatch1 = $`;
					$Curr1 = $&;
					$Line1 = $';
					
					if($Curr1 =~/<span\[(\d+)\] class\=\"given-names\" data\-element\=\"given-names\">\Q$given_name\E<\/span\[\1\]>/i)
					{
						$Curr1=~s/<span\[(\d+)\] class\=\"Author\"([^<>]*)>(.*?)<\/span\[\1\]>/<span\[$1\] class\=\"Author\"$2><span class\=\"ORCID\" data\-element\=\"contrib\-id\" data\-attribs\-contrib\-id\-type\=\"orcid\"><span class\=\"ORCIDTEXT\">$orcid<\/span><\/span>$3<\/span\[$1\]>/si;
					}
					elsif($Curr1 =~/<span\[(\d+)\] class\=\"surname\" data\-element\=\"surname\">\Q$sur_name\E<\/span\[\1\]>/i)
					{
						$Curr1=~s/<span\[(\d+)\] class\=\"Author\"([^<>]*)>(.*?)<\/span\[\1\]>/<span\[$1\] class\=\"Author\"$2><span class\=\"ORCID\" data\-element\=\"contrib\-id\" data\-attribs\-contrib\-id\-type\=\"orcid\"><span class\=\"ORCIDTEXT\">$orcid<\/span><\/span>$3<\/span\[$1\]>/si;
					}
					elsif($Curr1 =~/<span\[(\d+)\] class\=\"given-names\" data\-element\=\"given-names\">\Q$sur_name\E<\/span\[\1\]>/i || $Curr1 =~/<span\[(\d+)\] class\=\"surname\" data\-element\=\"surname\">\Q$given_name\E<\/span\[\1\]>/i)
					{
						$Curr1=~s/<span\[(\d+)\] class\=\"Author\"([^<>]*)>(.*?)<\/span\[\1\]>/<span\[$1\] class\=\"Author\"$2><span class\=\"ORCID\" data\-element\=\"contrib\-id\" data\-attribs\-contrib\-id\-type\=\"orcid\"><span class\=\"ORCIDTEXT\">$orcid<\/span><\/span>$3<\/span\[$1\]>/si;
					}
					
					$Curr1=~s/<span class\=\"ORCID\" data\-element\=\"contrib\-id\" data\-attribs\-contrib\-id\-type\=\"orcid\">\s*<span class\=\"ORCIDTEXT\">\s*<\/span>\s*<\/span>//sgi;
						
				$Variable1 .=$PreMatch1 .$Curr1;	
				}	
				$Variable1 .=$Line1;	
				$_ = $Variable1;

		}
	
			
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$artinfo = $Variable;
		
		#EMAIL insert
		if($pubname=~/^(HINDAWI)$/i)
		{
			$Line=$_;
			$Variable="";	
			while($Line =~/<span(\[\d+\]) class=\"Author\"(.*?)<\/span\1>/sgi)	
			{	
				$PreMatch = $`;
				$Curr = $&;
				$Line = $';
			if($Curr=~/<span(\[\d+\]) class\=\"given-names\" /si || $Curr=~/<span(\[\d+\]) class\=\"surname\"/si)
			{
				if($Curr!~m/<span class\=\"AUEMAIL\">/i)
				{
					my $gname=$2 if($Curr=~/<span(\[\d+\]) class\=\"given-names\" data\-element\=\"given-names\">(.*?)<\/span\1>/i);
					my $sname=$2 if($Curr=~/<span(\[\d+\]) class\=\"surname\" data\-element\=\"surname\">(.*?)<\/span\1>/i);

					$Line1=$artinfo;	
					$Variable1="";	
					while($Line1 =~/<contrib (.*?)<\/contrib>/sgi)	
					{	
						$PreMatch1 = $`;
						$Curr1 = $&;
						$Line1 = $';

						if($Curr1=~/$sname/si && $Curr1=~/$gname/si)
						{
							my $mailid=$1 if($Curr1=~/<email>((?:(?!<\/email>).)*?)<\/email>/si);
							$Curr=~s/(<\/span\[\d+\]>)$/<span class=\"AUEMAIL\"><span class=\"EMAILTEXT\">$mailid<\/span><\/span>$1/sgi;
						}
							
					$Variable1 .=$PreMatch1 .$Curr1;	
					}	
					$Variable1 .=$Line1;	
					$artinfo = $Variable1;
					$Curr=~s/<span class\=\"AUEMAIL\"><span class=\"EMAILTEXT\">\s*<\/span><\/span>//sgi;
				}
			}
			$Variable .=$PreMatch .$Curr;	
			}	
			$Variable .=$Line;	
			$_ = $Variable;
		}
		
		#Academic Editor insert
		if($pubname=~/^(HINDAWI)$/i)
		{
			$Line=$artinfo;	
			$Variable="";	
			my $ae_id = 551;
			while($Line =~/<contrib (.*?)<\/contrib>/sgi)	
			{	
				$PreMatch = $`;
				$Curr = $&;
				$Line = $';
				
				if($Curr =~/contrib-type\=\"Academic Editor\"/si)
				{
					my ($given_name, $sur_name, $orcid_url, $email_txt, $Academic_Editor);
					$given_name = $1 if ($Curr =~/<given-names?>([^<>]*)<\/given-names?>/i);
					$sur_name = $1 if ($Curr =~/<surname>([^<>]*)<\/surname>/i);
					$email_txt = $1 if ($Curr =~/<email>([^<>]*)<\/email>/i);
					$orcid_url = $3 if ($Curr =~/<contrib([^<>]*)contrib\-id\-types?\=\"orcid\"([^<>]*)>(.*?)<\/contrib/si);

					$Academic_Editor = "<span class=\"Author\" data-element=\"contrib\" data-attribs-id=\"author-0$ae_id\" data-attribs-contrib-type=\"Academic Editor\"><span class=\"ORCID\" data-element=\"contrib-id\" data-attribs-contrib-id-type=\"orcid\"><span class=\"ORCIDTEXT\">$orcid_url<\/span><\/span><span class=\"name\" data-element=\"name\" data-attribs-name-style=\"western\"><span class=\"surname\" data-element=\"surname\">$sur_name<\/span><span class=\"FMSEP\"> <\/span><span class=\"given-names\" data-element=\"given-names\">$given_name<\/span><\/span><span class=\"AUEMAIL\"><span class=\"EMAILTEXT\">$email_txt<\/span><\/span><\/span>";
					
					while($Academic_Editor=~s/<span class\=\"(ORCID|ORCIDTEXT|surname|given-names|AUEMAIL|EMAILTEXT)\"([^<>]*)>\s*<\/span>//sgi){}

					if($_ =~/<p\[(\d+)\] class\=\"AuthorGroup\"([^<>]*)>(.*?)<\/p\[\1\]>/si)
					{
						$_=~s/(<p\[(\d+)\] class\=\"AuthorGroup\")([^<>]*)>(.*?)<\/p\[\2\]>/$1$3>$4<\/p\[$2\]>\n<p class\=\"EditorGroup\">$Academic_Editor<\/p>/si;
						$ae_id++;
					}
				
	
				}
		
				
					
			$Variable .=$PreMatch .$Curr;	
			}	
			$Variable .=$Line;	
			$artinfo = $Variable;
		}

	}
		
	
	
}

sub CHAR2ENTITY
{
	while($_ =~ m/[\x{A0}-\x{FFDC}]/g)
	{
		my $findchar = $&;
		my $ent = uc(sprintf("%x", ord($findchar)));

		if(defined $ent)
		{
			if(length($ent) == 1)
			{
				$ent = "&#x0000$ent;";
			}
			elsif(length($ent) == 2)
			{
				$ent = "&#x000$ent;";
			}
			elsif(length($ent) == 3)
			{
				$ent = "&#x00$ent;";
			}
			elsif(length($ent) == 4)
			{
				$ent = "&#x0$ent;";
			}
			$_ =~ s/$findchar/$ent/g;
		}
		else
		{
			$_ =~ s/$findchar/<SRN\/>/;
		}
	}


	$_ =~ s/<NOTCONVERTED>([\&\#\w\;]+)<\/NOTCONVERTED>/$1/gi;
	$_ =~ s{<NOTCONVERTED>\\x(\w+)<\/NOTCONVERTED>}
	{
		my $NTent = "&#x0000" . $1;
		$NTent =~ s/^\&\#x0+([a-z0-9]{4})$/<NOTCONVERTED>\&\#x$1\;<\/NOTCONVERTED>/gi;
		$NTent;
	}iseg;

	$_ =~ s{<NOTCONVERTED>((\\x|\w)+)<\/NOTCONVERTED>}
	{
		my $test = $1;
		my @NTent = map {$_ =~ s/\\x(\w+)/\&\#x0000$1/i;$_ =~ s/^\&\#x0+([a-z0-9]{4})$/<NOTCONVERTED>\&\#x$1\;<\/NOTCONVERTED>/gi; $_} split(/(\\x\w+)/i, $test);
		my $finjoin = join "", @NTent;
		$finjoin;
	}iseg;

	$_ =~ s{<NOTCONVERTED>(&[\#\w]+;| )+<\/NOTCONVERTED>}
		{
			my $notconv = $&;
			$notconv =~ s/<\/?NOTCONVERTED>//gi;
			$notconv;
		}gie;

	$_ =~ s{<NOTCONVERTED>([^<>]+)<\/NOTCONVERTED>}
	{
		my $notc = $1;
		$notc =~ s{.}
			{
				my $findchar = $&;
				my $ent = uc(sprintf("%x", ord($findchar)));
				#print "$ent\n";
				if(defined $ent)
				{
					if(length($ent) == 1)
					{
						$ent = "&#x0000$ent;";
					}
					elsif(length($ent) == 2)
					{
						$ent = "&#x000$ent;";
					}
					elsif(length($ent) == 3)
					{
						$ent = "&#x00$ent;";
					}
					elsif(length($ent) == 4)
					{
						$ent = "&#x0$ent;";
					}
				}
				$ent;
			}eg;
		$notc;
	}iseg;
	
}

sub FOOTNOTES
{
	
	$Line=$_;
	$Variable="";	
	while($Line =~/<p(\[\d+\]) class\=\"AUTHORFOOTNOTE\">(.*?)<\/p\1>/sg)
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
	
		$Curr =~s/(?<!"|>)(https?\:\/\/?[^\.]+\.[^\s<>]+[^\s\.><])/<uri xlink:href="$1">$1<\/uri>/sgi;
		
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;
	$_ = $Variable;
	
	if($_=~/(<div class="funding-group" data-element="funding-group">((?:(?!<\/div>).)*?)<\/div>\s*)<div class="abstract"/si)
	{
		my $fund = $1;
		#$fund=~s/<b(\[\d+\]) class="dummy">Funding\s*(?:\:|\.)\s*<\/b\1>\s*//si;
		$_=~s/(<div class="funding-group" data-element="funding-group">((?:(?!<\/div>).)*?)<\/div>\s*)<div class="abstract"/<div class="abstract"/si;
		$_=~s/(<div\[\d+\] class="bodymatter">)/$fund$1/si;
	}

	
	$Line=$_;	
	$Variable="";	
	my ($author_note, $new_af_id) = ("", 1);
	my %author_foot;
	while($Line =~/<div(\[\d+\]) class\=\"footnote\" id\=\"([^\"]*)\">(.*?)<\/div\1>/sg)
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		if($Curr=~m/<p(\[\d+\]) class\=\"normal\">(\*|\&ast\;|\&\#x0?002A\;)+/si)
		{
			$author_note .= "$Curr\n";
			$Curr = "";
		}
		else
		{
			$author_foot{$2} = "footnote$new_af_id" if($Curr =~s/<div(\[\d+\]) class\=\"footnote\" id\=\"([^\"]*)\">/<div$1 class\=\"footnote\" id\=\"footnote$new_af_id\">/si);
			$new_af_id++;
		}
		
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	
	if($author_note)
	{
		$author_note=~s/<div(\[\d+\]) class\=\"footnote\" id\=\"([^\"]*)\">(.*?)<\/div\1>/$3/sgi;
		$author_note=~s/<p(\[\d+\]) class\=\"normal\">(.*?)<\/p\1>/<p$1 class\=\"AuthorFootnotes\">$2<\/p$1>/sgi;
		if($_!~s/<div class\=\"abstract\"/$author_note\n<div class\=\"abstract\"/si)
		{
			$_=~s/<p(\[\d+\]) class\=\"ArticleTitleHead\"([^<>]*)>(.*?)<\/p\1>/$&\n$author_note/si;
		}
	}
	
	if(%author_foot)
	{
		foreach $key_id (keys %author_foot)
		{
			$_ =~s/<a(\[\d+\]) class\=\"footnote\" href\=\"\#$key_id\">(\d+)<\/a\1>/<a$1 class\=\"footnote\" href\=\"\#$author_foot{$key_id}\">$2<\/a$1>/si;
		}
	}
	
	$_ =~s/<a(\[\d+\]) class\=\"footnote\" href\=\"\#footnote(\d+)\">(\d+)<\/a\1>/<a$1 class\=\"footnote\" href\=\"\#footnote$2\">$2<\/a$1>/sig;
}

sub TABLESNOTES
{
	
	while($_=~s/(<tfoot>((?:(?!<tfoot\s*\b).)*?)<\/tfoot>)\s*<\/table>/\n<\/table>\n$1/sgi){}
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<tfoot>((?:(?!<tfoot\s*\b).)*?)<\/tfoot>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';

		$Curr=~s/<p\[(\d+)\] class\=\"normal\">\s*<sup\[(\d+)\] class\=\"dummy\">\s*<(b|i)\[(\d+)\] class\=\"dummy\">\s*(\w|(\*|\#)\6*)<\/\3\[\4\]><\/sup\[\2\]>/<p\[$1\] class\=\"TABLE\-FOOT\"><sup\[$2\] class\=\"dummy\"><$3\[$4\] class\=\"dummy\"><span class\=\"TFNLABEL\">$5<\/span><\/$3\[$4\]><\/sup\[$2\]>/sgi;
		$Curr=~s/<p\[(\d+)\] class\=\"normal\">\s*<sup\[(\d+)\] class\=\"dummy\">\s*(\w|(\*|\#)\4*)<\/sup\[\2\]>/<p\[$1\] class\=\"TABLE\-FOOT\"><sup\[$2\] class\=\"dummy\"><span class\=\"TFNLABEL\">$3<\/span><\/sup\[$2\]>/sgi;
		$Curr=~s/<p\[(\d+)\] class\=\"normal\">\s*((\*|\#)\3*)/<p\[$1\] class\=\"TABLE\-FOOT\"><span class\=\"TFNLABEL\">$2<\/span>/sgi;
		$Curr=~s/<(\/)?tfoot>\n?//sgi;

	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<div\[(\d+)\] class\=\"TABLE\"([^<>]*)>(.*?)<\/div\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		my @footlable = ();
		while($Curr =~/<span class\=\"TFNLABEL\">((?:(?!<span\s*\b).)*?)<\/span>/gi)
		{
			push(@footlable, $1)
		}
		
		foreach my $tlabel (@footlable)
		{
			$Curr=~s/<sup\[(\d+)\] class\=\"dummy\">\s*<(b|i)\[(\d+)\] class\=\"dummy\">\s*\Q$tlabel\E<\/\2\[\3\]><\/sup\[\1\]>/<sup\[$1\] class\=\"dummy\"><$2\[$3\] class\=\"dummy\"><span class\=\"TFNLINK\">$tlabel<\/span><\/$2\[$3\]><\/sup\[$1\]>/sgi;
			$Curr=~s/<sup\[(\d+)\] class\=\"dummy\">\s*\Q$tlabel\E<\/sup\[\1\]>/<sup\[$1\] class\=\"dummy\"><span class\=\"TFNLINK\">$tlabel<\/span><\/sup\[$1\]>/sgi;
		}

	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;

}

sub RUNNINGHEAD
{
	
  ##right running head value either from jrnltitle or articletitle
  if($jornalconfig=~m/<rightrunning value=\"article\-title\">/sig)
  {
    if($articleinfo=~m/<article\-title>(.*?)<\/article\-title>/si)
	{
      my $art_title = $1;
      $_=~s/(<p(\[\d+\]) class=\"ArticleTitleHead\"[^<>]*>(.*?)<\/p\2>)/$1\n<p class=\"right\-running\">$art_title<\/p>/si;
    }
  }
  else
  {
    if($articleinfo=~/<journalfulltitle>(.*?)<\/journalfulltitle>/i)
    {
      my $alttitle="$1";
      $_=~s/(<p(\[\d+\]) class=\"ArticleTitleHead\"[^<>]*>(.*?)<\/p\2>)/$1\n<p class=\"right\-running\">$alttitle<\/p>/si;
	  ####RUNNING HEAD IN FULLCAPS####
		#$_=~s/<p class=\"right\-running\">$alttitle<\/p>/<p class=\"right\-running\">\U$alttitle\E<\/p>/si;
	  ####RUNNING HEAD IN ITALIC####
		#$_=~s/<p class=\"right\-running\">$alttitle<\/p>/<p class=\"right\-running\"><i>$alttitle<\/i><\/p>/si;
    }
  }
  ##left running head
  GIVEELEMENTNUMBERING("p", "span");
 
  if($jornalconfig=~m/<left\-running([^<>]*)etal=\"([^\"]*)\"([^<>]*)\/>/si){
    my $etal_italic = $1;
    my $etalnum = $2-1;
    my $etalend_dot = $3;
    my $id=0;
    my ($alttxtone, $alttexttwo, $alttxtthree, $finalalttxt);
    while($_=~/<span(\[\d+\]) class=\"Author\"[^<>]*>(.*?)<\/span\1>/sig){
      my $alttitle2="$2";
      $id++;
      my $alttext;
	
      if($alttitle2=~/<span(\[\d+\]) class=\"given\-names\"[^<>]*>(.*?)<\/span\1><span(\[\d+\]) class=\"FMSEP\">[^<>]*<\/span\3><span(\[\d+\]) class=\"surname\"[^<>]*>(.*?)<\/span\4>/si)
      {
        my $givenname = $2;
        my $surname = $5;
        if($id eq 1){
          $alttxtone="<gn>".$givenname."<\/gn> ".$surname;
          $finalalttxt=$alttxtone;
        }
        elsif($id eq 2){
          my $alttexttwocon="<gn>".$givenname."<\/gn> ".$surname;
          my $alttexttwo=$alttxtone." and ".$alttexttwocon;
          $finalalttxt=$alttexttwo;     
        }
        elsif($id > $etalnum){                    
         $alttxtthree = $alttxtone." et al\.";
         $finalalttxt=$alttxtthree;
        }
      }
      elsif($alttitle2=~/<span(\[\d+\]) class=\"surname\"[^<>]*>(.*?)<\/span\1><span(\[\d+\]) class=\"FMSEP\">[^<>]*<\/span\3><span(\[\d+\]) class=\"given\-names\"[^<>]*>(.*?)<\/span\4>/si)
      {
        my $givenname = $5;
        my $surname = $2;
        if($id eq 1){
          $alttxtone="<gn>".$givenname."<\/gn> ".$surname;
          $finalalttxt=$alttxtone;
        }
        elsif($id eq 2){
          my $alttexttwocon="<gn>".$givenname."<\/gn> ".$surname;
          my $alttexttwo=$alttxtone." and ".$alttexttwocon;
          $finalalttxt=$alttexttwo;     
        }
        elsif($id > $etalnum){                    
         $alttxtthree = $alttxtone." et al\.";
         $finalalttxt=$alttxtthree;
        }
      }
    }

	$finalalttxt=~s/<(\/)?gn>//g;
    if($etalend_dot=~m/enddot=\"NO\"/si){
      $finalalttxt=~s/et al\./et al/sig;
    }
    if($etal_italic=~m/etal\-style=\"italic\"/si){
      $finalalttxt=~s/( |\&nbsp\;|\&\#x000?A0\;)(et( |\&nbsp\;|\&\#x000?A0\;)al\.?)/$1<i>$2<\/i>/sig;
    }
	$finalalttxt=~s/<(\/)?DATA>//sgi;
    $_=~s/(<p(\[\d+\]) class=\"ArticleTitleHead\"[^<>]*>(.*?)<\/p\2>)/$1\n<p class=\"left\-running\">$finalalttxt<\/p>/si;  
	if($jornalconfig=~/<RRH>(.*?)<\/RRH>\s*<LRH>(.*?)<\/LRH>/i)
	{
	my ($rrh,$lrh)=($1,$2);
	$_=~s/<p class=\"left\-running\">((?:(?!<\/p>).)*?)<\/p>/<p class=\"left\-running\">$lrh<\/p>/sgi;
	$_=~s/(<p(\[\d+\]) class=\"right\-running\">)(.*?)(<\/p\2>)/$1$rrh$4/sgi;
	}
  }
  elsif($_=~/<span(\[\d+\]) class=\"Author\"[^<>]*>(.*?)<\/span\1>/si)
    {
      my $alttitle2="$2";
      if($alttitle2=~/<span(\[\d+\]) class=\"given\-names\"[^<>]*>(.*?)<\/span\1><span(\[\d+\]) class=\"FMSEP\">[^<>]*<\/span\3><span(\[\d+\]) class=\"surname\"[^<>]*>(.*?)<\/span\4>/si)
      {
        my $alttext;
        my $givenname = $2;
        my $surname = $5;
        my $initial;

		my $agroup = $2 if($_=~/<(p\[\d+\]) class="AuthorGroup"[^><]*>(.*?)<\/\1>/si);
		my $acount = () = $agroup=~/class="Author"/sgi;
		if ($acount == 1)
		{
			if($givenname=~m/[A-Z]$/)
			{
				$alttext=$givenname."\. ".$surname;
			}
			else
			{
				$alttext=$givenname." ".$surname;
			}
		}
		elsif($acount == 2)
		{
			$agroup=~s/^<span(\[\d+\]) class="Author"[^<>]*>(.*?)<\/span\1>//si;
			if($agroup=~/<span(\[\d+\]) class=\"given\-names\"[^<>]*>(.*?)<\/span\1><span(\[\d+\]) class=\"FMSEP\">[^<>]*<\/span\3><span(\[\d+\]) class=\"surname\"[^<>]*>(.*?)<\/span\4>/si)
			{
				my $givenname2 = $2;
        		my $surname2 = $5;
				if($givenname2=~m/[A-Z]$/)
				{
					$givenname2 = $givenname2."\.";
				}
				if($givenname=~m/[A-Z]$/)
				{
					$alttext=$givenname."\. ".$surname." and ".$givenname2." ".$surname2;
				}
				else
				{
					$alttext=$givenname." ".$surname." and ".$givenname2." ".$surname2;
				}
			}
		}
		else
		{
			if($givenname=~m/[A-Z]$/)
			{
				$alttext=$givenname."\. ".$surname." et al\.";
			}
			else
			{
				$alttext=$givenname." ".$surname." et al\.";
			}
		}
		
        $_=~s/(<p(\[\d+\]) class=\"ArticleTitleHead\"[^<>]*>(.*?)<\/p\2>)/$1\n<p class=\"left\-running\">$alttext<\/p>/si;  
      }

      if($alttitle2=~/<span(\[\d+\]) class=\"surname\"[^<>]*>(.*?)<\/span\1><span(\[\d+\]) class=\"FMSEP\">[^<>]*<\/span\3><span(\[\d+\]) class=\"given\-names\"[^<>]*>(.*?)<\/span\4>/si)
      {
        my $alttext;
        my $givenname = $5;
        my $surname = $2;
        my $initial;

          if($givenname=~m/[A-Z]$/)
		  {
            $alttext=$givenname."\. ".$surname." et al\.";
          }
          else
          {
			$alttext=$givenname." ".$surname." et al\.";
          }
		$_=~s/(<p(\[\d+\]) class=\"ArticleTitleHead\"[^<>]*>(.*?)<\/p\2>)/$1\n<p class=\"left\-running\">$alttext<\/p>/si;  
      }
    }
  
}

sub TESTSUB
{
	
	if($jornalconfig=~/<lastaff\b[^><\/]*enddot="NO"[^><]*>/si)
	{
		$_=~s#<p(\[\d+\])[^><]*class="Affiliation"(.*?)<\/p\1>(?!.*<p(\[\d+\])[^><]*class="Affiliation")#
		my $cur = $&;
		$cur =~s/\s*<span(\[\d+\]) class="FMSEP">[\.\;\s]*<\/span\1>\s*<\/p(\[\d+\])>/<\/p$2>/si;
		("$cur");#sie;
	}

	if($jornalconfig=~/<author-notes\b[^><\/]*enddot="NO"[^><]*>/si)
	{
		$_=~s#<p(\[\d+\])[^><]* class="AuthorFootnotes"(.*?)<\/p\1>#
		my $cur = $&;
		$cur =~s/[\.\;\s]+<\/p(\[\d+\])>/<\/p$1>/gi;
		("$cur");#sgie;
	}
	
	if($jornalconfig=~/<lastkwd\b[^><\/]*enddot="NO"[^><]*>/si)
	{

		$_=~s#<span(\[\d+\])[^><]*class="Keywordtext"(.*?)<\/span\1>(?!.*<span(\[\d+\])[^><]*class="Keywordtext")#
		my $cur = $&;
		$cur =~s/[\.\;\s]+<\/span(\[\d+\])>/<\/span$1>/gi;
		("$cur");#sgie;

		$_=~s#<span(\[\d+\])[^><]*class="Keywordtext"(?:.*?)<\/span\1>\s*<span(\[\d+\]) class="FMSEP">[\.\;\s]*<\/span\2>(?!.*<span(\[\d+\])[^><]*class="Keywordtext")#
		my $cur = $&;
		$cur =~s/\s*<span(\[\d+\]) class="FMSEP">[\.\;\s]*<\/span\1>\s*//gi;
		("$cur");#sgie;

	}
	
	if($jornalconfig=~/<corresp\b[^><\/]*enddot="NO"[^><]*>/si)
	{
		$_=~s#<p(\[\d+\])[^><]* class="(?:CAUTHOR|Corresponding)"(.*?)<\/p\1>#
		my $cur = $&;
		$cur =~s/[\.\;\s]+<\/p(\[\d+\])>/<\/p$1>/gi;
		("$cur");#sgie;
	}

	if($jornalconfig=~/<corresp>((?:(?!<\/corresp>).)*?)<\/corresp>/si)
	{	
		my $corresp_config = $1;
		if($corresp_config=~/<email>((?:(?!<\/email>).)*?)<\/email>/si)
		{
			my $email_config = $1;	
			if($email_config=~/<sep>((?:(?!<\/sep>).)*?)<\/sep>/si)
			{
				my $email_sep = $1;
				
				if($email_sep=~/^\; $/)
				{
					$_=~s/<(span\[\d+\]) class="FMAFFEMAIL" data-element="FMAFFEMAIL">(.*?)<\/\1>[\,\s]*<(span\[\d+\]) class="FMAFFEMAIL" data-element="FMAFFEMAIL">(.*?)<\/\3>/<$1 class="FMAFFEMAIL" data-element="FMAFFEMAIL">$2<\/$1>$email_sep<$3 class="FMAFFEMAIL" data-element="FMAFFEMAIL">$4<\/$3>/sgi;
					$_=~s/<email>((?:(?!<\/email>).)*?)<\/email>[\,\s]*<email>((?:(?!<\/email>).)*?)<\/email>/<email>$1<\/email>$email_sep<email>$2<\/email>/sgi;
				}
				elsif($email_sep=~/^\, $/)
				{
					$_=~s/<(span\[\d+\]) class="FMAFFEMAIL" data-element="FMAFFEMAIL">(.*?)<\/\1>[\;\s]*<(span\[\d+\]) class="FMAFFEMAIL" data-element="FMAFFEMAIL">(.*?)<\/\3>/<$1 class="FMAFFEMAIL" data-element="FMAFFEMAIL">$2<\/$1>$email_sep<$3 class="FMAFFEMAIL" data-element="FMAFFEMAIL">$4<\/$3>/sgi;
					$_=~s/<email>((?:(?!<\/email>).)*?)<\/email>[\;\s]*<email>((?:(?!<\/email>).)*?)<\/email>/<email>$1<\/email>$email_sep<email>$2<\/email>/sgi;
				}
				else
				{
					$_=~s/<(span\[\d+\]) class="FMAFFEMAIL" data-element="FMAFFEMAIL">(.*?)<\/\1>[\;\,\s]*<(span\[\d+\]) class="FMAFFEMAIL" data-element="FMAFFEMAIL">(.*?)<\/\3>/<$1 class="FMAFFEMAIL" data-element="FMAFFEMAIL">$2<\/$1>$email_sep<$3 class="FMAFFEMAIL" data-element="FMAFFEMAIL">$4<\/$3>/sgi;
					$_=~s/<email>((?:(?!<\/email>).)*?)<\/email>[\;\,\s]*<email>((?:(?!<\/email>).)*?)<\/email>/<email>$1<\/email>$email_sep<email>$2<\/email>/sgi;
				}
				
			}
		}
	}

#print ERR $_; exit;		
}



sub FinalCleanup
{
	

	while($_ =~ m/<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>/sgi)
	{
		$_=~s/<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>/<$1>$3<\/$1>/sgi;
	}
	
	
	$_=~s/<(\w+)\[(\d+)\]/<$1/g;
	$_=~s/<\/(\w+)\[(\d+)\]>/<\/$1>/g;
	$_=~s/\s*<\/p>/<\/p>/g;
	$_=~s/  / /g;
	$_=~s/<divx /<div /g;
	$_=~s/<\/divx>/<\/div>/g;
	$_=~s/<supr>/<sup>/g;
	$_=~s/<\/supr>/<\/sup>/g;

	
	$Line=$_;
	$Variable="";
	while($Line =~/<head>(.*?)<\/head>/sgi)
	{
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		$Curr=~s/\&\#x0027\;/\'/gi;

	$Variable .=$PreMatch .$Curr;
	}
	$Variable .=$Line;
	$_ = $Variable;	
	
}

sub GIVEELEMENTNUMBERING
{

	my @elemt = @_;
	
	my $re2="";
	foreach $re2 (@elemt)
	{
		$_=~s/<$re2>/<$re2 class\=\"DUMMY\">/gi;
	}	
	
	my $e2="";

	foreach $e2 (@elemt)
	{
		my $strongcount = 0;
		strongStart:
		$_ =~ s{<$e2\s+([^<>]*>((?:(?!<$e2\s+\b).)*?))<\/$e2>}
		{
			my $strong = $&;
			#print "$strong\n\n";
			$strongcount++;
			$strong =~ s/<$e2\s+([^<>]*>((?:(?!<$e2\s+\b).)*?))<\/$e2>/<$e2\[$strongcount\] $1<\/$e2\[$strongcount\]>/msi;
			$strong;
			#print "$strong\n\n";
		}emsgi;
		goto strongStart if($_ =~ m/<$e2\s+/msi);		
	}
	
}



sub GIVEELEMENTNUMBERINGNEW
{

	my $content = shift(@_);
	my @elemt = @_;
	
	my $re2="";
	foreach $re2 (@elemt)
	{
		$content=~s/<$re2>/<$re2 class\=\"DUMMY\">/gi;
	}	
	
	my $e2="";

	foreach $e2 (@elemt)
	{
		my $strongcount = 0;
		strongStart:
		$content =~ s{<$e2\s+([^<>]*>((?:(?!<$e2\s+\b).)*?))<\/$e2>}
		{
			my $strong = $&;
			#print "$strong\n\n";
			$strongcount++;
			$strong =~ s/<$e2\s+([^<>]*>((?:(?!<$e2\s+\b).)*?))<\/$e2>/<$e2\[$strongcount\] $1<\/$e2\[$strongcount\]>/msi;
			$strong;
			#print "$strong\n\n";
		}emsgi;
		goto strongStart if($content =~ m/<$e2\s+/msi);		
	}

	return $content;
}

#####################

