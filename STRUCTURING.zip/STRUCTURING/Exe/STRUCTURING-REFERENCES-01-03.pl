#######################################################################################
#                                                                                     
#               Tool Name  	:  STRUCTURING-REFERENCES-01-03.pl                                   
#               Version       :  Version 1.0                                          
#               Purpose      :  
#                                
#               Copyrights    :  Integra
#               Developed By  :  (Sathish V.)                       
#               Started On    :  24 - 05 - 2023                                                  
#               Completed On  :                                                   
#               Last Modified :  
#                                                                                     
#######################################################################################

#use strict;
#use warnings;
use Win32;
use File::Copy;
use File::Path;
use File::Basename;
use DBI;
use DBD::mysql;
use LWP::Simple;
#use JSON::Any;
use XML::Simple;
use MongoDB;
use Data::Dumper qw(Dumper);
use HTML::Entities;
use Array::Utils qw(:all);
use List::MoreUtils qw(uniq);
use DateTime;
use Text::Hunspell;
use HTML::Strip;
use DateTime;
use Roman;

use Array::Split qw( split_into );
	
binmode STDOUT, ":utf8";		
			
use Encode qw(encode decode);


my ($filename, $path, $header, $matchtxt, $headinfo, $fpath1)=("","","","","","");
my ($curlcount, $tabcount, $eqcol, $inlinecount, $auxfind, $nonlatex)=(0, 0, 0, 1, 0, 0);
my ($Line, $Variable, $PreMatch, $Curr, $bbox, $fm, $filepath, $fpath, $bbox1, $journaltext, $journaltext1, $snocnt3, $hglt, $bibtext);
my ($Line1, $Variable1, $PreMatch1, $Curr1);
my $ijdata; 
my @jsautr;
my @psautr;
my (@equationcol, @defcollect, @inlinecol, @inlinecol2, @mathconten, @tempmt)=("", "", "", "", "", "");
my %math_remov_ins;
my %tex_link;
my $headcss="";
my $refcontent="";
my $refcontent1="";
my $refcontent2="";



$fpath1 = $ARGV[0];

my $pubname = $ARGV[1];
my $jname = $ARGV[2];
my $functiontype = $ARGV[3];
my $functiontext = $ARGV[4];
my $functiontext2 = $ARGV[4];
my $pubtype = $ARGV[5];


my $outfpath1 = $fpath1;
my $outfpath2 = $fpath1;
my $querypath = $fpath1;

my $dirs = dirname($fpath1);

my $dirs1 = dirname($fpath1);

$dirs1=~s/^(.*?)\\Files\\(.*?)$/$2/sgi;
$dirs1=~s/^(.*?)\/Files\/(.*?)$/$2/sgi;

#print "$dirs1\n\n";
#exit;
my @fnarray="";

my @fildirna = (split/\\/, $dirs);
my $dirnamex = $fildirna[-1];

my $filenamex = basename($fpath1, ".html");

if (-e "$fpath1")
{
}
else
{
	print "File not found";
	exit;
}



$outfpath1=~s/\.html$//g;
$outfpath2=~s/\\document\.html$//g;

undef $/;


my $reftypeb="JOURNAL|BOOK|EDBK|PROC|OTHER|THESIS|WEB|BKSERIES|WKPAPER|SOFT|TECH";

my $serverpath="D\:/Integra/STRUCTURING/ini";
my $exepath="D\:/Integra/STRUCTURING/Exe";


my $rubypath="C\:\\Ruby26\-x64\\bin";


my $filetype="WORD";


my $frontmatter="";

open(ERR, ">:encoding(UTF-8)", "$outfpath1\_Error\.xml")|| die print("Can't open input file!!!");

#open(EX, ">:encoding(UTF-8)", "$outfpath1_GEN\.xml")|| die print("Can't open input file $fpath1.tex!!!");


open(QXX, "<$serverpath/journalinfo\.xml") or die print("$serverpath/journalinfo\.xml NOT FOUND, update the Journal Database!!!");
my $stdata = <QXX>;
close (QXX);	



open(QSS, "<$serverpath/AUTO-EDITING/UNITS\.html") or die print("AUTO-EDITING\/UNITS\.html NOT FOUND, update the Journal Database!!!");
my $units = <QSS>;
close (QSS);

open(CET, "<$serverpath/TEXTENTITIES\.xml") or die print("TEXTENTITIES\.xml NOT FOUND, update the Journal Database!!!");
my $Combine_Entity = <CET>;
close (CET);

open(WYY, "<$serverpath/AUTO-EDITING/$pubtype/$pubname/$jname\.xml");
my $jornalconfig = <WYY>;
close (WYY);

open(HEXA, "<:encoding(UTF-8)", "$serverpath/ENTITIES\-DATA\.xml") or die print("ENTITIES\-DATA\.xml NOT FOUND, update the Journal Database!!!");
my $entities = <HEXA>;
close (HEXA);

open(TXX, "<$serverpath/REFERENCE\-CONFIG/Journals/$pubname/$jname\.ini") or die print("$jname\.ini NOT FOUND, update the Journal Database!!!");
my $bbox4 = <TXX>;
close (TXX);



open(FIN, "<:encoding(UTF-8)", "$fpath1")|| die print("Can't open input file $fpath1!!!");
#open(OUT1, ">$fpath1\.xml")|| die print("$fpath1!!!");
$/="\0";

%Name_NUM=('A'=>1, 'B'=>2, 'C'=>3, 'D'=>4, 'E'=>5, 'F'=>6, 'G'=>7, 'H'=>8, 'I'=>9, 'J'=>10, 'K'=>11, 'L'=>12, 'M'=>13, 'N'=>14, 'O'=>15, 'P'=>16, 'Q'=>17, 'R'=>18, 'S'=>19, 'T'=>20, 'U'=>21, 'V'=>22, 'W'=>23, 'X'=>24, 'Y'=>25, 'Z'=>26);


while(<FIN>)
{
	ELEMENTNUMBERING();
	my $FMDATA="$_";
	REFPRECLEANUP();
	ANYSTYLEMODULE();
	REFFINALCLEANUP();
	REFFINALCLEANUP2();
	FinalCleanup();
	

	
	open(XMLCONTENT, ">:encoding(UTF-8)", "$outfpath1-STEP3\.html")|| die print("Can't open input file !!!");
	print XMLCONTENT "$_";
	close(XMLCONTENT);
	
	$FMDATA=~s/<div\[(\d+)\] class\=\"(bodymatter|front|floats)\">(.*?)<\/div\[\1\]>//sgi;
	$_= "$FMDATA";
	FinalCleanup();
	
	open(XMLCONTENT, ">:encoding(UTF-8)", "$outfpath1-REF\.html")|| die print("Can't open input file");
	print XMLCONTENT "$_";
	close(XMLCONTENT);
	exit;
}

sub FinalCleanup
{
	

	while($_ =~ m/<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>/sgi)
	{
		$_=~s/<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>/<$1>$3<\/$1>/sgi;
	}
	
	
	$_=~s/<(\w+)\[(\d+)\]/<$1/g;
	$_=~s/<\/(\w+)\[(\d+)\]>/<\/$1>/g;
	$_=~s/\s*<\/p>/<\/p>/g;
	$_=~s/  / /g;
	$_=~s/<divx /<div /g;
	$_=~s/<\/divx>/<\/div>/g;
	$_=~s/<supr>/<sup>/g;
	$_=~s/<\/supr>/<\/sup>/g;

	
	$Line=$_;
	$Variable="";
	while($Line =~/<head>(.*?)<\/head>/sgi)
	{
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		$Curr=~s/\&\#x0027\;/\'/gi;

	$Variable .=$PreMatch .$Curr;
	}
	$Variable .=$Line;
	$_ = $Variable;	
	
}



sub JOURNALSTYLEREF
{
	my $Reftexts = shift;
	
	my ($refauetal, $retainauthetal, $etalsty);
	if($bbox4=~ m/<SPECSTYLE TYPE\=\"(\w+)\"\/>/i)
	{
		$type2="$1";
	}
	
	if($bbox4=~ m/<JTITLE STYLE\=\"(\w+)\"\/>/i)
	{
		$jtitlestyle="$1";
	}
	
	if($bbox4=~ m/<BIBITEM TYPE\=\"(YES|NO)\"\/>/i)
	{
		$type1="B$1";
	}
	
	if($bbox4=~ m/<ABBR STYLE\=\"(DOTTED|NODOTTED)\"\/>/i)
	{
		$abbrstyle="$1";
	}
	if($bbox4=~ m/<PAGERANGE TYPE\=\"(FULL|TRUNCATE)\"\/>/i)
	{
		$pagestyle="$1";
	}
	if($bbox4=~ m/<ATITLE TEXTTYPE\=\"(ICAPS)\"\/>/i)
	{
		$atitlestyle="$1";
	}
	if($bbox4=~ m/<REFAUETAL NO\=\"(\d+)\" RETAIN\=\"(\d+)\"\/>/i)
	{
		$refauetal="$1";
		$retainauthetal="$2";
	}
	if($bbox4=~ m/<ETAL TYPE="(DOTTED|NODOTTED|DOTTEDSPACE)"\/>/i)
	{
		$etalsty ="$1";
	}

	#remove author and add etal
	if(defined $refauetal)
	{
		$Line=$Reftexts;
		$Variable="";
		while($Line =~/<AUGRP>((?:(?!<AUGRP\s*\b).)*?)<\/AUGRP>/sgi)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			my $auctach = $refauetal + 1;
			if($Curr =~/(<AUTHOR>((?:(?!<AUTHOR\s*\b).)*?)<\/AUTHOR>(<SEP>((?:(?!<SEP\s*\b).)*?)<\/SEP>)?){$auctach,}/si)
				{
					if($Curr =~/((<AUTHOR>((?:(?!<AUTHOR\s*\b).)*?)<\/AUTHOR>(<SEP>((?:(?!<SEP\s*\b).)*?)<\/SEP>)?){$retainauthetal})/si)
						{
							my $etalauthor = $&;
							$Curr=~s/<AUGRP>((?:(?!<AUGRP\s*\b).)*?)<\/AUGRP>/<AUGRP>$etalauthor<AUTHOR><ETAL>etal<\/ETAL><\/AUTHOR><\/AUGRP>/si;
							$Curr=~s/<\/AUTHOR><AUTHOR>/<\/AUTHOR><SEP>\, <\/SEP><AUTHOR>/sig;
						}
				}
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$Reftexts = $Variable;			
	}
	
	####Author SNM FNM Sequence
	
	if($bbox4=~m/<AUORDER><(\w+)\/><SEP>(.*?)<\/SEP><(\w+)\/><\/AUORDER>/i)
	{
		my $f1="$1";
		my $f2="$2";
		my $f3="$3";
		
		$Line=$Reftexts;
		$Variable="";
		while($Line =~/<AUTHOR>(.*?)<\/AUTHOR>/g)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'

			$Curr =~ s/<$f3>(.*?)<\/$f3>(.*?)<$f1>(.*?)<\/$f1>/<$f1>$3<\/$f1>$2<$f3>$1<\/$f3>/g;
			$Curr =~ s/<SEP>(.*?)<\/SEP>/<SEP>$f2<\/SEP>/g;

			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$Reftexts = $Variable;
	}

	if($bbox4=~m/<EDORDER><(\w+)\/><SEP>(.*?)<\/SEP><(\w+)\/><\/EDORDER>/i)
	{
		my $f1="$1";
		my $f2="$2";
		my $f3="$3";
		
		$Line=$Reftexts;
		$Variable="";
		while($Line =~/<EDGRP>(.*?)<\/EDGRP>/g)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'

			$Curr =~ s/<(\/)?AUTHOR>/<$1EDITOR>/g;

			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$Reftexts = $Variable;

		$Line=$Reftexts;
		$Variable="";
		while($Line =~/<EDITOR>(.*?)<\/EDITOR>/g)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'

			$Curr =~ s/<$f3>(.*?)<\/$f3>(.*?)<$f1>(.*?)<\/$f1>/<$f1>$3<\/$f1>$2<$f3>$1<\/$f3>/g;
			$Curr =~ s/<SEP>(.*?)<\/SEP>/<SEP>$f2<\/SEP>/g;
			$Curr =~ s/<(\/)?EDITOR>/<$1AUTHOR>/g;
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$Reftexts = $Variable;
	}

	####AUTHOR INITIAL STYLE
	if($bbox4=~m/<INITIALS><(\w+)\/><(\w+)\/><\/INITIALS>/i)
	{
		my $fnmformat1 = "$1";
		my $fnmformat2 = "$2";
		
		$Line=$Reftexts;
		$Variable="";
		while($Line =~/<INITS>(.*?)<\/INITS>/g)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $intext="$1";
			
			#to abbrivated
			if($bbox4=~m/<INITIALS type="ABBR"\/>/i)
			{
				$intext =~ s/^([A-Z])([a-z]+)/$1\./g;
				$intext =~ s/ ([A-Z])([a-z]+)/ $1\./g;
				$intext =~ s/ ([A-Z])([a-z]+)/ $1\./g;
				$intext =~ s/\-([A-Z])([a-z]+)/\-$1\./g;
				$intext =~ s/\.([A-Z])([a-z]+)/\.$1\./g;
				$intext =~ s/\-([a-z])([a-z]+)/\-\U$1\E\./g;
				#$intext =~ s/\.$//g;	
			}
			
			if($fnmformat1=~m/^DOTTED/i)
			{
				$intext=~s/([^\&\#x(\w+)])([A-Z])([A-Z])\.?/$1$2\.$3\./g;
				$intext=~s/([^\&\#x(\w+)])([A-Z])([A-Z])\.?/$1$2\.$3\./g;
				$intext=~s/([A-Z])([A-Z])\.?/$1\.$2\./g;
				$intext=~s/([A-Z])([A-Z])\.?/$1\.$2\./g;
				$intext=~s/([A-Z]) ([A-Z])\.?/$1\.$2\./g;
				$intext=~s/([A-Z]) ([A-Z])\.?/$1\.$2\./g;
				$intext=~s/([A-Z])$/$1\./g;
				#print ERR "$intext\n";
			}
			elsif($fnmformat1=~m/^NODOTTED/i)
			{
				$intext=~s/([A-Z])\./$1/g;
			}
	
			if($fnmformat2=~m/^SPACED/i)
			{
				$intext=~s/([A-Z])\.([A-Z])/$1\. $2/g;
				$intext=~s/([A-Z])\.([A-Z])/$1\. $2/g;
				$intext=~s/([^\&\#x(\w+)])([A-Z])([A-Z])/$1$2 $3/g;
				$intext=~s/([^\&\#x(\w+)])([A-Z])([A-Z])/$1$2 $3/g;
			}
	
			elsif($fnmformat2=~m/^CLOSEDUP/i)
			{
				$intext=~s/([A-Z])\. ([A-Z])/$1\.$2/g;
				$intext=~s/([A-Z])\. ([A-Z])/$1\.$2/g;
				$intext=~s/([A-Z]) ([A-Z])/$1$2/g;
				$intext=~s/([A-Z]) ([A-Z])/$1$2/g;
			}
				
			$Curr=~s/<INITS>(.*?)<\/INITS>/<INITS>$intext<\/INITS>/i;

			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$Reftexts = $Variable;
	}
	
	#exit;
	####First Author

	if($bbox4=~m/<F\-AUTHOR>(.*?)<\/F\-AUTHOR>/i)
	{
		my $FASEP = "$1";
		$Reftexts =~ s/<\/AUTHOR><SEP>(.*?)<\/SEP>\n?<AUTHOR>/<\/AUTHOR><SEP>$FASEP<\/SEP><AUTHOR>/g;
	}
	
	
	####Last Author
	if($bbox4=~m/<L\-AUTHOR>(.*?)<\/L\-AUTHOR>/i)
	{
		my $LASEP = "$1";
		
		$Line=$Reftexts;
		$Variable="";
		while($Line =~/<AUGRP>(.*?)<\/AUGRP>/g)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'

			my $aucount=0;
			while($Curr=~/<AUTHOR>/sg)
			{
				$aucount++;
				$Curr=~s/<AUTHOR>/<AUTHOR$aucount>/;
			}

			if($aucount ge "2")
			{
				$Curr=~s/<\/AUTHOR><SEP>([^<]+)<\/SEP><AUTHOR$aucount>/<\/AUTHOR><SEP>$LASEP<\/SEP><AUTHOR$aucount>/g;
			}
			
			if($LASEP=~/\, and /si)
			{
				if($aucount eq "2")
				{
				$Curr=~s/<SEP>\, and <\/SEP>/<SEP> and <\/SEP>/sgi;
				}
			}

			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$Reftexts = $Variable;

		$Reftexts=~s/<AUTHOR(\d+)>/<AUTHOR>/g;
	}

	####TWO Author
	if($bbox4=~m/<TWO\-AUTHOR>(.*?)<\/TWO\-AUTHOR>/i)
	{
		my $TASEP = "$1";
		$Line=$Reftexts;
		$Variable="";
		while($Line =~/<AUGRP>(.*?)<\/AUGRP>/g)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			
			my $aucount=0;
			while($Curr=~/<AUTHOR>/sg)
			{
				$aucount++;
				$Curr=~s/<AUTHOR>/<AUTHOR$aucount>/;
			}

			if($aucount eq "2" && $aucount le "2")
			{
				$Curr=~s/<\/AUTHOR><SEP>([^<]+)<\/SEP><AUTHOR$aucount>/<\/AUTHOR><SEP>$TASEP<\/SEP><AUTHOR$aucount>/g;
			}
			

			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$Reftexts = $Variable;
	
		$Reftexts=~s/<AUTHOR(\d+)>/<AUTHOR>/g;
	}
	
	####Last Editor
	if($bbox4=~m/<L\-EDITOR>(.*?)<\/L\-EDITOR>/i)
	{
		my $LASEP = "$1";

		$Line=$Reftexts;
		$Variable="";
		while($Line =~/<EDGRP>(.*?)<\/EDGRP>/g)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'

			my $aucount=0;
			while($Curr=~/<AUTHOR>/sg)
			{
				$aucount++;
				$Curr=~s/<AUTHOR>/<AUTHOR$aucount>/;
			}

			if($aucount ge "2")
			{
				$Curr=~s/<\/AUTHOR><SEP>([^<]+)<\/SEP><AUTHOR$aucount>/<\/AUTHOR><SEP>$LASEP<\/SEP><AUTHOR$aucount>/g;
			}
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$Reftexts = $Variable;

		$Reftexts=~s/<AUTHOR(\d+)>/<AUTHOR>/g;
	}
	####ETAL SEP
	$Reftexts=~s/<AUTHOR><SNM>(et)<\/SNM><SEP>([^<>]*)<\/SEP><INITS>(al)\.?<\/INITS><\/AUTHOR>/<AUTHOR><ETAL>$1$3<\/ETAL><\/AUTHOR>/gi;
	if($bbox4=~m/<ETAL_SEP>(.*?)<\/ETAL_SEP>/i)
	{
		my $ETALSEP = "$1";
		$Reftexts=~s/<SEP>([^<>]*)<\/SEP><AUTHOR><ETAL>(.*?)<\/ETAL><\/AUTHOR>/$ETALSEP<AUTHOR><ETAL>$2<\/ETAL><\/AUTHOR>/g;
	}
	
	#######ELEMENTS ORDER
	while($bbox4=~m/(<(\w+)\-TYPE>(.*?)<\/\2\-TYPE>)/sg)
	{
		my $RINI="$1";
		my $RTYPES="$2";
		
		if($RINI=~m/<ORDER>(.*?)<\/ORDER>/i)
		{
			my $elements="$1";
			
			my @values="";
			
			while($elements=~m/<(\w+)\/>/sg)
			{
				$elementlist="$1";
				push(@values, "$elementlist");
			}
			
			$Line=$Reftexts;
			$Variable="";
			while($Line =~/<$RTYPES>(.*?)<\/$RTYPES>/sg)
			{
				$PreMatch = $`;
				$Curr = $&;
				$Line = $';
				#'
				
				my $newref="";
				for my $el (@values)
				{
					if ($Curr =~ m/<$el>(.*?)<\/$el>/s)
					{
						$newref .= "$&<SEP><\/SEP>";
					}				
				}
				$Curr=~s/<$RTYPES>(.*?)<\/$RTYPES>/<$RTYPES>$newref<\/$RTYPES>/sg;

				$Variable .=$PreMatch .$Curr;
			}
			$Variable .=$Line;
			$Reftexts = $Variable;				
		}
		
		$Reftexts=~s/<\/COLLAB><\/AUTHOR><\/AUGRP>/<\/COLLAB><\/AUTHOR><\/COLLAB>/gi;
		
		if($RINI=~m/<SEP\-TAGS>(.*?)<\/SEP\-TAGS>/si)
		{
			my $septags="$1";

			while($septags=~m/<\/(\w+)><SEP>(.*?)<\/SEP><(\w+)>/g)
			{
				my $starttag="$1";
				my $endtag="$3";
				my $spr="$2";
				$Line=$Reftexts;
				$Variable="";
				while($Line =~/<$RTYPES>(.*?)<\/$RTYPES>/sg)
				{
					$PreMatch = $`;
					$Curr = $&;
					$Line = $';
					#'
					
					$Curr=~s/<\/$starttag><SEP><\/SEP><$endtag>/<\/$starttag><SEP>$spr<\/SEP><$endtag>/g;
					
					$Variable .=$PreMatch .$Curr;
				}
				$Variable .=$Line;
				$Reftexts = $Variable;					
				
			}

			while($septags=~m/<\/(\w+)><SEP>(.*?)<\/SEP><\/(\w+)>/g)
			{
				my $starttag="$1";
				my $endtag="$3";
				my $spr="$2";
				$Line=$Reftexts;
				$Variable="";
				while($Line =~/<$RTYPES>(.*?)<\/$RTYPES>/sg)
				{
					$PreMatch = $`;
					$Curr = $&;
					$Line = $';
					#'
					
					$Curr=~s/<\/$starttag><SEP><\/SEP><\/$endtag>/<\/$starttag><SEP>$spr<\/SEP><\/$endtag>/g;
				
					$Variable .=$PreMatch .$Curr;
				}
				$Variable .=$Line;
				$Reftexts = $Variable;					
				
			}
		}
		$Reftexts=~s/<\/COLLAB><\/AUTHOR><\/COLLAB>/<\/COLLAB><\/AUTHOR><\/AUGRP>/gi;
	}
	
	while($Reftexts=~/<EDBK>((?:(?!<\/EDBK>).)*?)<\/EDBK>/sgi)
	{
		my $Curref=$&;
	 if($Curref=~/<EDGRP>((?:(?!<\/EDGRP>).)*?)<\/EDGRP>/si)
	 {
	  my $temp=$&;
	  my $edgpcount = () = ($temp=~/<AUTHOR>/gi);
		if($edgpcount < 2)
		{
			$Curref=~s/<\/EDGRP><SEP>(\,)? Eds\./<\/EDGRP><SEP>$1 Ed\./sg;
			$Reftexts=~s/<EDBK>((?:(?!<\/EDBK>).)*?)<\/EDBK>/$Curref/si;
		}
	 }
	 $Reftexts=~s/<(\/)?EDBK>/<$1XEDBK>/si;
	}
	$Reftexts=~s/<(\/)?XEDBK>/<$1EDBK>/sgi;
	
	
	$Reftexts=~s/\?<\/ATITLE><SEP>\. <\/SEP>/\?<\/ATITLE><SEP> <\/SEP>/g;

	if($etalsty eq "DOTTED")
	{
		$Reftexts =~s/<\/ETAL>/\.<\/ETAL>/gi;
	}
	if($etalsty eq "NODOTTED")
	{
		$Reftexts =~s/\.<\/ETAL>/<\/ETAL>/gi;
	}
	
	#print ERR "$Reftexts\n";
	
	if($etalsty eq "DOTTEDSPACE")
	{
		$Reftexts =~s/etal<\/ETAL>/et al<\/ETAL>/gi;
		$Reftexts =~s/<\/ETAL>/\.<\/ETAL>/gi;
	}
	
	if($pagestyle eq "FULL")
	{
		$Line=$Reftexts;	
		$Variable="";	
		while($Line =~/<FPAGE>(e?)(\d+)<\/FPAGE><SEP>(\&ndash\;|\&#?\w+\;)<\/SEP><LPAGE>(\d+)<\/LPAGE>/sg)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			my $elocator="$1";
			my $fpage="$2";
			my $lpage="$4";
			
			my $flen = length("$fpage");
			my $llen = length("$lpage");

			if ($llen lt $flen)
			{
				my $diff= $flen - $llen;
				$diff= abs($diff);
				if($fpage=~m/^(\d{$diff})/i)
				{
					my $cpage="$1";
					$Curr=~s/<LPAGE>/<LPAGE>$elocator$cpage/i;
				}
			}
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$Reftexts = $Variable;		
	}
	elsif($pagestyle eq "TRUNCATE")
	{
		$Line=$Reftexts;	
		$Variable="";	
		while($Line =~/<FPAGE>(\d+)<\/FPAGE><SEP>(\&ndash\;|\&#?\w+\;)<\/SEP><LPAGE>(\d+)<\/LPAGE>/sg)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			my $fpage="$1";
			my $lpage="$3";
			
			my $flen = length("$fpage");
			my $llen = length("$lpage");

			if ($llen eq $flen)
			{
				
				for(1..$flen)
				{
					if(substr($fpage, 0, 1) eq substr($lpage, 0, 1))
					{
						$fpage = substr $fpage, 1;
						$lpage= substr $lpage, 1;
					}
				}
				$Curr=~s/<LPAGE>(\d+)/<LPAGE>$lpage/i;

			}

		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$Reftexts = $Variable;		
	}
	if($jname=~/^(AAE)$/ || $pubname=~/^(HINDAWI)$/si)
	{
		$Line=$Reftexts;	
		$Variable="";	
		while($Line =~/<(BOOK|EDBK|JOURNAL|BKSERIES|PROC|THESIS|TECH)>((?:(?!<\/\1>).)*?)<\/\1>/sg)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
		
				if($Curr!~/<LPAGE>/si)
				{
					$Curr=~s/<SEP>(\,)? pp\. <\/SEP><FPAGE>/<SEP>$1 p\. <\/SEP><FPAGE>/sg;
				}
		
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$Reftexts = $Variable;		
	}
	if($jtitlestyle eq "EXP")
	{
		my $dbh = DBI->connect('dbi:mysql:dbname=ipubedit3;host=localhost','root', '') || print "Could not connect to database: $DBI::errstr";

		$Line=$Reftexts;
		$Variable="";
		while($Line =~/<JTITLE>(.*?)<\/JTITLE>/sgi)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $JRNABBR="\Q$1\E";
			my $JRNABBR1="$1";
			$JRNABBR=~s/\.//g;
			$JRNABBR=~s/\\\\/\\/g;
			$JRNABBR=~s/\\\s*$//g;
			$JRNEXP=~s/\.//g;

			$sql = $dbh->prepare("select J1 from journal_database where J2='$JRNABBR' LIMIT 1");
			$sql->execute() or die "Unable to execute sql: $sql->errstr";
			$rows = $sql->rows;
			if ($rows > 0)
			{
				if(my @row = $sql->fetchrow_array())
				{
					my $JRNEXP="$row[0]";
					#print ERR "$JRNEXP\t$JRNABBR1\n";
					
					if($JRNABBR1!~m/^$JRNEXP$/i)
					{
						$JRNEXP=~s/([A-Z])/\L$1\E/g;
						$JRNEXP=~s/^([a-z])/\U$1\E/g;
						$JRNEXP=~s/ ([a-z])/ \U$1\E/g;
						$JRNEXP=~s/ (With|A|An|To|At|The|Of|In|And|But|Or|Nor|For|Yet|So|After|Although|As|Because|Before|Even|If|In|As|Much|Lest|Now|Once|Provided|Since|Supposing|Than|That|Though|Til|Unless|Until|When|Whenever|Where|Whereas|Wherever|Whether|Which|While|Who|Whoever|Why|On) / \L$1\E /g;
						if($JRNEXP=~m/(\w+)/i)
						{
							$Curr=~s/<JTITLE>(.*?)<\/JTITLE>/<JTITLE>$JRNEXP<\/JTITLE>/i;
						}
					}
				}
			}
			$sql->finish();
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$Reftexts = $Variable;			
		$dbh->disconnect();
	}
	elsif($jtitlestyle eq "ABBR")
	{
		my $dbh = DBI->connect('dbi:mysql:dbname=ipubedit3;host=localhost','root', '') || print "Could not connect to database: $DBI::errstr";

		$Line=$Reftexts;
		$Variable="";
		while($Line =~/<JTITLE>(.*?)<\/JTITLE>/sgi)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $JRNABBR="\Q$1\E";
			my $JRNABBR1="$1";
			$JRNABS=~s/\.//g;
			
			$sql = $dbh->prepare("select J2 from journal_database where J1='$JRNABBR' LIMIT 1");
			$sql->execute() or die "Unable to execute sql: $sql->errstr";
			$rows = $sql->rows;
			if ($rows > 0)
			{
				if(my @row = $sql->fetchrow_array())
				{
					my $JRNABS="$row[0]";
					
					$JRNABS=~s/^([A-Z])([A-Z]+)/$1\L$2\E/gi;
					$JRNABS=~s/ ([A-Z])([A-Z]+)/ $1\L$2\E/gi;

					if($JRNABBR1!~m/^$JRNABS$/i)
					{
						if($JRNABS=~m/(\w+)/i)
						{
							$Curr=~s/<JTITLE>(.*?)<\/JTITLE>/<JTITLE>$JRNABS<\/JTITLE>/i;
						}
						else
						{
							$Curr=~s/IntegraDDOT<\/JTITLE>/<\/JTITLE>/i;
						}
					}
					else
					{
						$Curr=~s/IntegraDDOT<\/JTITLE>/<\/JTITLE>/i;
					}
				}
			}
			$sql->finish();

			$Curr=~s/IntegraDDOT<\/JTITLE>/<\/JTITLE>/i;
			if($abbrstyle=~ m/NODOTTED/i)
			{
				#print ERR "$Curr\n";
				$Curr=~s/\.//i;
			}
			
			
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$Reftexts = $Variable;			
		$dbh->disconnect();
	}
	

	
	return 	$Reftexts;
}



sub REFFINALCLEANUP
{
	if (-e "$dirs\\reftext\.xml")
	{
		open(RTX, "<:encoding(UTF-8)", "$dirs\\reftext\.xml") or die print("$dirs\\reftext\.xml NOT FOUND");
		my $anytext = <RTX>;
		close (RTX);
		
		while($anytext =~ m/\n /sgi)
		{
			$anytext=~s/\n /\n/sgi;
		}
		
		while($anytext =~ m/\n/sgi)
		{
			$anytext=~s/\n//sgi;
		}
		$anytext=~s/–/\-/sgi;
		
		my $xmlref="";
		if($anytext =~ m/(<\?xml (.*?)$)/sgi)
		{
			$xmlref ="$1";
			$anytext=~s/(<\?xml (.*?)$)//sgi;
		}
		$anytext=~s/\&rsqb\"/\&rsqb\;\"/g;
		$anytext=~s/\,\{\"others\"\: (true)\}/\,\{\"family\"\: \"et\"\,\"given\"\: \"al.\"\}/g;
		$anytext=~s/\,\{\"([^\"]+)\"\: (true|false)\}//g;
		$anytext=~s/^\[\{(.*?)\}\]$/\{\"anon\"\:\[\{$1\}\]\}/si;
		
		
		my $temptext="$_";
		
		$_="$anytext";
		
		CHAR2ENTITY();
		
		$anytext="$_";
		
		open(refcontent, ">:encoding(UTF-8)", "$dirs\\refjson\.json")|| die print("Can't open input file !!!");
		print refcontent "$_";
		close(refcontent);
		$_="$temptext";
		
		system("D\:\\INTEGRA\\STRUCTURING\\Exe\\JSON2XML\_Conversion\.exe \"$dirs\\refjson\.json\"");	
		open(RTX, "<:encoding(UTF-8)", "$dirs\\refjson\.xml") or die print("$dirs\\refjson\.xml NOT FOUND");
		my $jxml = <RTX>;
		close (RTX);
		
		$jxml=~s/\&amp\;\#x(\w+)\;/\&\#x$1\;/g;
		$jxml=~s/QQQQnpublished/Unpublished/gi;


		$jxml=~s/\&lt\;imgtaginl(\d+)\/\&gt\;/<imgtaginl$1\/>/g;
		$jxml=~s/^<\_(.*?)refjson\.json>\s*//gi;
		$jxml=~s/\s*<\/\_(.*?)refjson\.json>\s*//gi;
		
		#exit;


		
		$Line=$jxml;
		$Variable="";
		while($Line =~/<anon>(.*?)<\/anon>/sgi)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			if($Curr =~ m/<type>(.*?)<\/type>/sgi)
			{
				my $reftype ="$1";
				$Curr=~s/<anon>/<anon type\=\"$reftype\">/sgi;
			}
			
			$Curr=~s/<anon>/<anon type\=\"OTHER\">/sgi;			
					
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$jxml = $Variable;

		#print ERR "$jxml";
		
		$Line=$jxml;
		$Variable="";
		while($Line =~/<author>(.*?)<\/author>/sgi)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			$Curr=~s/<particle>/<given>/gi;
			$Curr=~s/<\/particle>/<\/given>/gi;

			if($Curr =~ m/<suffix>(.*?)<\/suffix>/gi)
			{
				my $family ="$1";
				if($Curr =~ m/<author /gi)
				{
					$Curr=~s/<author /<author suffix\=\"$family\" /sgi;
					$Curr=~s/<suffix>(.*?)<\/suffix>\s*//gi;
				}
				else
				{
					$Curr=~s/<author>/<author suffix\=\"$family\" \/>/sgi;
					$Curr=~s/<suffix>(.*?)<\/suffix>\s*//gi;
				}
			}

			if($Curr =~ m/<given>(.*?)<\/given>/gi)
			{
				my $given ="$1";
				$Curr=~s/<author /<author given\=\"$given\" /gi;
				$Curr=~s/<author>/<author given\=\"$given\" \/>/gi;
				$Curr=~s/<given>(.*?)<\/given>\s*//gi;
			}
			if($Curr =~ m/<particle>(.*?)<\/particle>/gi)
			{
				my $given ="$1";
				if($Curr =~ m/<author /gi)
				{
					$Curr=~s/<author /<author particle\=\"$given\" \/>/gi;
					$Curr=~s/<particle>(.*?)<\/particle>\s*//gi;
				}
				else
				{
					$Curr=~s/<author>/<author particle\=\"$given\" \/>/gi;
					$Curr=~s/<particle>(.*?)<\/particle>\s*//gi;
				}
			}
			
			if($Curr =~ m/<family>(.*?)<\/family>/gi)
			{
				my $family ="$1";
				if($Curr =~ m/<author /gi)
				{
					$Curr=~s/<author /<author family\=\"$family\" /sgi;
					$Curr=~s/<family>(.*?)<\/family>\s*//gi;
				}
				else
				{
					$Curr=~s/<author /<author family\=\"$family\" /sgi;
					$Curr=~s/<family>(.*?)<\/family>\s*//gi;
				}
			}

			#print ERR "$Curr\n\n";

			$Curr=~s/<\/author>\s*//gi;
			

			
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$jxml = $Variable;
		

		$Line=$jxml;
		$Variable="";
		while($Line =~/<editor>(.*?)<\/editor>/sgi)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			if($Curr =~ m/<given>(.*?)<\/given>/gi)
			{
				my $given ="$1";
				$Curr=~s/<editor>/<editor given\=\"$given\" \/>/gi;
				$Curr=~s/<given>(.*?)<\/given>\s*//gi;
			}
			
			if($Curr =~ m/<family>(.*?)<\/family>/gi)
			{
				my $family ="$1";
				$Curr=~s/<editor /<editor family\=\"$family\" /sgi;
				$Curr=~s/<family>(.*?)<\/family>\s*//gi;
			}
			$Curr=~s/<\/editor>\s*//gi;
					
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$jxml = $Variable;

		
			
		$Line=$inlinemath;
		$Variable="";
		while($Line =~/<inl(\d+)>(.*?)<\/inl\1>/gi)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $inlid="$1";
			my $intext="$2";
			
			$jxml=~s/<imgtaginl$inlid\/>/<img id\=\"inl$inlid\" $intext>/gi;
			
			
			#print ERR "$Curr";		
					
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$inlinemath = $Variable;

		$jxml=~s/\&amp\;comma\;/\,/g;
		$jxml=~s/\&amp\;lsqb\;/\[/g;
		$jxml=~s/\&amp\;rsqb\;/\]/g;
		$jxml=~s/Integradummypr/Proceeding/g;
		$jxml=~s/IntegraDOT/\./sgi;
		$jxml=~s/tplamphashx(\w{5})tplcolon/\&\#x$1\;/g;
		$jxml=~s/tplamphashx(\w{4})tplcolon/\&\#x$1\;/g;
		$jxml=~s/tplamphashx(\w{3})tplcolon/\&\#x$1\;/g;
		$jxml=~s/tplamphash(\w+)tplcolon/\&\#$1\;/g;
		$jxml=~s/tplamp(\w+)tplcolon/\&$1\;/g;
		$jxml=~s/tplamp/\&/g;
		$jxml=~s/tplcolon/\;/g;
		$jxml=~s/Integralt(\w+)Integragt/<$1>/g;
		$jxml=~s/Integralt\/(\w+)Integragt/<\/$1>/g;
		$jxml=~s/tplcolon/\;/g;
		$jxml=~s/\&rbrace\;/\)/g;
		$jxml=~s/\&lbrace\;/\(/g;
		$jxml=~s/\&percent\;/\%/g;
		$jxml=~s/\&lsqb\;/\[/g;
		$jxml=~s/\&rsqb\;/\]/g;
		$xmlref=~s/\&amp\;lsqb\;/\[/g;
		$xmlref=~s/\&amp\;rsqb\;/\]/g;
		$xmlref=~s/Integradummypr/Proceeding/g;
		$xmlref=~s/tplamphashx(\w{5})tplcolon/\&\#x$1\;/g;
		$xmlref=~s/tplamphashx(\w{4})tplcolon/\&\#x$1\;/g;
		$xmlref=~s/tplamphashx(\w{3})tplcolon/\&\#x$1\;/g;
		$xmlref=~s/tplamphash(\w+)tplcolon/\&\#$1\;/g;
		$xmlref=~s/tplamp(\w+)tplcolon/\&$1\;/g;
		$xmlref=~s/\&amp\;comma\;/\,/g;
		$xmlref=~s/tplamp/\&/g;
		$xmlref=~s/tplcolon/\;/g;
		$xmlref=~s/Integralt(\w+)Integragt/<$1>/g;
		$xmlref=~s/Integralt\/(\w+)Integragt/<\/$1>/g;
		$xmlref=~s/tplcolon/\;/g;
		$xmlref=~s/\&rbrace\;/\)/g;
		$xmlref=~s/\&lbrace\;/\(/g;
		$xmlref=~s/\&percent\;/\%/g;
		$xmlref=~s/\&lsqb\;/\[/g;
		$xmlref=~s/\&rsqb\;/\]/g;
		$xmlref=~s/<\/sequence>/<\/sequence>\n/g;
		$xmlref=~s/<\/note><date>(.*?)<\/date>/ $1<\/note>/gi;
		$xmlref=~s/QQQQnpublished/Unpublished/gi;

		while($jxml =~ m/\n /sgi)
		{
			$jxml=~s/\n /\n/sgi;
		}
		
		$jxml=~s/<opt>\s*//g;
		$jxml=~s/<\/opt>\s*//g;
		$jxml=~s/<author ([^<]+)\/>/<AUGRP><author $1\/><\/AUGRP>/g;
		$jxml=~s/<\/AUGRP>\s*<AUGRP>/\n/g;
		$jxml=~s/<editor ([^<]+)\/>/<EDGRP><editor $1\/><\/EDGRP>/g;
		$jxml=~s/<\/EDGRP>\s*<EDGRP>/\n/g;
		$jxml=~s/\s*<editor (given|family)\=\"(eds|Eds)\"\s*\/>\s*<\/EDGRP>/<\/EDGRP>/sg;
		$jxml=~s/<date>(.*?)<\/date>\s*<date>(.*?)<\/date>/<date>$1<\/date>\n<datex>$2<\/datex>/sg;
		$jxml=~s/\n/<SEP><\/SEP>\n/sgi;
		$jxml=~s/<anon ([^<]+)><SEP><\/SEP>/<anon $1>/g;
		$jxml=~s/<\/anon><SEP><\/SEP>/<\/anon>/g;
		$jxml=~s/<anon type\=\"\">/<anon type\=\"OTHER\">/g;
		$jxml=~s/\&\#x02013\;/\&ndash\;/g;
		$jxml=~s/<title>(.*?)&\#x0?201D\;((?:(?!<\/title>).)*?)<\/title>/<title>$1<\/title>/sgi;
		
		
		my $jsoncount="";
		while($jxml =~/<anon /g)
		{
			$jsoncount++;
			$jxml=~s/<anon /<xanon id\=\"$jsoncount\" /i;
			$jxml=~s/<\/anon>/<\/anon$jsoncount>/i;
		}
		$jxml=~s/<xanon /<anon /g;
		
		
		my $xmlcount="";
		while($xmlref =~/<sequence>/g)
		{
			$xmlcount++;
			$xmlref=~s/<sequence>/\n<sequence id\=\"$xmlcount\">/i;
			$xmlref=~s/<\/sequence>/<\/sequence$xmlcount>/i;
		}
		
		my $txtrefcount="";
		while($refcontent1 =~/<p\[(\d+)\] class/g)
		{
			$txtrefcount++;
			$refcontent1=~s/<p\[(\d+)\] class/\n<p\[$1\] id\=\"$txtrefcount\" class/i;
		}			
		
		my $txtrefcount="";
		while($refcontent2 =~/<p\[(\d+)\] class/g)
		{
			$txtrefcount++;
			$refcontent2=~s/<p\[(\d+)\] class/\n<p\[$1\] id\=\"$txtrefcount\" class/i;
		}			

		$jxml=~s/<anon id\=\"(\d+)\" type\=\"(personal\_communication|interview|manuscript)\">/<anon id\=\"$1\" type\=\"OTHER\">/gi;


		$Line=$jxml;
		$Variable="";
		while($Line =~/<anon id\=\"(\d+)\" type\=\"([^\"]+)\">(.*?)<\/anon\1>/sgi)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $anonid="$1";
			my $jrntype="$2";

			if($xmlref =~ m/<sequence id\=\"$anonid\">(.*?)<\/sequence$anonid>/si)
			{
				my $xmlrefcontent="$1";
				if($Curr !~ m/<(AUGRP)>/si)
				{
					if($Curr !~ m/<(EDGRP)>/si)
					{
						if($Curr =~ m/<container-title>(.*?)<\/container-title>/si)
						{
							$Curr=~s/<container-title>(.*?)<\/container-title>/<AUGRP><AUTHOR><COLLAB>$1<\/COLLAB><\/AUTHOR><\/AUGRP>/i;
						}
						elsif($Curr =~ m/<title>(.*?)<\/title>/si)
						{
							$Curr=~s/<title>(.*?)<\/title>/<AUGRP><AUTHOR><COLLAB>$1<\/COLLAB><\/AUTHOR><\/AUGRP>/i;
						}
					}
				}
				
				if($Curr !~ m/<date>/si)
				{
					$Curr=~s/<container\-title>(\d{4}([a-z])?)\.?\,? /<date>$1<\/date>\n<container-title>/i;
				}
				
				if($xmlrefcontent =~ m/\s*\[cited<\/journal><date>(.*?)<\/date>/si)
				{
					if($Curr =~ m/ \[cited<\/container\-title>/si)
					{
						$Curr=~s/ \[cited<\/container\-title>/<\/container\-title>/gi;
						$xmlrefcontent=~s/ ?\[cited<\/journal><date>(.*?)<\/date>/<\/journal><datecomment>\[cited $1<\/datecomment>/gi;
						if($xmlrefcontent =~ m/(<datecomment>(.*?)<\/datecomment>)/si)
						{
							my $dc="$1";
							$Curr=~s/<datex>(.*?)<\/datex>/$dc/i;
						}
					}
				}
			}
			
			if($Curr =~ m/<datex>(.*?)<\/datex>/si)
			{
				my $edate="$1";
				if($Curr =~ m/<note>/si)
				{
					$Curr=~s/<\/note>/ $edate<\/note>/i;
					$Curr=~s/<datex>(.*?)<\/datex><SEP><\/SEP>\s*//i;
					#print ERR "$Curr\n";
				}
				
			}
			$Curr=~s/<\/title><SEP><\/SEP>\s*<title>(.*?)\&\#x02019\;<\/title>\s*<SEP><\/SEP>/\, \&\#x02018\;$1\&\#x02019\;<\/title><SEP><\/SEP>/sgi;
			$Curr=~s/<\/title><SEP><\/SEP>\s*<title>(.*?)<\/title>\s*<SEP><\/SEP>/\, $1<\/title><SEP><\/SEP>/sgi;
			$Curr=~s/<location>(.*?)<\/location><SEP><\/SEP>\s*<location>(.*?)<\/location><SEP><\/SEP>/<location>$1\, $2<\/location><SEP><\/SEP>/sgi;
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$jxml = $Variable;

		$jxml=~s/<\/([^<]+)>\s*<\1>/ /g;
		$jxml=~s/<author given\=\"etal\"\s*\/>/<xauthor given\=\"etal\"\/>/gi;
		$jxml=~s/<author family\=\"([^\"]+)\" given\=\"([^<]+)\&amp\; ([^<]+)\"\s*\/><SEP><\/SEP>\s*<author given\=\"([^\"]+)\"\s*\/>/<author family\=\"$1\" given\=\"$2\" \/><SEP><\/SEP>\n<author family\=\"$3\" given\=\"$4\" \/>/sg;
		$jxml=~s/<author family\=\"([^\"]+)\" particle\=\"\&amp\;\"\s*\/><SEP><\/SEP>\s*<author given\=\"([^\"]+)\"\s*\/>/<author family\=\"$1\" given\=\"$2\" \/>/sg;
		$jxml=~s/<author family\=\"([^\"]+)\" given\=\"([^\"]+)\" suffix\=\"([^\"]+)\" \/><SEP><\/SEP>\n<author given\=\"([^\"]+)\"\s*\/>/<author family\=\"$1\" given\=\"$3\" \/><SEP><\/SEP>\n<author family\=\"$2\" given\=\"$4\" \/>/sg;
		$jxml=~s/<xauthor given\=/<author given\=/gi;
			
		$Line=$jxml;
		$Variable="";
		while($Line =~/<(author|editor) ([^<]+)\/>/sgi)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			$Curr=~s/ particle\=\"(\&amp\;|ed\.|eds\.)\"//g;
			#print ERR "$Curr\n\n";
			
			if($Curr =~ m/<author given\=\"etal\"\s*\/>/sgi)
			{
				#my $etal="$1";
				#$etal=~s/\.//g;
				
				$Curr=~s/<author given\=\"etal\"\s*\/>/<AUTHOR><ETAL>etal<\/ETAL><\/AUTHOR>/i;
			}
		
			
			
			if($Curr =~ m/ family\=\"([^\"]+)\" given\=\"([^\"]+)\"/sgi)
			{
				my $snm="$1";
				my $fnm="$2";
				if($snm !~ m/([a-z])/)
				{
					$Curr=~s/ family\=\"([^\"]+)\" given\=\"([^\"]+)\"/ family\=\"$2\" given\=\"$1\"/g;
				}
				
				if($snm =~ m/^(\&(\w+)\;\.?|\&(\w+)\;\.?\&(\w+)\;\.?|\&(\w+)\;\.?\&(\w+)\;\.?\&(\w+)\;\.?)$/)
				{
					$Curr=~s/ family\=\"([^\"]+)\" given\=\"([^\"]+)\"/ family\=\"$2\" given\=\"$1\"/g;
				}
			}		
			$Curr=~s/<(author|editor) family\=\"([^\"]+)\" given\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><\/AUTHOR>/g;
			$Curr=~s/<(author|editor) family\=\"([^\"]+)\" given\=\"([^\"]+)\" suffix\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><SEP><\/SEP><SUFFIX>$4<\/SUFFIX><\/AUTHOR>/g;
			$Curr=~s/<(author|editor) family\=\"([^\"]+)\" suffix\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><\/AUTHOR>/g;
			$Curr=~s/<(author|editor) family\=\"([^\"]+)\" given\=\"([^\"]+)\" particle\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$4 $2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><SEP><\/SEP><\/AUTHOR>/g;
			$Curr=~s/<(author|editor) family\=\"([^\"]+) ([^\"]+)\" particle\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$4 $2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><SEP><\/SEP><\/AUTHOR>/sg;
			$Curr=~s/<(author|editor) family\=\"([^\"]+)\" particle\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$3<\/SNM><SEP><\/SEP><INITS>$2<\/INITS><SEP><\/SEP><\/AUTHOR>/sg;

			if($Curr =~ m/<author given\=\"([^\"]+)\"\s*\/>/sgi)
			{
				my $givenn="$1";
				$givenn=~s/\.//g;
				$Curr=~s/<author given\=\"([^\"]+)\"\s*\/>/<AUTHOR><COLLAB>$givenn<\/COLLAB><SEP><\/SEP><\/AUTHOR>/i;
			}
			
			if($Curr =~ m/<editor given\=\"([A-Z])([A-Z])([a-z]+)\"\s*\/>/sgi)
			{
				my $givenn="$1";
				my $snmn="$2$3";
				$givenn=~s/\.//g;
				
				$Curr=~s/<editor given\=\"([^\"]+)\"\s*\/>/<AUTHOR><SNM>$snmn<\/SNM><SEP><\/SEP><INITS>$givenn<\/INITS><SEP><\/SEP><\/AUTHOR>/i;
			}				
			$Curr=~s/<AUTHOR><SNM>\&\#(\w+)\;<\/SNM><SEP><\/SEP><INITS>(.*?)<\/INITS><\/AUTHOR>/<AUTHOR><SNM>$2<\/SNM><SEP><\/SEP><INITS>\&\#$1\;<\/INITS><\/AUTHOR>/sg;
			
			while($Curr =~ m/ ([A-Z])\.?<\/SNM><SEP><\/SEP><INITS>/sgi)
			{
				$Curr=~s/ ([A-Z])\.?<\/SNM><SEP><\/SEP><INITS>/<\/SNM><SEP><\/SEP><INITS>$1/g;
			}
			
					
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$jxml = $Variable;

		$Line=$jxml;
		$Variable="";
		while($Line =~/<anon id\=\"(\d+)\" type\=\"([^\"]+)\">(.*?)<\/anon\1>/sgi)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $anonid="$1";
			
			my $jrntype="$2";
			
			if($jrntype =~ m/OTHER/si)
			{
				if($Curr =~ m/(<doi>)/si)
				{
					$jrntype="article\-journal";
					$Curr=~s/<anon id\=\"(\d+)\" type\=\"([^\"]+)\">/<anon id\=\"$1\" type\=\"article\-journal\">/i;
				}
			}
			if($jrntype =~ m/book/si)
			{
				if($Curr =~ m/<publisher>Journal of /si)
				{
					$jrntype="article\-journal";
					$Curr=~s/<publisher>Journal of (.*?)<\/publisher>/<container\-title>Journal of $1<\/container\-title>/gi;
					$Curr=~s/<anon id\=\"(\d+)\" type\=\"([^\"]+)\">/<anon id\=\"$1\" type\=\"article\-journal\">/i;
				}
				if($Curr =~ m/<publisher>(.*?)(Journal|PLOS ONE)(.*?)<\/publisher>/i)
				{
					$jrntype="article\-journal";
					$Curr=~s/<publisher>(.*?)Journal(Journal|PLOS ONE)<\/publisher>/<container\-title>$1$2$3<\/container\-title>/gi;
					$Curr=~s/<anon id\=\"(\d+)\" type\=\"([^\"]+)\">/<anon id\=\"$1\" type\=\"article\-journal\">/i;
				}
			}
			if($jrntype =~ m/article\-journal/si)
			{
				if($Curr =~ m/(<publisher>)/si)
				{
					$jrntype="book";
					$Curr=~s/<anon id\=\"(\d+)\" type\=\"([^\"]+)\">/<anon id\=\"$1\" type\=\"book\">/i;
				}
			}
			if($jrntype =~ m/(Proceeding|paper\-conference)/si)
			{
				if(($Curr =~ m/(<doi>)/si) and ($Curr !~ m/(<location>)/si))
				{
					$jrntype="article\-journal";
					$Curr=~s/<anon id\=\"(\d+)\" type\=\"([^\"]+)\">/<anon id\=\"$1\" type\=\"article\-journal\">/i;
				}
			}

			if($Curr =~ m/<EDGRP>/si)
			{
				$Curr=~s/<anon id\=\"(\d+)\" type\=\"([^\"]+)\">/<anon id\=\"$1\" type\=\"chapter\">/g;
				$jrntype="chapter";
			}

			if($jrntype =~ m/article\-journal/si)
			{
				
				$Curr=~s/<container\-title>(.*?)\,?<\/container\-title>/<JTITLE>$1<\/JTITLE>/g;
				$Curr=~s/<title>(.*?)\,?<\/title>/<ATITLE>$1<\/ATITLE>/g;
				if($Curr !~ m/<JTITLE>/si)
				{
					if($Curr =~ m/<ATITLE>/si)
					{
						$Curr=~s/<ATITLE>(.*?) ?\? (.*?)\,?<\/ATITLE>/<ATITLE>$1\?<\/ATITLE><SEP><\/SEP>\n<JTITLE>$2<\/JTITLE>/g;
					}
				}
			}
			
			if($jrntype =~ m/book/si)
			{
				if($Curr =~ m/<container\-title>/si)
				{
					$Curr=~s/<anon id\=\"(\d+)\" type\=\"([^\"]+)\">/<anon id\=\"$1\" type\=\"chapter\">/g;
					$jrntype="chapter";
				}
			}

			if($jrntype =~ m/chapter/si)
			{
				$Curr=~s/<container\-title>(.*?)\,?<\/container-title>/<BTITLE>$1<\/BTITLE>/sg;
				$Curr=~s/<title>(.*?)\,?<\/title>/<CHAPTER>$1<\/CHAPTER>/sg;
			}

			if($jrntype =~ m/book/si)
			{
				$Curr=~s/<title>(.*?)\,?<\/title>(.*?)<title>(.*?)<\/title>/<CHAPTER>$1<\/CHAPTER>$2<BTITLE>$3<\/BTITLE>/sg;
				$Curr=~s/<title>(.*?)\,?<\/title>/<BTITLE>$1<\/BTITLE>/sg;
			}

			if($jrntype =~ m/paper\-conference/si)
			{
				$Curr=~s/<container\-title>(.*?)\,?<\/container-title>/<PROCTITLE>$1<\/PROCTITLE>/sg;
				$Curr=~s/<title>(.*?)\,?<\/title>/<CHAPTER>$1<\/CHAPTER>/sg;
			}
			if($jrntype =~ m/thesis/si)
			{
				$Curr=~s/<container\-title>(.*?)\,?<\/container-title>/<PROCTITLE>$1<\/PROCTITLE>/sg;
				$Curr=~s/<title>(.*?)\,?<\/title>/<CHAPTER>$1<\/CHAPTER>/sg;
				$Curr=~s/<genre>(.*?)\,?<\/genre>/<OTHERINFO>$1<\/OTHERINFO>/sg;
			}
			
			if($jrntype =~ m/webpage/si)
			{
				$Curr=~s/<title>(.*?)\,?<\/title>/<ATITLE>$1<\/ATITLE>/sg;
				$Curr=~s/<note>(.*?)\,?<\/note>/<SEPNOTE>$1<\/SEPNOTE>/sg;
			}
			if($jrntype =~ m/OTHER/si)
			{
				if($xmlref =~ m/<sequence id\=\"$anonid\">(.*?)<\/sequence$anonid>/si)
				{
					my $xmlrefcontent="$1";
					$xmlrefcontent=~s/<\/([^<]+)><([^<]+)>/<\/$1>\n<$2>/g;
					
					if($Curr =~ m/<AUGRP>(.*?)<\/AUGRP>/si)
					{
						my $AUGRP="$1";
						$xmlrefcontent=~s/<author>(.*?)<\/author>/<AUGRP>$AUGRP<\/AUGRP>/sg;
					}
					$Curr=~s/<anon id\=\"(\d+)\" type\=\"([^\"]+)\">(.*?)<\/anon\1>/<anon id\=\"$1\" type\=\"$2\">$xmlrefcontent<\/anon$1>/si;
				}
				
				if($Curr =~ m/<note>(.*?)<\/note>/i)
				{
					if($Curr =~ m/<note>Available at (.*?) \(accessed (.*?)\)\.?<\/note>/i)
					{
						$Curr=~s/<note>Available at (.*?) \(accessed (.*?)\)\.?<\/note>/<SEPNOTE>Available at<\/SEPNOTE>\n<url>$1<\/url>\n<DATEINCITATION>\(accessed $2\)\.<\/DATEINCITATION>/gi;
					}
					if($Curr =~ m/<note>Available at (.*?) \(assessed (.*?)\)\.?<\/note>/i)
					{
						$Curr=~s/<note>Available at (.*?) \(assessed (.*?)\)\.?<\/note>/<SEPNOTE>Available at<\/SEPNOTE>\n<url>$1<\/url>\n<DATEINCITATION>\(accessed $2\)\.<\/DATEINCITATION>/gi;
					}
				}
				if($Curr =~ m/<url>(.*?)<\/url>/i)
				{
					if($Curr =~ m/<note>Available at (.*?) \(accessed (.*?)\)\.<\/note>/i)
					{
						$Curr=~s/<note>Available at (.*?) \(accessed (.*?)\)\.<\/note>/<SEPNOTE>Available at<\/SEPNOTE>\n<url>$1<\/url>\n<DATEINCITATION>\(accessed $2\)\.<\/DATEINCITATION>/gi;
					}
					$Curr=~s/<date>(\(acce(.*?))<\/date>/<DATEINCITATION>$1<\/DATEINCITATION>/gi;
				}					
				$Curr=~s/<title>(.*?)\,?<\/title>/<ATITLE>$1<\/ATITLE>/sg;
				$Curr=~s/<collection\-title>(.*?)\,?<\/collection\-title>/<SERIES>$1<\/SERIES>/sg;
				
				$Curr=~s/<note>(.*?)\,?<\/note>/<OTHERINFO>$1<\/OTHERINFO>/sg;
				$Curr=~s/<url>(.*?)\,<\/url>/<URI>$1<\/URI>/sg;
				$Curr=~s/<url>(.*?)<\/url>/<URI>$1<\/URI>/sg;
				$Curr=~s/<anon id\=\"(\d+)\" type\=\"([^\"]+)\"><ATITLE>(.*?)<\/ATITLE>/<anon id\=\"$1\" type\=\"$2\"><AUGRP><COLLAB>$3<\/COLLAB><\/AUGRP>/sg;
			}
			
			$Curr=~s/<collection\-title>(.*?)\,?<\/collection\-title>/<SERIES>$1<\/SERIES>/sg;
			$Curr=~s/<title>(.*?)\,?<\/title>/<ATITLE>$1<\/ATITLE>/sg;
			$Curr=~s/<note>(.*?)\,?<\/note>/<OTHERINFO>$1<\/OTHERINFO>/sg;
			$Curr=~s/<url>(.*?)<\/url>/<URI>$1<\/URI>/sg;
			$Curr=~s/<genre>(.*?)\,?<\/genre>/<OTHERINFO>$1<\/OTHERINFO>/sg;
			#####PAGE REPLACEMENT
							
			if($xmlref =~ m/<sequence id\=\"$anonid\">(.*?)<\/sequence$anonid>/si)
			{
				my $xmlrefcontent="$1";
				if($xmlrefcontent =~ m/<url>(.*?)<\/url>/si)
				{
					my $url="$1";
					$url=~s/ //gi;
					$Curr=~s/<URI>(.*?)<\/URI>/<URI>$url<\/URI>/i;
					$Curr=~s/<URI>(.*?)\,<\/URI>/<URI>$1<\/URI>/i;
				}
				if($xmlrefcontent =~ m/<pages>(.*?)<\/pages>/si)
				{
					my $pages="$1";
					
					if($pages =~ m/([a-z]|A-Z)/si)
					{
						$Curr=~s/<pages>(.*?)<\/pages>/<pages>$pages<\/pages>/gi;
					}
				}
				if($xmlrefcontent =~ m/<date>(.*?)<\/date>/si)
				{
					my $date="$1";
					if($date =~ m/(([a-z]|A-Z)| |\-)/si)
					{
						$Curr=~s/<date>(.*?)<\/date>/<date>$date<\/date>/gi;
					}
				}
				
				####COLLAB REPLACEMENT
				if($xmlrefcontent =~ m/<author>(.*?)\.?\,?<\/author>/si)
				{
					my $au="$1";
					
					my $collabword="organis?z?ation|limited| ?ltd\\. ?| ?Inc\\.? ?|National |Council|Ministry|Programme|Control|Data|Nacional|Instituto|Core|consortium| Corp|Group|Super|Public|Holdings|Packaging|Software|Oracle|Pharmaceutical|Pharma|Research|universitaire|University|Foundation|School| NASA|Resorts|Hotel|Community|Nation|Services|Restaurant|Treatment|Health|Center|Centre|Technol|Publishing|Publications|Books|Industries|Newspaper|Assoc|Hospital|Management|Capital|Commission|Companies|Company|Foundation| Fund |Trust|Press|Studio|Bureau|Investment|Agency|Development|Gmbh|United|y de|General de|Associated|Press|Brooklyn|Nine\-Nine|ASTM|Standard|Plastics?|Components?|\\.com|Review|\\bLaws|\\bLaw\\.|\\bChina|India|universitaire|University|School|Ltd|Open Science|Framework|Common Sense|Media|Rights|Technologies|Library|Online|Adobe|Systems|WHO|Improving|SFOR";
					
					if($au =~ m/( (of|the|is|on|co) )/si)
					{
						$Curr=~s/<AUGRP>(.*?)<\/AUGRP>/<AUGRP><AUTHOR><COLLAB>$au<\/COLLAB><\/AUTHOR><\/AUGRP>/sgi;
					}
					elsif($au =~ m/( |>|^)?($collabword)(\,|\:| |\<|\.|\;|$)/si)
					{
						if($au =~ m/^($collabword)\, ([A-Z)])\.?$/si)
						{
						}
						elsif($au =~ m/($collabword)\, ([A-Z])\.? /si)
						{
							#print ERR "aa$au\n\n";
						}
						else
						{
							$Curr=~s/<AUGRP>(.*?)<\/AUGRP>/<AUGRP><AUTHOR><COLLAB>$au<\/COLLAB><\/AUTHOR><\/AUGRP>/sgi;
						}
					}
					
				}
			}							
			if($Curr =~ m/<OTHERINFO>(doi (.*?))<\/OTHERINFO>/si)
			{
				$Curr=~s/<OTHERINFO>(doi (.*?))\,?<\/OTHERINFO>/<doi>$1<\/doi>/sg;
			}							
			$Curr=~s/<datex>(.*?)\.?<\/datex>/<OTHERINFO>$1<\/OTHERINFO>/sg;
			$Curr=~s/<date>(.*?)\.?<\/date>/<YEAR>$1<\/YEAR>/g;
			$Curr=~s/<volume>(\w+)\((\w+)\)\:<\/volume>/<VOLUME>$1<\/VOLUME><SEP><\/SEP>\n<ISSUE>$2<\/ISSUE>/gi;
			$Curr=~s/<volume>(.*?)\((.*?)\)?\,?<\/volume>/<VOLUME>$1<\/VOLUME><SEP><\/SEP>\n<ISSUE>\($2\)<\/ISSUE>/g;
			$Curr=~s/<volume>(.*?)\:\s*<\/volume>/<volume>$1<\/volume>/sgi;
			$Curr=~s/<volume>(.*?)\:\s*(.*?)<\/volume>/<VOLUME>$1<\/VOLUME><SEP><\/SEP>\n<ISSUE>$2<\/ISSUE>/g;
			$Curr=~s/<volume>(.*?)\,?<\/volume>/<VOLUME>$1<\/VOLUME>/g;
			$Curr=~s/<issue>(.*?)\,?<\/issue>/<ISSUE>$1<\/ISSUE>/g;
			$Curr=~s/<pages>p\.? (.*?)<\/pages>/<pages>$1<\/pages>/gi;
			$Curr=~s/<pages>p?p\.? (\w+)\.?<\/pages>/<FPAGE>$1<\/FPAGE>/gi;
			$Curr=~s/<pages>(.*?)\-(.*?)\.?\,?<\/pages>/<FPAGE>$1<\/FPAGE><SEP><\/SEP>\n<LPAGE>$2<\/LPAGE>/g;
			$Curr=~s/<pages>(.*?)\&ndash\;(.*?)\.?\,?<\/pages>/<FPAGE>$1<\/FPAGE><SEP><\/SEP>\n<LPAGE>$2<\/LPAGE>/g;
			$Curr=~s/<pages>(.*?) (.*?)\.?\,?<\/pages>/<FPAGE>$1<\/FPAGE><SEP><\/SEP>\n<LPAGE>$2<\/LPAGE>/g;
			$Curr=~s/<pages>(.*?)\.?\,?<\/pages>/<FPAGE>$1<\/FPAGE>/g;
			$Curr=~s/<FPAGE>\(pp\. ?/<FPAGE>/gi;
			$Curr=~s/\)<\/LPAGE>/<\/LPAGE>/gi;
			$Curr=~s/\)<\/ISSUE>/<\/ISSUE>/gi;
			$Curr=~s/<ISSUE>\(/<ISSUE>/gi;
			$Curr=~s/<publisher>(.*?)\,?<\/publisher>/<PUBNAME>$1<\/PUBNAME>/g;
			$Curr=~s/<location>(.*?)\,?<\/location>/<PUBLOC>$1<\/PUBLOC>/g;
			$Curr=~s/<edition>(.*?)\,?<\/edition>/<EDITION>$1<\/EDITION>/g;
			$Curr=~s/<YEAR>\((.*?)\)\.?\,?<\/YEAR>/<YEAR>$1<\/YEAR>/g;
			$Curr=~s/\,<\/YEAR>/<\/YEAR>/g;
			$Curr=~s/<LPAGE>(.*?) doi (.*?)<\/LPAGE>/<LPAGE>$1<\/LPAGE><SEP><\/SEP>\n<doi>doi $2<\/doi>/gi;
			$Curr=~s/<doi>doi /<doi>/g;
			$Curr=~s/<doi>(.*?)\.?\,?<\/doi>/<REFDOI>$1<\/REFDOI>/g;
			$Curr=~s/<URI>(https?\:\/\/?doi\..*?)<\/URI>/<REFDOI>$1<\/REFDOI>/sg;
			$Curr=~s/<OTHERINFO>(.*?)\,?<\/OTHERINFO>(.*?)<OTHERINFO>(.*?)<\/OTHERINFO>/<OTHERINFO>$1<\/OTHERINFO>$2<REFCOMMENT>$3<\/REFCOMMENT>/sg;
			$Curr=~s/<LPAGE>000<\/LPAGE><SEP><\/SEP>\s*//g;

			if($Curr =~ m/<author family\=\"([^\"]+)\"\s*\/>/si)
			{
				if($Curr =~ m/<AUGRP>(.*?)<\/AUGRP>/si)
				{
					my $AUGRP="$1";
					
					if($xmlref =~ m/<sequence id\=\"$anonid\">(.*?)<\/sequence$anonid>/si)
					{
						my $xmlrefcontent="$1";
						if($xmlrefcontent =~ m/<author>(.*?)<\/author>/si)
						{
							my $uauthor="$1";
							
							$Curr=~s/<AUGRP>(.*?)<\/AUGRP>/<AUGRP type\=\"unc\">$uauthor<\/AUGRP>/sg;
						}
					}
				}
			}
			$Curr=~s/<AUGRP>\s*<author literal\=\"([^\"]+)\"\s*\/><\/AUGRP>/<AUGRP type\=\"unc\">$1<\/AUGRP>/sg;
			$Curr=~s/\s*<\/(\w+)>/<\/$1>/g;
			$Curr=~s/<ISSUE>\((\w+)\)<\/ISSUE>/<ISSUE>$1<\/ISSUE>/g;
			$Curr=~s/<ISSUE>\((\w+\-\w+)\)<\/ISSUE>/<ISSUE>$1<\/ISSUE>/g;
			
			if($Curr =~ m/ J<\/ATITLE>/si)
			{
				$Curr=~s/<JTITLE>/<JTITLE>J. /g;
				$Curr=~s/ J<\/ATITLE>/<\/ATITLE>/g;
			}
			
			$Curr=~s/<ATITLE>\.\s*/<ATITLE>/gi;
			$Curr=~s/\,<\/VOLUME>/<\/VOLUME>/g;
			$Curr=~s/<FPAGE>pp\. ?/<FPAGE>/g;
			$Curr=~s/<(OTHERINFO|REFCOMMENT)>Available(.*?)<\/\1>/<SEPNOTE>Available$2<\/SEPNOTE>/gi;
			$Curr=~s/\[cited<\/JTITLE>/\[cited\]<\/JTITLE>/gi;
			$Curr=~s/<isbn>(.*?)<\/isbn>/<ISBN>$1<\/ISBN>/gi;
			$Curr=~s/(\&quot\;|\")<\/(ATITLE|CHAPTER)>/<\/$2>/g;
			$Curr=~s/\.<\/(ATITLE|CHAPTER)>/<\/$1>/g;
			$Curr=~s/<(ATITLE|CHAPTER)>(\&quot\;|\")/<$1>/g;
			$Curr=~s/<datecomment>(.*?)\,?<\/datecomment>/<DATECOMMENT>$1<\/DATECOMMENT>/sg;
			$Curr=~s/ (\w+)\;<\/YEAR>/ $1<\/YEAR>/gi;
			
			if($Curr !~ m/<YEAR>/si)
			{
				$Curr=~s/<ATITLE>(\d{4})([a-z])\, /<YEAR>$1$2<\/YEAR><SEP><\/SEP>\n<ATITLE>/gi;
				$Curr=~s/ ?\((forthcoming|in press|inpress)\)<\/INITS><\/AUTHOR><\/AUGRP>/<\/INITS><\/AUTHOR><\/AUGRP><SEP><\/SEP>\n<YEAR>$1<\/YEAR>/gi;
			}

			if($Curr !~ m/<YEAR>/si)
			{
				if($Curr =~ m/<VOLUME>(\d{4})<\/VOLUME>/si)
				{
					$Curr=~s/<VOLUME>(\d{4})<\/VOLUME>/<YEAR>$1<\/YEAR>/gi;
					if($Curr !~ m/<VOLUME>(\d{4})<\/VOLUME>/si)
					{
						$Curr=~s/<ISSUE>(.*?)<\/ISSUE>/<VOLUME>$1<\/VOLUME>/gi;
					}
				}
			}

			if($jrntype =~ m/article\-journal/si)
			{
				if($Curr !~ m/<VOLUME>/si)
				{
					$Curr=~s/ (\d+)<\/ATITLE>/<\/ATITLE><SEP><\/SEP>\n<VOLUME>$1<\/VOLUME>/gi;
					$Curr=~s/<OTHERINFO>(\d+)<\/OTHERINFO><SEP><\/SEP>\s*<FPAGE>(\d+)<\/FPAGE>/<FPAGE>$1<\/FPAGE><SEP><\/SEP>\n<VOLUME>$2<\/VOLUME>/sgi;
				}
			}
			
			if($Curr =~ m/<ATITLE>(\w+)<\/ATITLE>/si)
			{
				my $djtitle="$1";
				$Curr=~s/<JTITLE>/<JTITLE>$djtitle\. /gi;
				$Curr=~s/<ATITLE>(\w+)<\/ATITLE><SEP><\/SEP>\s*//gi;
			}
			
			$Curr=~s/<REFDOI>(.*?)<\/REFDOI>(.*?)<REFDOI>(.*?)<\/REFDOI>/$2<REFDOI>$3<\/REFDOI>/sgi;
			$Curr=~s/<REFDOI>https?\:\/\/?doi\.org\//<REFDOI>/gi;
					
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$jxml = $Variable;
		
		while($jxml =~ m/<AUGRP type\=\"unc\">(.*?)<\/AUGRP>/gi)
		{
			my $AUTEXT="$1";
			my $STRAUTHOR;
			$STRAUTHOR = Author("<au>$AUTEXT<\/au>");
			$STRAUTHOR=~s/<snm>/<SNM>/g;
			$STRAUTHOR=~s/<\/snm>/<\/SNM>/g;
			$STRAUTHOR=~s/<x>/<SEP>/g;
			$STRAUTHOR=~s/<\/x>/<\/SEP>/g;
			$STRAUTHOR=~s/<inits>/<INITS>/g;
			$STRAUTHOR=~s/<\/inits>/<\/INITS>/g;
			$STRAUTHOR=~s/<AUGRP>\s*/<AUGRP>/g;
			$jxml=~s/<AUGRP type\=\"unc\">\Q$AUTEXT\E<\/AUGRP>/$STRAUTHOR/;
		}			

		$Line=$jxml;
		$Variable="";
		while($Line =~/<AUGRP type\=\"unc\">(.*?)<\/AUGRP>/g)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $AUTEXT="$1";
			
			$STRAUTHOR = Author("<au>$AUTEXT<\/au>");
	
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$jxml = $Variable; 	

		$jxml=~s/ (in review\-\w+)\.?<\/INITS><\/AUTHOR><\/AUGRP><SEP><\/SEP>/<\/INITS><\/AUTHOR><\/AUGRP><SEP><\/SEP>\n<YEAR>$1<\/YEAR><SEP><\/SEP>/g;
		$jxml=~s/<SNM>(in press)<\/SNM><SEP><\/SEP><INITS>([^<]+) ([^<]+)<\/INITS><SEP><\/SEP><\/AUTHOR><\/AUGRP><SEP><\/SEP>/<SNM>$2<\/SNM><SEP><\/SEP><INITS>$3<\/INITS><SEP><\/SEP><\/AUTHOR><\/AUGRP><SEP><\/SEP>\n<YEAR>$1<\/YEAR><SEP><\/SEP>/sgi;
		$jxml=~s/<anon id\=\"(\d+)\" type\=\"article\-journal\">(.*?)<\/anon\1>/<JOURNAL>$2<\/JOURNAL>/sg;
		$jxml=~s/<anon id\=\"(\d+)\" type\=\"chapter\">(.*?)<\/anon\1>/<EDBK>$2<\/EDBK>/sg;
		$jxml=~s/<anon id\=\"(\d+)\" type\=\"book\">(.*?)<\/anon\1>/<BOOK>$2<\/BOOK>/sg;
		$jxml=~s/<anon id\=\"(\d+)\" type\=\"paper\-conference\">(.*?)<\/anon\1>/<PROC>$2<\/PROC>/sg;
		$jxml=~s/<anon id\=\"(\d+)\" type\=\"webpage\">(.*?)<\/anon\1>/<WEB>$2<\/WEB>/sg;
		$jxml=~s/<anon id\=\"(\d+)\" type\=\"OTHER\">(.*?)<\/anon\1>/<OTHER>$2<\/OTHER>/sg;
		$jxml=~s/<anon id\=\"(\d+)\" type\=\"thesis\">(.*?)<\/anon\1>/<THESIS>$2<\/THESIS>/sg;
		$jxml=~s/<anon id\=\"(\d+)\" type\=\"report\">(.*?)<\/anon\1>/<OTHER>$2<\/OTHER>/sg;
		$jxml=~s/<anon id\=\"(\d+)\" type\=\"([^\"]+)\">(.*?)<\/anon\1>/<OTHER>$2<\/OTHER>/sg;
		$jxml=~s/\n//g;
		$jxml=~s/<\/($reftypeb)><($reftypeb)>/<\/$1>\n\n<$2>/g;
		$jxml=~s/<au>(.*?)<\/au>/<AUGRP><COLLAB>$1<\/COLLAB><\/AUGRP>/g;
		$jxml=~s/<OTHER><YEAR>(.*?) (\d+)<\/YEAR>/<OTHER><AUGRP><AUTHOR><COLLAB>$1<\/COLLAB><\/AUTHOR><\/AUGRP><YEAR>$2<\/YEAR>/g;
		$jxml=~s/\.<\/URI>/<\/URI>/gi;
		$jxml=~s/<YEAR>\((.*?)\):<\/YEAR>/<YEAR>$1<\/YEAR>/gi;
		$jxml=~s/<\/COLLAB><SEP><\/SEP><\/AUTHOR><\/AUGRP>/<\/COLLAB><\/AUTHOR><\/AUGRP>/gi;
		$jxml=~s/<\/INITS><SEP><\/SEP><\/AUTHOR>/<\/INITS><\/AUTHOR>/gi;
		$jxml = JOURNALSTYLEREF("$jxml");
		$jxml =~ s/<SEPNOTE>(.*?)<\/SEPNOTE><SEP><\/SEP>/<SEP>$1 <\/SEP>/g;			
		$jxml=~s/<SEP><\/SEP>/<SEP>\, <\/SEP>/gi;
		$jxml=~s/<SEP>\, <\/SEP><\/(\w+)>\n/<SEP><\/SEP><\/$1>\n/gi;
		$jxml=~s/<SEP>\, <\/SEP><\/(\w+)>$/<SEP><\/SEP><\/$1>/gi;
		$jxml=~s/<\/SEP><SEP>//gi;
		$jxml=~s/<AUTHOR><SNM>et<\/SNM><SEP>\,? <\/SEP><INITS>al\.<\/INITS><\/AUTHOR>/<AUTHOR><ETAL>etal\.<\/ETAL><\/AUTHOR>/gi;
		$jxml=~s/( Eds)<\/INITS><\/AUTHOR><\/AUGRP><SEP>/<\/INITS><\/AUTHOR><\/AUGRP><SEP>$1/gi; 
		$jxml=~s/\.<\/OTHERINFO><SEP>\./<\/OTHERINFO><SEP>\./gi; 
		$jxml=~s/\.<\/REFCOMMENT><SEP>\./<\/REFCOMMENT><SEP>\./gi;
		$jxml=~s/\. URL<\/PROCTITLE><SEP>([^><]+)<\/SEP><URI>/<\/PROCTITLE><SEP>\. URL$1<\/SEP><URI>/gi;

		$Line=$jxml;
		$Variable="";
		while($Line =~/<JOURNAL>(.*?)<\/JOURNAL>/g)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			$Curr=~s/<VOLUME>(\d+)\,([^><]+)<\/VOLUME>/<VOLUME>$1<\/VOLUME>\,$2/sgi;
			$Curr=~s/<\/JTITLE><SEP>([^<]+)<\/SEP>\s*<VOLUME>(.*?) (.*?)<\/VOLUME>/ $2<\/JTITLE><SEP>$1<\/SEP>\n<VOLUME>$3<\/VOLUME>/sg;
			$Curr=~s/<VOLUME>Vol\. /<VOLUME>/gi;
			$Curr=~s/\,<\/JTITLE>/<\/JTITLE>/gi;
			$Curr=~s/\.?\,<\/ATITLE>/<\/ATITLE>/gi;
					
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$jxml = $Variable;
		
		$jxml =~ s/<SEP>([^<]+)<\/SEP><LPAGE>XXXX<\/LPAGE>//gi;
		
		
		$Line=$jxml;
		$Variable="";
		while($Line =~/<EDBK>(.*?)<\/EDBK>/g)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			if($Curr!~m/<AUGRP>/si)
			{
				$Curr=~s/<EDBK>(.*?)<SEP>\. In\: <\/SEP><EDGRP>(.*?)<\/EDGRP>/<EDBK><EDGRP>$2<\/EDGRP><SEP><b>\.<\/b> <\/SEP>$1<SEP>\. <\/SEP>/sgi;
			}
			
			
			$Curr=~s/<\/BTITLE><SEP>([^<]+)<\/SEP>\s*<VOLUME>(.*?) (.*?)<\/VOLUME>/ $2<\/BTITLE><SEP>$1<\/SEP>\n<VOLUME>$3<\/VOLUME>/sg;
			$Curr=~s/<SEP><\/SEP>//gi;
					
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$jxml = $Variable;

		$jxml =~ s/<($reftypeb)>/<p class\=\"$1\">/g;
		$jxml =~ s/<\/($reftypeb)>/<\/p>/g;
	
		my $txtrefcount="";
		while($jxml =~/<p class/g)
		{
			$txtrefcount++;
			$jxml=~s/<p class/\n<p id\=\"$txtrefcount\" class/i;
			$jxml=~s/<\/p>/\n<\/p$txtrefcount>/i;
		}			

		$Line=$refcontent1;
		$Variable="";
		while($Line =~/<p\[(\d+)\] id\=\"(\d+)\" ([^<]+)>(.*?)<\/p\[\1\]>/sg)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $pid="$2";
			
			while($Curr =~ m/<(i|b|u)>(.*?)<\/\1>/sgi)
			{
				my $emptag="$1";
				my $empcontent="$2";
				
				$empcontent=~s/(\&\#x)([0-9A-Za-z]{4};)/${1}0${2}/sgi;
				$empcontent=~s/(\&\#x)([0-9A-Za-z]{3};)/${1}00${2}/sgi;
				
				if($jxml =~ m/<p id\=\"($pid)\" class\=\"([^\"]+)\">(.*?)<\/p\1>/si)
				{
					my $stref="$3";
					while($stref =~ m/<(ATITLE|CHAPTER|BTITLE|OTHERINFO|PROCTITLE)>(.*?)<\/\1>/sgi)
					{
						my $reftag="$1";
						my $refcnt="$2";
						if($refcnt =~ m/\Q$empcontent\E/si && $empcontent !~ m/^in$/i)
						{
							if($stref !~ m/<JTITLE>\Q$empcontent\E<\/JTITLE>/si)
							{
								$refcnt =~ s/\Q$empcontent\E/<$emptag>$empcontent<\/$emptag>/;
							}							
							$stref =~ s/<$reftag>(.*?)<\/$reftag>/<$reftag>$refcnt<\/$reftag>/si;
							$jxml =~ s/<p id\=\"($pid)\" class\=\"([^\"]+)\">(.*?)<\/p\1>/<p id\=\"$1\" class\=\"$2\">$stref<\/p$1>/si;
							goto ENDWHILE;
						}	
						
					}
					ENDWHILE:						
				}
			}

			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$refcontent1 = $Variable; 

		$jxml =~ s/\, (\w+)<\/ATITLE><SEP>([^<]+)<\/SEP><JTITLE>/<\/ATITLE><SEP>$2<\/SEP><JTITLE>$1 /gi;
		$jxml =~ s/<([A-Z]+)>/<span class\=\"$1\">/g;
		$jxml =~ s/<\/([A-Z]+)>/<\/span>/g;

		$Line=$jxml;
		$Variable="";
		while($Line =~/<p id\=\"(\d+)\" class\=\"([^\"]+)\">(.*?)<\/p\1>/sg)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $pid="$1";
			if($refcontent2=~ m/<p\[(\d+)\] id\=\"$pid\" ([^<]+)>(.*?)<\/p\[\1\]>/si)
			{
				my $edref="$3";
			}
			if($refcontent1 =~ m/<p\[(\d+)\] id\=\"$pid\" ([^<]+)>(.*?)<\/p\[\1\]>/si)
			{
				my $plainref="$3";
				if($refcontent2=~ m/<p\[(\d+)\] id\=\"$pid\" ([^<]+)>(.*?)<\/p\[\1\]>/si)
				{
					my $edref="$3";
					if($edref=~ m/<span class\=\"(ICORRECTED|DCORRECTED)\">/si)
					{
						$Curr=~s/<p id\=\"(\d+)\" class\=\"([^\"]+)\">/<p class\=\"$2\"><span class\=\"UNSTRUCTREF\">$plainref<\/span><span class\=\"EDITEDREF\">$edref<\/span><span class\=\"reflabel\"><\/span>/g;
					}
					else
					{
						$Curr=~s/<p id\=\"(\d+)\" class\=\"([^\"]+)\">/<p class\=\"$2\"><span class\=\"UNSTRUCTREF\">$plainref<\/span><span class\=\"reflabel\"><\/span>/g;
					}
				}
			}
			
			$Curr=~s/<\/p(\d+)>/<\/p>/g;
					
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$jxml = $Variable; 				

		$jxml=~s/\.<\/span><span class\=\"SEP\"><\/span>/<\/span><span class\=\"SEP\">\.<\/span>/g;

			if($_=~/<div\[(\d+)\] class\=\"references\">(.*?)<\/div\[\1\]>/s)
			{
				$_=~s/<div\[(\d+)\] class\=\"references\">(.*?)<\/div\[\1\]>/<div\[$1\] class\=\"references\">$jxml<\/div\[$1\]>/si;
			}

		
	}
}

sub ANYSTYLEMODULE
{
	chdir("D\:\\Ruby32\-x64\\bin");
	system("ruby\.exe anystyle \-\-stdout \-f json\,xml parse \"$dirs\\reftext\.txt\" \>$dirs\\reftext\.xml");
	
}



sub REFPRECLEANUP
{
	
	$_=~s/((?:\s*<span(\[\d+\]) class="QUERY">.*?<\/span\2>\s*)+)(<\/p(?:\[\d+\])?>)/$3$1/sgi;
	
	my %ref_hash = MOVE_OUT_QUERY(1);
	
	
	#move inline out of reference
	my %ref_inl_hash;
	if($_=~/<div(\[\d+\]) class="references">(.*?)<\/div\1>/si)
	{
		my $ref = $2;
		my $count = 1;
		#while ($ref=~/<(p\[\d+\]) class="[^"]+">(.*?)<\/\1>/sgi)
		while ($ref=~/<(p\[\d+\])[^><]+>(.*?)<\/\1>/sgi)
		{
			my $r_pr = $&;
			while ($r_pr=~/<span\[\d+\] class="TEX">/sgi)
			{
				($r_pr, $ref_inl_hash{$count}) = &CUT_N_JOIN($r_pr, 'span', 'inline', 'IntegraINL', $count, 'CUT');
				$count++;
			}
			$r_pr=~s/<(\/)?p/<$1Xp/sgi;
			#$ref=~s/<(p\[\d+\]) class="[^"]+">(.*?)<\/\1>/$r_pr/si;
			$ref=~s/<(p\[\d+\])[^><]+>(.*?)<\/\1>/$r_pr/si;
		}
		$ref=~s/<(\/)?Xp/<$1p/sgi;
		$_=~s/<div(\[\d+\]) class="references">(.*?)<\/div\1>/<div$1 class="references">$ref<\/div$1>/si;
	}

	while($_=~/<p(\[\d+\]) class=\"ref[^\"]+\">((?:(?!<\/p>).)*?)<\/p\1>/sgi)
	{
		my $temp = $&;
		$temp=~s/(([A-Z]?)\d+)\&\#x0?2013;(\2\d+)/$1\-$3/sgi;
		$temp=~s/<(\/?)p\b/<$1XXp/sgi;
		$_=~s/<p(\[\d+\]) class=\"ref[^\"]+\">((?:(?!<\/p>).)*?)<\/p\1>/$temp/si;
	}
	$_=~s/<(\/?)XXp\b/<$1p/sgi;
	
	
	CHAR2ENTITY();
	
	
	if($_=~/<div\[(\d+)\] class\=\"references\">(.*?)<\/div\[\1\]>/s)
	{
		$refcontent="$2";
		$refcontent1="$2";
		$refcontent2="$2";
		
		
		$refcontent=~s/<refanchor>([^<>]*)<\/refanchor>//g;
		$refcontent=~s/<DCORRECTED> <\/DCORRECTED>//g;
		$refcontent=~s/<ICORRECTED> <\/ICORRECTED>/ /g;
		$refcontent =~ s/<sc\[(\d+)\] class\=\"dummy\">(.*?)<\/sc\[\1\]>/$2/gis;
		
		$refcontent2=~s/<refanchor>([^<>]*)<\/refanchor>//g;
		$refcontent2=~s/<DCORRECTED> <\/DCORRECTED>/<span class\=\"DCORRECTED\"> <\/span>/g;
		$refcontent2=~s/<ICORRECTED> <\/ICORRECTED>/<span class\=\"ICORRECTED\"> <\/span>/g;
		$refcontent2 =~ s/<sc\[(\d+)\] class\=\"dummy\">(.*?)<\/sc\[\1\]>/$2/gis;
		
		
		while($refcontent=~/<ins\[(\d+)\] ([^<]+)>(.*?)<\/ins\[\1\]>/sg)
		{
			$refcontent=~s/<ins\[(\d+)\] ([^<]+)>(.*?)<\/ins\[\1\]>/$3/sg;
		}
		while($refcontent=~/<del\[(\d+)\] ([^<]+)>(.*?)<\/del\[\1\]>/sg)
		{
			$refcontent=~s/<del\[(\d+)\] ([^<]+)>(.*?)<\/del\[\1\]>//sg;
		}
		
		$refcontent=~s/\s*<\/p\[(\d+)\]>/<\/p\[$1\]>/sgi;
		$refcontent=~s/<p\[(\d+)\]>\s*/<p\[$1\]>/sgi;
		$refcontent=~s/<b>\((\d+)\)/ <b>\($1\)/g;
		$refcontent=~s/<b>(\d+)/ <b>$1/g;
		$refcontent=~s/<b>\((\d+)/ <b>\($1/g;
		
		
		$refcontent=~s/  / /g;
		$refcontent=~s/  / /g;
		$refcontent=~s/\%/\&percent\;/g;
		$refcontent=~s/([A-z]+)(\d+)\((\d{4})\)(\d+)\&\#x02013\;(\d+)\.<\/p\[(\d+)\]>/$1\, $3\, $2\, $4\-$5\.<\/p\[$6\]>/g;
		$refcontent=~s/<i>\.<\/i>/\./gi;
		$refcontent=~s/<i>(\d+)<\/i>/$1/gi;
		$refcontent=~s/ Advance online publication\. / /gi;	
		
		$refcontent=~s/ et\.? ?al\./ et al\. /gi;
		
		####SUFFIX
		$refcontent=~s/\, 2nd\,/\, II,/gi; 
		$refcontent=~s/\, 3rd\,/\, III,/gi; 
		$refcontent=~s/\, 4th\,/\, IV\,/gi; 
		$refcontent=~s/\, 5th\,/\, V\,/gi; 
		
		
		$refcontent=~s/ PMID\: ?(\w+)\.?\s*<\/p\[(\d+)\]>/<\/p\[$2\]>/gi;
		$refcontent=~s/ PMID\: ?(\w+)\.//g; 		
		$refcontent=~s/ PMID\: ?(\w+)\.//g;
		$refcontent=~s/ ?\[PMID\: ?(\w+)\]\.//g;
		$refcontent=~s/ ?PMID (\d+)\.?//g;
		$refcontent=~s/http\:\/\/dx\.doi org/http\:\/\/dx\.doi\.org/gi;
		$refcontent=~s/<\/i>\.https\:/<\/i>\. https\:/gi;
		$refcontent=~s/<\/i>\,(\d+)/<\/i>\, $1/gi;
		$refcontent=~s/\!\.<i>/\!\. <i>/gi;
		$refcontent=~s/\, \((\d{4})\)\.([A-Za-z])/\, \($1\)\. $2/gi;
		$refcontent=~s/ fromwww\./ from www\./gi;
		$refcontent=~s/\(Vol\. (\d+)\, Issue (\d+)\, pp\. (\d+)\&\#x02013\;(\d+)\)/\, $1\($2\)\, $3\&\#x02013\;$4/gi;
		$refcontent=~s/Vol\. (\d+)\, no\.? (\d+)\, pp?\. (\d+)/$1\($2\)\, $3/gi;
		
		
		$refcontent=~s/\, ?\, ?/\, /g;
		$refcontent=~s/  / /g;
		$refcontent=~s/ Small (\d{4})\, (\d+)\, (\d+)\.<\/p\[(\d+)\]>/ $1\, Small, $2\, $3\.<\/p\[$4\]>/gi;

		$refcontent=~s/  / /g;
		$refcontent=~s/\&\#x02010\;/\-/g;
		$refcontent=~s/\&\#x00026\;/\&amp;/g;
		$refcontent=~s/\&\#8211\;/\-/g;
		$refcontent=~s/http\:\/\/dx\.doi\.org\///g;
		
		$refcontent=~s/ \.([A-z]+)/\. $1/g;
		$refcontent=~s/ \,/\, /g;
		$refcontent=~s/\.\./\./g;
		$refcontent=~s/\:<\/p\[(\d+)\]>/<\/p\[$1\]>/g;
		$refcontent=~s/Unpublished/QQQQnpublished/gi;
		$refcontent=~s/ \&\#x0201C\;(.*?)\&\#x0201D\; (\d+) (.*?) (\d+)\&\#x02013\;(\d+)\./ \&\#x0201C\;$1\&\#x0201D\; $3\, $2\, $4\&\#x02013\;$5\./g;
		$refcontent=~s/\,\,/\,/g;
		$refcontent=~s/&\#x0?2018;(.*?)&\#x0?2019;/$1/g;
		$refcontent=~s/ \&\#x0201C\;(.*?)\&\#x0201D\; /\, $1\, /g;
		$refcontent=~s/\,\,/\,/g;
		$refcontent=~s/\, p (\d+)<\/p\[(\d+)\]>/\, $1<\/p\[$2\]>/gi;
		$refcontent=~s/\, p (\d+)<\/p\[(\d+)\]>/\, $1<\/p\[$2\]>/gi;
		$refcontent=~s/ pp (\d+)\-(\d+)\.?<\/p\[(\d+)\]>/ $1\-$2\.<\/p\[$3\]>/g;
		$refcontent=~s/ pp (\d+)\.?<\/p\[(\d+)\]>/ $1\.<\/p\[$2\]>/g;
		$refcontent=~s/\, pp (\w+)\-(\w+) \((\w+)\)\./\, $1\-$2 \($3\)\./gi;
		$refcontent=~s/\,<\/i>(\d+)\, /\,<\/i> $1\, /g;
		$refcontent=~s/<\/i>(\d+)\;/<\/i> $1\;/gi;
		$refcontent=~s/  / /g;
		$refcontent=~s/ (\d{4})\,([A-z]+)/ $1\, $2/g;
		$refcontent=~s/ ([A-Z])([a-z]+)\: ?(\w+)(\&ndash\;|\&\#x02013\;|\-)(\w+)\.?<\/p\[(\d+)\]>/\: $1$2\, $3$4$5\.<\/p\[$6\]>/g;
		$refcontent=~s/ ([A-Z])([a-z]+)\: ?(\w+)(\&ndash\;|\&\#x02013\;|\-)(\w+)\.?<\/p\[(\d+)\]>/\: $1$2\, $3$4$5<\/p\[$6\]>/g;
		$refcontent=~s/(\d+) ?\: (\d+)\&\#x02013\;(\d+)\.?<\/p\[(\d+)\]>/$1\: $2\-$3<\/p\[$4\]>/gi;
		$refcontent=~s/(\d+) ?\, (\d+)\&\#x02013\;(\d+)\.?<\/p\[(\d+)\]>/$1\, $2\-$3<\/p\[$4\]>/gi;
		$refcontent=~s/(\d+)\: (\d+) ?\&\#x02013\; ?(\d+)\./$1\: $2\-$3\./g;
		$refcontent=~s/ (\d+)\;(\w+)\:(\w+)\&\#x02013\;(\w+)\./ $1\; $2\: $3\-$4\./sgi;
		$refcontent=~s/ (\d+)\&\#x02013\;(\d+)\.<\/p\[(\d+)\]>/\, $1\-$2\.<\/p\[$3\]>/gi;
		$refcontent=~s/ (\d{4})\;(\w+)\((\w+)\)\:(\d+)\-(\d+)\./ $1\, $2\($3\)\: $4\-$5\./gi;
		$refcontent=~s/ (\d{4})\;(\d+)\:(\d+)\-(\d+)\./ $1\, $2\: $3\-$4\./gi;
		$refcontent=~s/ Volume (\d+)\, Number (\d+)\, / $1\($2\)\: /g;
		$refcontent=~s/ Volume (\d+)\, Number (\d+)/ $1\($2\)/g;
		$refcontent=~s/(\d+)\: (\d+) ?\&\#x02013\; ?(\d+)/$1\: $2\-$3/g;
		$refcontent=~s/ (\d+) (\w+)(\&ndash\;|\&\#x02013\;|\-)(\w+)\.?<\/p\[(\d+)\]>/ $1\: $2-$4<\/p\[$5\]>/gi;
		$refcontent=~s/ (\d+) ?\((\d+)\)\,? ?(\d+)(\&ndash\;|\&\#x02013\;|\-)(\d+)\.?<\/p\[(\d+)\]>/ $1\($2\)\: $3-$5<\/p\[$6\]>/g;
		$refcontent=~s/ Vol\. (\d+)\, Issue (\d+)\, / $1\($2\)\: /g;
		$refcontent=~s/ (\d+)\,? \(?(\w+)\)?\,? (\w+)(\&ndash\;|\&\#x02013\;|\-)(\w+)\.?<\/p\[(\d+)\]>/ $1\($2\)\: $3\-$5<\/p\[$6\]>/sgi;
		$refcontent=~s/ (\d+)\((\w+)\), (\w+)\-(\w+)\.<\/p\[(\d+)\]>/ $1\($2\)\: $3\-$4<\/p\[$5\]>/gi;
		$refcontent=~s/ (\d+)\&\#x02013\;(\d+)\+(\d+)\.<\/p\[(\d+)\]>/\, $1\-$2\+$3\.<\/p\[$4\]>/gi;
		$refcontent=~s/\,\,/\,/gi;
		$refcontent=~s/ (\d+)\((\w+)\), (\w+)\-(\w+)\. / $1\($2\)\: $3\-$4\. /gi;
		$refcontent=~s/<b>(\d+)<\/b>\, (\d+)\-(\d+)\./$1\: $2\-$3\./g; 
		$refcontent=~s/<b>(\d+)<\/b>\((\d+)\)\, (\w+)\./$1\($2\)\: $3\./g;
		$refcontent=~s/<b>(\d+)<\/b>\((\d+)\)\, (\d+)\-(\d+)\./$1\($2\)\: $3\-$4\./g;
		$refcontent=~s/<\/i>(\d+) \((\d+)\)\,/<\/i> $1\($2\)\,/g;
		$refcontent=~s/ In\:/ in\:/g;
		$refcontent=~s/Journal of(\w+)/Journal of $1/gi;
		$refcontent=~s/\,<i>\, <i>//gi;
		$refcontent=~s/ In([A-Z])\./ In $1\./g; 
		$refcontent=~s/\&amp\;(([A-Z])([a-z]+)\, ([A-Z])\.)/\&amp\; $1/g;
		$refcontent=~s/\&amp\;(([A-Z])([a-z]+)\, )/\&amp\; $1/g;
		$refcontent=~s/\&amp\;(([A-Z])([a-z]+)\-)/\&amp\; $1/g;
		$refcontent=~s/\,\.\&amp\;/\, \&amp\;/gi; 
		$refcontent=~s/ \.<\/p\[(\d+)\]>/\.<\/p\[$1\]>/gi;
		$refcontent=~s/ Vol\. (\d+)\.(\w+)/ Vol\. $1\. $2/gi;
		$refcontent=~s/([A-Z])([a-z]+)\&amp\;/$1$2 \&amp\;/g; 
		$refcontent=~s/<p\[(\d+)\] ([^<]+)>\[(\d+)\]\s*//g;
		$refcontent=~s/<p\[(\d+)\] ([^<]+)>//g;
		$refcontent=~s/\((eds\.|ed\.)\)/$1/gi;
		$refcontent=~s/\((eds|ed)\)/$1\./gi;
		$refcontent=~s/<\/i> \(ed\. (.*?)\)/<\/i>\, ed\. $1/gi;
		$refcontent=~s/<\/i> \(eds\. (.*?)\)/<\/i>\, eds\. $1/gi;
		$refcontent=~s/ (eds\.|ed\.) / $1\, /gi;
		$refcontent=~s/ (\d{4})\.([A-Z])([a-z]+)/ $1\. $2$3/g; 
		$refcontent=~s/\.\./\./gi;
		$refcontent=~s/<\/p\[\d+\]>//g;
		$refcontent=~s/ (Jr|Sr) ([A-Z])/\, $1 $2/g;
		$refcontent=~s/ JR(\b)/ J\.R\.\,/g;
		$refcontent=~s/ SR(\b)/ S\.R\.$1/g;
		$refcontent=~s/\,\,/\,/g;
		$refcontent=~s/\.\./\./g;
		$refcontent=~s/\((\d{4}) Edition\)\:/$1 Edition\,/g;
		$refcontent=~s/ \((\d+)([a-z]+) Ed\.?\)/\, $1$2 Edition\,/gi;
		$refcontent=~s/\,\./\,/gi; 
		$refcontent=~s/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\;(\d+)/$1 $2/gi;
		$refcontent=~s/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d+)/$1 $2/gi;
		#$refcontent=~s/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4})/$1\, $2/gi;
		$refcontent=~s/ (\d{4})\;(\d+)\(/ $1\, $2\(/gi;
		$refcontent=~s/ (\d+) (\d+)\;/ $1 $2\; /gi;
		$refcontent=~s/\; (\d+)doi\:/\; $1\, doi\:/gi;
		$refcontent=~s/\. (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)(\,| |\;|\:)/\.\, $1$2/gi;
		#$refcontent=~s/ (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)(\,| |\;|\:)/ $1\-$2/gi;
		$refcontent=~s/(\d+)\;(\d+)doi\:/$1\, $2\, doi\:/gi;
		$refcontent=~s/doi\:/ doi\:/gi;
		$refcontent=~s/ (\d{4})\;\(/ $1\; \(/gi;
		#print ERR "$refcontent\n";
		#exit;
		
		$refcontent=~s/  / /g;
		$refcontent=~s/<i>//g;
		$refcontent=~s/<\/i>//g;
		$refcontent=~s/<b>//g;
		$refcontent=~s/<\/b>//g;
		$refcontent=~s/\((\d+)\-(\d+)\)\. DOI/$1-$2\. DOI/g;
		$refcontent=~s/ (\d+)\, (\w+) \((\d{4})\)\./ Vol\. $1\, $2 \($3\)\./g;
		$refcontent=~s/\, \((\d{4})\)\: /\, \($1\)\. /g;
		$refcontent=~s/\, \((\d{4})\) \: /\, \($1\)\. /g;
		$refcontent=~s/ \((\d{4})\) ?\: / \($1\)\. /g;
		$refcontent=~s/\;(\d+)\((\d+)\)\:(\w+)\-(\w+)\.\n/\;  $1\($2\)\:$3\-$4\.\n/g;
		$refcontent=~s/\;(\d+)\((\d+)\)\:(\w+)\.\n/\; $1\($2\)\:$3\.\n/g;
		$refcontent=~s/\;(\d+)\:(\w+)\.\n/\; $1\, $2\.\n/g;
		$refcontent=~s/\;(\d+)\((\d+)\)\:(\d+)\-(\d+)\;/\; $1\($2\)\:$3\-$4\. /g;
		$refcontent=~s/\;(\d+)\:(\d+)\-(\d+)\./\; $1\: $2\-$3\./g;
		$refcontent=~s/ \(Ph\.D\. Thesis\)\./\, Ph\.D\. Thesis\,/g;
		$refcontent=~s/\. \((\d{4})\)\./\, $1\,/g;
		$refcontent=~s/(\d+)\((\d+)\)\, (\d+)\&\#x02013\;(\d+)\./$1\($2\)\, $3\-$4\./gi;
		$refcontent=~s/(January|February|March|April|May|June|July|August|September|October|November|December)\&\#x02013\;(January|February|March|April|May|June|July|August|September|October|November|December)/$1\-$2/gi;
		$refcontent=~s/\,(\d+)\((\d+)\)/\, $1\($2\)/gi;
		$refcontent=~s/\,((\d+)\, (\d+)\&\#x02013\;)/\, $1/gi;
		$refcontent=~s/\,((\d+)\, (\d+)\&\#x02013\;)/\, $1/gi;
		$refcontent=~s/\((\d{4})\)\:/\&dummylbrace\;$1\&dummyrbrace\;\:/g;
		$refcontent=~s/\.\((\d{4})\)\. /\. \($1\)\. /g; 
		$refcontent=~s/ \((\d{4})\)/\, $1/g;
		$refcontent=~s/\((\d{4})\) /$1 /g;
		$refcontent=~s/\&dummylbrace\;/\(/g;
		$refcontent=~s/\&dummyrbrace\;/\)/g;
		$refcontent=~s/\((\d{4})([a-z])\)/$1$2/g;
		$refcontent=~s/\)/\&rbrace\;/g;
		$refcontent=~s/\(/\&lbrace\;/g;
		$refcontent=~s/(\w+)\&\#x02013\;(\w+)/$1\-$2/g;
		$refcontent=~s/(\w+)\&ndash\;(\w+)/$1\-$2/g;
		$refcontent=~s/ (\w+)\:(\d+)\-/ $1\: $2\-/g;
		$refcontent=~s/ (\w+)\:([A-z])(\d+)\-/ $1\: $2$3\-/g;
		$refcontent=~s/ (\w+)\:([A-z])(\d+)\./ $1\: $2$3\./g;
		$refcontent=~s/\:/\: /g;
		$refcontent=~s/  / /g;
		$refcontent=~s/https\: /https\:/g;
		$refcontent=~s/http\: /http\:/g;
		$refcontent=~s/ doi\, / /gi;
		$refcontent=~s/\, 10\.(\w+)\//\, doi 10\.$1\//gi;		
		$refcontent=~s/\; 10\.(\w+)\//\, doi 10\.$1\//gi;		
		$refcontent=~s/(\d+) DOI\:? /$1\. doi /gi;
		$refcontent=~s/(\d+)\. DOI\:? /$1\. doi /gi;
		$refcontent=~s/\/(\w+)\: /\/$1\:/g;
		$refcontent=~s/([a-z])(\d+)\: (\d+)\-(\d+)\.\n/$1 $2\: $3\-$4\.\n/gi;
		$refcontent=~s/([a-z])(\d+)\: (\d+)\-(\d+)\n/$1 $2\: $3\-$4\n/gi;
		$refcontent=~s/ (\d+)\, (\d+)\: (\d+)\-(\d+)\n/ $1\($2\)\: $3\-$4\n/g;
		$refcontent=~s/<(\w+)\[\d+\] class\=\"dummy\">/Integralt$1Integragt/g;
		$refcontent=~s/<\/(\w+)\[\d+\]>/Integralt\/$1Integragt/g;
		$refcontent=~s/<(\w+)\[\d+\]>/Integralt$1Integragt/g;
		$refcontent=~s/<\/(\w+)\[\d+\]>/Integralt\/$1Integragt/g;
		$refcontent=~s/p\- (\d+)\.\n/p\. $1\.\n/g;
		$refcontent=~s/pp\-(\d+)\n/pp\. $1\n/g;
		$refcontent=~s/ p\. ?(\d+)\.?\n/ p\. $1\n/g;
		$refcontent=~s/ pp\.? (\d+)\.\n/ pp\. $1\n/g;
		$refcontent=~s/ p\. (\d+)\-(\d+)\.\n/ $1\-$2\n/gi;
		$refcontent = HTML::Entities::decode($refcontent);
		$refcontent=~s/\[doi\: (.*?)\]/doi\: $1/gi;
		$refcontent=~s/\&(\w+)\;/tplamp$1tplcolon/g;
		$refcontent=~s/\&\#(\w+)\;/tplamphash$1tplcolon/g;
		$refcontent=~s/tplamprbracetplcolon\: (\w+)\-/\)\: $1\-/g;
		$refcontent=~s/\. \n/\.\n/g;
		$refcontent=~s/(\w+)\-(\w+)\. 10\.(\w+)\//$1\-$2\. doi 10\.$3\//g;
		$refcontent=~s/(\w+)\: ?(\w+)\. 10\.(\w+)\//$1\: $2\-000\. doi 10\.$3\//g;
		$refcontent=~s/(\(| )(\d{4})(.*?) ?(\d{4})\: (\w+)\-(\w+)\. doi/$1$2$3, Vol $4\: $5\-$6\. doi/g;
		$refcontent=~s/\. 10\.(\d+)\//\. doi 10\.$1\//g;
		$refcontent=~s/ (\d{4})([a-z]) / $1$2\, /g;
		$refcontent=~s/ pp\. ISBN / ISBN /g;
		$refcontent=~s/ ISBN\, / ISBN /g;
		$refcontent=~s/Vol\. (\d+)\((\w+)\)\, (\w+)\-(\w+)/$1\: $2\, $3\-$4\./g;
		$refcontent=~s/ (\d+)\, (\w+) (\d{4})\.\n/ $1\, $2\-XXXX\. \($3\)\.\n/gi;
		$refcontent=~s/([A-Z])([A-Z]) (\d{4}) /$1$2\, $3 /g;
		$refcontent=~s/([A-Z])([A-Z]) (\d{4})([a-z])\,/$1$2\, $3$4\,/g;
		$refcontent=~s/(\d+)\, (\d+) (\d+)\-(\d+)\.\n/$1\, $2\, $3\-$4\.\n/g;
		$refcontent=~s/(\d+)\, (\d+) (\d+)\-(\d+)\n/$1\($2\)\, $3\-$4\n/g;
		$refcontent=~s/ (\d+)\: (\d+)p\.\n/ $1\: $2\.\n/g;
		$refcontent=~s/tplamplbracetplcolonpp\. (\w+)\-(\w+)tplamprbracetplcolon/\(pp\. $1\-$2\)/gi;
		$refcontent=~s/ pp (\d+)\-(\d+)\.\n/ $1\-$2\.\n/g;
		$refcontent=~s/tplamplbracetplcolon(accessed .*?)tplamprbracetplcolon/\($1\)/g;
		$refcontent=~s/tplamplbracetplcolon(\w+)\)\: (\w+)\-(\w+)\./\($1\)\: $2\-$3\./g;
		$refcontent=~s/tplamplbracetplcolon(\w+)\)\: (\w+)\-(\w+)/\($1\)\: $2\-$3/g;
		$refcontent=~s/tplamplbracetplcolon(\w+)tplamprbracetplcolon\, (\w+)\-(\w+)\, (\w+)\.?\n/\($1\)\, $2\-$3\, $4\n/gi;
		$refcontent=~s/tplamplbracetplcolonDocument (.*?)tplamprbracetplcolon/\(Document $1\)/gi;
		$refcontent=~s/tplamplbracetplcolon(\w+)\-(\w+)\)\: (\w+)\-(\w+)\./\($1\-$2\)\: $3\-$4\./g;
		$refcontent=~s/tplamplbracetplcolon(\w+)\-(\w+)\)\: (\w+)\-(\w+)/\($1\-$2\)\: $3\-$4/g;
		$refcontent=~s/\,(\d+)\, (\d+)\-(\d+)\n/\, $1\, $2\-$3\n/gi;
		$refcontent=~s/(\,|\:)\n/\n/gi;
		$refcontent=~s/\[/\&lsqb\;/g;
		$refcontent=~s/\]/\&rsqb\;/g;
		$refcontent=~s/ Vol\. (\w+)\((\w+)\)\: (\w+)\-(\w+)\.?\n/ $1\($2\)\: $3\-$4\n/gi;
		$refcontent=~s/ Vol\. (\w+)\, No\. (\w+)\, pp\. ?(\w+)\-(\w+)\.?\n/ $1\($2\)\: $3\-$4\n/gi;
		$refcontent=~s/tplamplbracetplcolon(January|February|March|April|May|June|July|August|September|October|November|December) (\d+)tplamprbracetplcolon/\($1 $2\)/gi;
		$refcontent=~s/tplamplbracetplcolon((\d+)\,? (January|February|March|April|May|June|July|August|September|October|November|December))tplamprbracetplcolon/\($1\)/gi;
		$refcontent=~s/\, \. /\, /g; 
		$refcontent=~s/tplamplbracetplcolon(January|February|March|April|May|June|July|August|September|October|November|December)/\($1/gi;
		$refcontent=~s/\, \. /\, /g;
		$refcontent=~s/tplamplbracetplcolon((\d+)\,? (January|February|March|April|May|June|July|August|September|October|November|December)\,? (\d+))tplamprbracetplcolon/\($1\)/gi;
		$refcontent=~s/tplamplbracetplcolon((\d+[a-z])\,? (January|February|March|April|May|June|July|August|September|October|November|December)\,? (\d+))tplamprbracetplcolon/\($1\)/gi;
		$refcontent=~s/tplamplbracetplcolon((\d{4})\/(\d{4}))tplamprbracetplcolon/\($1\)/gi;
		$refcontent=~s/ \&lsqb\;CrossRef\&rsqb\;$//gi;
		$refcontent=~s/([a-z]) (\d+)\; (\d+)\: (\d+)\-(\d+)\.$/$1\, $2\, $3\: $4\-$5\./gi;
		$refcontent=~s/([a-z]) (\d+)\; (\d+)\: (\d+)\-(\d+)\./$1\, $2\, $3\: $4\-$5\./gi;
		$refcontent=~s/  / /g;		
		$refcontent=~s/tplampamptplcolon/\&/g;
		$refcontent=~s/ et al\.\,/ etal\,/gi;
		$refcontent=~s/ etal\.\,/ etal\,/gi;
		$refcontent=~s/ et al /\, etal\, /gi;
		$refcontent=~s/ et al\./\, etal\, /gi;
		$refcontent=~s/(\d+)\,(\d+)\-(\d+)\./$1\, $2\-$3\./g;
		$refcontent=~s/\,\,/\,/gi;
		$refcontent=~s/ et ?al / etal\, /gi;
		$refcontent=~s/ et ?al\. / etal\, /gi;
		$refcontent=~s/ (\w+)\, etal\,/\, $1\, etal\,/gi;
		$refcontent=~s/\,\,/\,/gi;
		$refcontent=~s/\, (\d{4}) to /\&comma\; $1 to /g;
		$refcontent=~s/(edited by)\:/$1/gi;
		$refcontent=~s/([a-z]+) (\d+)\: (\d+)\-(\d+)\./$1\, $2\: $3\-$4\./g;
		$refcontent=~s/McGraw\-Hill\, /McGraw\-Hill\: /g;
		$refcontent=~s/\, edition by (.*?)\.\,/\, edited by $1\./g;
		$refcontent=~s/\, edited by (.*?)\.\,/\, edited by $1\./g;
		$refcontent=~s/\, edited by (.*?)\.\,/\, edited by $1\./g;
		$refcontent=~s/([A-z]+)(\d+)\,New York\:/$1\, $2\, New York\:/gi; 
		$refcontent=~s/\,New York\:/\, New York\:/g; 
		$refcontent=~s/ New\: York\,/ New York\:/g;
		$refcontent=~s/\.University of /\. University of /g;
		$refcontent=~s/(\.|\,|\:|\;)DOI/$1 DOI/g;
		$refcontent=~s/([A-Z])\.([A-Z])([a-z]+)\, ([A-Z])\.([A-Z])\.([A-Z])([a-z]+)\, ([A-Z])\.([A-Z])([a-z]+)\,/$1\. $2$3\, $4\.$5\. $6$7\, $8\. $9$10\,/g; 
		$refcontent=~s/\n([A-Z])\.([A-Z])([a-z]+)/\n$1\. $2$3/gi;
		$refcontent=~s/\n(\w+)\, ([A-Z])\.([A-Z])/\n$1\, $2\. $3/g;
		$refcontent=~s/([A-z]+) (\d{4})([a-z])\, /$1\, $2$3\, /g;
		$refcontent=~s/([A-Za-z]+)\. (\d+)\,/$1IntegraDOT $2\,/gi;
		$refcontent=~s/volIntegraDOT/vol\./gi;
		$refcontent=~s/\&([A-Za-z]+)\, /\& $1\, /gi;
		$refcontent=~s/ ([A-Z])\. \-([A-Z])\.\, / $1\.\-$2\.\, /g;
		$refcontent=~s/\-(\d+)\.https/\-$1\. https/gi;
		$refcontent=~s/ (\d+)\,([A-Z])([a-z]+) / $1\, $2$3 /g; 
		$refcontent=~s/ volIntegraDOT / Vol /g;
		$refcontent=~s/ forthcoming\,/ \(forthcoming\)\,/gi;
		$refcontent=~s/university press/University Press/g;
		$refcontent=~s/tplamplbracetplcolon((\d+)\-(\d+)|Vol\. (\d+)|(\d+)|forthcoming)tplamprbracetplcolon/\($1\)/gi;
		$refcontent=~s/ (\d+)\;\:/$1\:/gi;
		$refcontent=~s/ pp\.\, (\d+)/ pp\. $1/gi;
		$refcontent=~s/\. \: /\, /gi;
		$refcontent=~s/\, \./\, /gi;
		$refcontent=~s/ \((January|February|March|April|May|June|July|August|September|October|November|December)\)/ tplamplbracetplcolon$1tplamprbracetplcolon/gi;
		
		my $inlinemath="";
		$Line=$refcontent;
		$Variable="";
		while($Line =~/<img id\=\"(inl(\d+))\" (.*?)>/gi)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $inlid="$1";
			my $intext="$3";
			
			$inlinemath .="<$inlid>$intext<\/$inlid>\n";
			$Curr=~s/<img id\=\"$inlid\" (.*?)>/<imgtag$inlid\/>/gi;
			
			
			#print ERR "$Curr";		
					
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$refcontent = $Variable;

		
		
		$Line=$refcontent;
		$Variable="";
		while($Line =~/( doi(\:| )(.*?))\n/gi)
		{
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			$Curr=~s/\. /\./g;
			$Curr=~s/\- /\-/g;
			$Curr=~s/\/ /\//g;
			
			
					
			$Variable .=$PreMatch .$Curr;
		}
		$Variable .=$Line;
		$refcontent = $Variable; 		

		my $months="(January|February|March|April|May|June|July|August|September|October|November|December)";
		$refcontent=~s/ noIntegraDOT / no\. /g;
		$refcontent=~s/ (num)IntegraDOT / $1\. /gi;
		$refcontent=~s/\. etal\b/\.\, etal/g;
		$refcontent=~s/ doi / doi\: /g;
		$refcontent=~s/ etal/\, etal/g;
		$refcontent=~s/\,\, etal/\, etal/g;
		$refcontent=~s/(?:\[|\&lsqb;)Online(?:\]|\&rsqb;)\.\s*Available\:\s*(https?:\/\/doi)/$1/gi;
		$refcontent=~s/\((\d{4})\)\: \, (\d+)/\($1\)\: $2/gi;
		$refcontent=~s/(\($months \d{4}\):) , (\d+)/$1 $3/gi;
		unlink("$dirs\\reftext.txt");

		open(REFCONTENT, ">:encoding(UTF-8)", "$dirs\\reftext\.txt")|| die print("Can't open input file $rubypath\\reftext\.txt!!!");
		print REFCONTENT "$refcontent";
		close(REFCONTENT);	
		chdir("$rubypath");
	}
}

sub CUT_N_JOIN
{
	my ($data, $element, $class, $rep_identy, $count, $switch, %join_hash) = (shift, shift, shift, shift, shift, shift, @_);
	my $cut_data;
	if ($switch eq 'CUT')
	{
		if($data=~/<\Q$element\E(\[\d+\])[^><]*class="\Q$class\E"[^><]*>.*?<\/\Q$element\E\1>/si)
		{
			$cut_data = $&;
			$data=~s/<\Q$element\E(\[\d+\])[^><]*class="\Q$class\E"[^><]*>.*?<\/\Q$element\E\1>/$rep_identy$count$rep_identy/si;
		}	
		return ($data, $cut_data);
	}
	elsif($switch eq 'JOIN')
	{
		while ($data=~/\Q$rep_identy\E(\d+)\Q$rep_identy\E/sgi)
		{
			my $co = $1;
			foreach my $key (keys %join_hash)
			{
				$data=~s/\Q$rep_identy$co$rep_identy\E/$join_hash{$key}/sgi if($key == $co);
			}
		}
		return ($data);
	}
	else
	{
		print "Invalid Switch $switch!!";
	}
}



sub REFFINALCLEANUP2
{
	#move back in inline to its position
	if($_=~/<div(\[\d+\]) class="references">(.*?)<\/div\1>/si)
	{
		my $ref = $2;
		$ref = &CUT_N_JOIN($ref, '0', '0', 'IntegraINL', '0', 'JOIN', %ref_inl_hash);
		$_=~s/<div(\[\d+\]) class="references">(.*?)<\/div\1>/<div$1 class="references">$ref<\/div$1>/si;
	}
	
	CHAR2ENTITY();
	
	MOVE_IN_QUERY(1, %ref_hash);


	$_=~s/(<\/p(?:\[\d+\])?>)((?:\s*<span(\[\d+\]) class="QUERY">.*?<\/span\3>\s*)+)/$2$1/sgi;	
	
	#Move querys listed after <h1> and figure
	$_=~s/(<\/h\d(?:\[\d+\])?>)((?:\s*<span(\[\d+\]) class="QUERY">.*?<\/span\3>\s*)+)/$2$1/sgi;	
	$_=~s/(<div(\[\d+\]) class="FIGBLOCK">.*?<span(\[\d+\]) class="FIG-CAPTION" data-element="caption">.*?)(<\/span\3>.*?<\/div\2>)((?:\s*<span(\[\d+\]) class="QUERY">.*?<\/span\6>\s*)+)/$1$5$4/sgi;		

}

sub ELEMENTNUMBERING
{
	
	
	open(ELIST, "<", "$serverpath/elements\.txt") or die print("$serverpath/elements\.txt NOT FOUND!!!");
	my $elements = <ELIST>;
	close (ELIST);

	$_=~s/\&\#x0?2103\;/\&\#x00B0\;C/g;
	$_=~s/<\/i>\.<i>/\./g;
	$_=~s/<(span|strong|sup|sub|sc|monospace)>/<$1 class\=\"dummy\">/g;
	

	$Line=$elements;	
	$Variable="";	
	while($Line =~/(\w+)/g)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		my $e2="$1";
		

		my $strongcount = 0;
		my $brk = 1;
		strongStart:
		if($brk >= 10)	{ print "\nUNexPectedBreak!!! for element - $e2"; print ERR $_; exit; goto BBREAK; }
		$_ =~ s{<$e2\s+([^<>]*>((?:(?!<$e2\s+\b).)*?))<\/$e2>}
				{
					my $strong = $&;
					#print "$strong\n\n";
					$strongcount++;
					$strong =~ s/<$e2\s+([^<>]*>((?:(?!<$e2\s+\b).)*?))<\/$e2>/<$e2\[$strongcount\] $1<\/$e2\[$strongcount\]>/msi;
					$strong;
				}emsgi;
		$brk++;
		goto strongStart if($_ =~ m/<$e2\s+/msi);		
		BBREAK:		
		
		
			
	#$Variable .=$PreMatch .$Curr;	
	}	
	#$Variable .=$Line;	
	#$_ = $Variable;

	
		while($_=~/<span\[(\d+)\] class\=\"dummy\">(.*?)<\/span\[\1\]>/sgi)
		{
			$_=~s/<span\[(\d+)\] class\=\"dummy\">(.*?)<\/span\[\1\]>/$2/sgi;	
		}
		

}

sub MOVE_OUT_QUERY
{
	my $temp = shift;
	my %ref_hash;
	if($temp == 1)
	{
		if($_=~/<div\[(\d+)\] class="references">(.*?)<\/div\[\1\]>/si)
		{
			my $ref_cnt = $2;
			if($ref_cnt=~/<span\[(\d+)\] class="QUERY">/si)
			{
				my $count = 1;
				
				$Line=$ref_cnt;	
				$Variable="";	
				#while($Line =~/<p\[(\d+)\] class=\"ref[^\"]+\">(.*?)<\/p\[\1\]>/sgi)	
				while($Line =~/<p\[(\d+)\] class=\"[^\"]+\">(.*?)<\/p\[\1\]>/sgi)	
				{	
					$PreMatch = $`;
					$Curr = $&;
					$Line = $';
				
					if($Line=~/^(\s*(?:<span\[(\d+)\] class="QUERY">.*?<\/span\[\2\]>\s*)+)/si)
					{
						$ref_hash{$count} = $1;
						$Line=~s/^(\s*(?:<span\[(\d+)\] class="QUERY">.*?<\/span\[\2\]>\s*)+)//si;
					}
					$count++;
				
				$Variable .=$PreMatch .$Curr;	
				}	
				$Variable .=$Line;	
				$ref_cnt = $Variable;	
				
				$ref_cnt=~s/(<\/p\[\d+\]>)\n\s*(<p\b)/$1\n$2/sgi;
				$ref_cnt=~s/(<\/p\[\d+\]>)\s*(<p\b)/$1\n$2/sgi;
				$ref_cnt=~s/><p/>\n<p/si;
		#print $ref_cnt;
				$_=~s/<div\[(\d+)\] class="references">(.*?)<\/div\[\1\]>/<div\[$1\] class="references">$ref_cnt<\/div\[$1\]>/si;
			}
		}

		return %ref_hash;
	}
	else
	{
		$_ =~s/((?:\s*<span\[(\d+)\] class\=\"QUERY\">.*?<\/span\[\2\]>\s*)+)(<\/p\[\d+\]>)/$3$1/sgi;
	}
}


sub MOVE_IN_QUERY
{
	my ($temp, %ref_hash) = (shift, @_);
	
	#print $_;
	
	if($temp == 1)
	{
		if($_=~/<div\[(\d+)\] class="references">(.*?)<\/div\[\1\]>/si)
		{
			my $ref_cnt = $2;
			my $count = 1;
			while($ref_cnt=~/<p class=\"[^\"]+\">((?:(?!<\/p>).)*?)<\/p>/sgi)
			{
				my $ref_while = $&;
				foreach my $key (%ref_hash)
				{
					if($key == $count)
					{
						$ref_while=~s/(<p class=\"[^\"]+\">((?:(?!<\/p>).)*?)<\/p>)/$1\n$ref_hash{$key}/si;
					}
				}
				$count++;
				$ref_while=~s/<(\/)?p\b/<$1Xp/sgi;
				$ref_cnt=~s/<p class=\"[^\"]+\">((?:(?!<\/p>).)*?)<\/p>/$ref_while/si;
			}
			$ref_cnt=~s/<(\/)?Xp\b/<$1p/sgi;
			$ref_cnt=~s/<\/p>\s*<span/<\/p>\n<span/sgi;
			$ref_cnt=~s/<\/(span\[\d+\])>\s*<p/<\/$1>\n<p/sgi;
			$_=~s/<div\[(\d+)\] class="references">(.*?)<\/div\[\1\]>/<div\[$1\] class="references">$ref_cnt<\/div\[$1\]>/si;
		}
	}
	else
	{
		$_ =~s/(<\/p\[\d+\]>)((?:\s*<span\[(\d+)\] class\=\"QUERY\">.*?<\/span\[\3\]>\s*)+)/$2$1/sgi;	
	}
}

sub CHAR2ENTITY
{
	while($_ =~ m/[\x{A0}-\x{FFDC}]/g)
	{
		my $findchar = $&;
		my $ent = uc(sprintf("%x", ord($findchar)));

		if(defined $ent)
		{
			if(length($ent) == 1)
			{
				$ent = "&#x0000$ent;";
			}
			elsif(length($ent) == 2)
			{
				$ent = "&#x000$ent;";
			}
			elsif(length($ent) == 3)
			{
				$ent = "&#x00$ent;";
			}
			elsif(length($ent) == 4)
			{
				$ent = "&#x0$ent;";
			}
			$_ =~ s/$findchar/$ent/g;
		}
		else
		{
			$_ =~ s/$findchar/<SRN\/>/;
		}
	}


	$_ =~ s/<NOTCONVERTED>([\&\#\w\;]+)<\/NOTCONVERTED>/$1/gi;
	$_ =~ s{<NOTCONVERTED>\\x(\w+)<\/NOTCONVERTED>}
	{
		my $NTent = "&#x0000" . $1;
		$NTent =~ s/^\&\#x0+([a-z0-9]{4})$/<NOTCONVERTED>\&\#x$1\;<\/NOTCONVERTED>/gi;
		$NTent;
	}iseg;

	$_ =~ s{<NOTCONVERTED>((\\x|\w)+)<\/NOTCONVERTED>}
	{
		my $test = $1;
		my @NTent = map {$_ =~ s/\\x(\w+)/\&\#x0000$1/i;$_ =~ s/^\&\#x0+([a-z0-9]{4})$/<NOTCONVERTED>\&\#x$1\;<\/NOTCONVERTED>/gi; $_} split(/(\\x\w+)/i, $test);
		my $finjoin = join "", @NTent;
		$finjoin;
	}iseg;

	$_ =~ s{<NOTCONVERTED>(&[\#\w]+;| )+<\/NOTCONVERTED>}
		{
			my $notconv = $&;
			$notconv =~ s/<\/?NOTCONVERTED>//gi;
			$notconv;
		}gie;

	$_ =~ s{<NOTCONVERTED>([^<>]+)<\/NOTCONVERTED>}
	{
		my $notc = $1;
		$notc =~ s{.}
			{
				my $findchar = $&;
				my $ent = uc(sprintf("%x", ord($findchar)));
				#print "$ent\n";
				if(defined $ent)
				{
					if(length($ent) == 1)
					{
						$ent = "&#x0000$ent;";
					}
					elsif(length($ent) == 2)
					{
						$ent = "&#x000$ent;";
					}
					elsif(length($ent) == 3)
					{
						$ent = "&#x00$ent;";
					}
					elsif(length($ent) == 4)
					{
						$ent = "&#x0$ent;";
					}
				}
				$ent;
			}eg;
		$notc;
	}iseg;
	
}


