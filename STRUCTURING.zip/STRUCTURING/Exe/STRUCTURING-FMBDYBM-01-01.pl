#######################################################################################
#                                                                                     
#               Tool Name  	:  STRUCTURING-FMBDYBM-01-01.pl                                   
#               Version       :  Version 1.0                                          
#               Purpose      :  
#                                
#               Copyrights    :  Integra
#               Developed By  :  (Sathish V.)                       
#               Started On    :  27 - 04 - 2023                                                  
#               Completed On  :                                                   
#               Last Modified :  
#                                                                                     
#######################################################################################

#use strict;
#use warnings;
use Win32;
use File::Copy;
use File::Path;
use File::Basename;
use DBI;
use DBD::mysql;
use LWP::Simple;
#use JSON::Any;
use XML::Simple;
use MongoDB;
use Data::Dumper qw(Dumper);
use HTML::Entities;
use Array::Utils qw(:all);
use List::MoreUtils qw(uniq);
use DateTime;
use Text::Hunspell;
use HTML::Strip;
use DateTime;
use Roman;

use Array::Split qw( split_into );
	
binmode STDOUT, ":utf8";		
			
use Encode qw(encode decode);


my ($filename, $path, $header, $matchtxt, $headinfo, $fpath1)=("","","","","","");
my ($curlcount, $tabcount, $eqcol, $inlinecount, $auxfind, $nonlatex)=(0, 0, 0, 1, 0, 0);
my ($Line, $Variable, $PreMatch, $Curr, $bbox, $fm, $filepath, $fpath, $bbox1, $journaltext, $journaltext1, $snocnt3, $hglt, $bibtext);
my ($Line1, $Variable1, $PreMatch1, $Curr1);
my $ijdata; 
my @jsautr;
my @psautr;
my (@equationcol, @defcollect, @inlinecol, @inlinecol2, @mathconten, @tempmt)=("", "", "", "", "", "");
my %math_remov_ins;
my %tex_link;
my $headcss="";

$fpath1 = $ARGV[0];

my $pubname = $ARGV[1];
my $jname = $ARGV[2];
my $functiontype = $ARGV[3];
my $functiontext = $ARGV[4];
my $functiontext2 = $ARGV[4];
my $pubtype = $ARGV[5];


my $outfpath1 = $fpath1;
my $outfpath2 = $fpath1;
my $querypath = $fpath1;

my $dirs = dirname($fpath1);

my $dirs1 = dirname($fpath1);

$dirs1=~s/^(.*?)\\Files\\(.*?)$/$2/sgi;
$dirs1=~s/^(.*?)\/Files\/(.*?)$/$2/sgi;

#print "$dirs1\n\n";
#exit;
my @fnarray="";

my @fildirna = (split/\\/, $dirs);
my $dirnamex = $fildirna[-1];

my $filenamex = basename($fpath1, ".html");

if (-e "$fpath1")
{
}
else
{
	print "File not found";
	exit;
}



$outfpath1=~s/\.html$//g;
$outfpath2=~s/\\document\.html$//g;

undef $/;


my $reftypeb="JRNL|BOOK|EDBK|PROC|OTHER|THESIS|WEB|BKSERIES|WKPAPER|SOFT|TECH";

my $serverpath="D\:/Integra/STRUCTURING/ini";
my $exepath="D\:/Integra/STRUCTURING/Exe";


my $rubypath="C\:\\Ruby26\-x64\\bin";


my $filetype="WORD";


my $frontmatter="";

open(ERR, ">:encoding(UTF-8)", "$outfpath1\_Error\.xml")|| die print("Can't open input file!!!");

#open(EX, ">:encoding(UTF-8)", "$outfpath1_GEN\.xml")|| die print("Can't open input file $fpath1.tex!!!");


open(QXX, "<$serverpath/journalinfo\.xml") or die print("$serverpath/journalinfo\.xml NOT FOUND, update the Journal Database!!!");
my $stdata = <QXX>;
close (QXX);	



open(QSS, "<$serverpath/AUTO-EDITING/UNITS\.html") or die print("AUTO-EDITING\/UNITS\.html NOT FOUND, update the Journal Database!!!");
my $units = <QSS>;
close (QSS);

open(CET, "<$serverpath/TEXTENTITIES\.xml") or die print("TEXTENTITIES\.xml NOT FOUND, update the Journal Database!!!");
my $Combine_Entity = <CET>;
close (CET);

open(WYY, "<$serverpath/AUTO-EDITING/$pubtype/$pubname/$jname\.xml");
my $jornalconfig = <WYY>;
close (WYY);

open(HEXA, "<:encoding(UTF-8)", "$serverpath/ENTITIES\-DATA\.xml") or die print("ENTITIES\-DATA\.xml NOT FOUND, update the Journal Database!!!");
my $entities = <HEXA>;
close (HEXA);




open(FIN, "<:encoding(UTF-8)", "$fpath1")|| die print("Can't open input file $fpath1!!!");
#open(OUT1, ">$fpath1\.xml")|| die print("$fpath1!!!");
$/="\0";

%Name_NUM=('A'=>1, 'B'=>2, 'C'=>3, 'D'=>4, 'E'=>5, 'F'=>6, 'G'=>7, 'H'=>8, 'I'=>9, 'J'=>10, 'K'=>11, 'L'=>12, 'M'=>13, 'N'=>14, 'O'=>15, 'P'=>16, 'Q'=>17, 'R'=>18, 'S'=>19, 'T'=>20, 'U'=>21, 'V'=>22, 'W'=>23, 'X'=>24, 'Y'=>25, 'Z'=>26);


while(<FIN>)
{
	if($_=~/[\x80-\xFE]/)
	{
		print "Junk Entity found in Word document, clear and rerun\n";
		exit;
	}
	
	GeneralCleanup();
	CHAR2ENTITY();
	NAMED2ENTITY();
	ELEMENTNUMBERING();
	MOVE_OUT_QUERY();
	MERGEDWORDS();
	DOUBLETAG();
	TBL2EQNS();
	Sections();
	BACK();
	FIGCITATION();
	TABLECITATION();
	EQNCITATION();
	SECCITATION();
	FIGURES();
	TABLES();
	FinalCleanup();
	ELEMENTNUMBERING();
	TABLES2();
	ABBRTBL2TEXT();
	
	FinalCleanup();
	
	open(XMLCONTENT, ">:encoding(UTF-8)", "$outfpath1-STEP1\.html")|| die print("Can't open input file !!!");
	print XMLCONTENT "$_";
	close(XMLCONTENT);
	exit;
}

sub ABBRTBL2TEXT
{
	$_=~s/(<h(\d+) class\=\"heading(\d+)\"><b\[\d+\] class\=\"dummy\">(Abbreviations)<\/b\[\d+\]><\/h\2>\s*)<table>/<table class\=\"ABBRTBL2TEXT\">\n<p\[000] class\=\"Glossarytitle\">$4<\/p\[000\]>/sgi;
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<table class\=\"ABBRTBL2TEXT\">(.*?)<\/table>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		if ($Curr=~/<colgroup>\s*<col width\=\"([^\"]+)\"\/>\s*<col width\=\"([^\"]+)\"\/>\s*<\/colgroup>/si)
		{
			
			$Curr=~s/<tr>\s*<td>(.*?)<\/td>\s*<td>(.*?)<\/td>\s*<\/tr>/<p\[000\] class\=\"Glossarypara\"><span\[000\] class\=\"Glossaryterm\">$1<\/span\[000\]><span\[000\] class\=\"Glossarytext\">$2<\/span\[000\]><\/p\[000\]>/sgi;
			$Curr=~s/<colgroup>(.*?)<\/colgroup>//sgi;
			$Curr=~s/<thead class\=\"TABLE\-HEAD\">//gi;
			$Curr=~s/<tbody class\=\"TABLE\-BODY\">//gi;
			$Curr=~s/<\/tbody>//gi;
			$Curr=~s/<\/thead>//gi;
			$Curr=~s/\n\s*/\n/gi;
			$Curr=~s/<table class\=\"ABBRTBL2TEXT\">/<div\[000\] class\=\"Glossary\">/gi;
			$Curr=~s/<\/table>/<\/div\[000\]>/gi;
			#print ERR "$Curr\n";
			
		}
		#$Curr=~s/<span class\=\"TABLE\-TITLE\" data\-element\=\"title\">\. ?/<span class\=\"TABLE\-TITLE\" data\-element\=\"title\">/gi;
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	
	
	$_=~s/<div\[000\] class\=\"Glossary\">(.*?)<\/div\[000\]>\s*<\/div\[(\d+)\]>\s*<div\[(\d+)\] class\=\"back\">/<\/div\[$2\]>\n<div\[$3\] class\=\"back\">\n<div\[000\] class\=\"Glossary\">$1<\/div\[000\]>/sgi;
	#print ERR "$_";
	

	
}

sub FinalCleanup
{
	
	if ($functiontype ne "14" && $functiontype ne "41")
	{
		if ($functiontype ne "44" && $functiontype ne "201")
		{
			INSERTMATHTAG();
		}	
	}


	#eq link id match for (1.1) format
	while ($_=~/<a class=\"EQUATIONLINK\" href=\"\#equ(\d+)\_(\d+)\">((?:(?!<\/a>).)*?)<\/a>/sgi)
	{
		my ($Curr, $id1, $id2) = ($&, $1, $2);
		$Curr=~s/<(\/)?a\b/<$1Xa/sgi;
		if($_=~/<span(\[\d+\]) id\=\"disp(\d+)\" class="disp"[^><]*>(.*?)<\/span\1>\s*<span(\[\d+\]) class\=\"EQLABEL\">\(?$id1\.$id2\)?<\/span\4>/si)
		{
			my $real_id = $2;
			$Curr=~s/href=\"\#equ(\d+)\_(\d+)\"/href=\"\#equ$real_id\"/si;
		}
		$_=~s/<a class=\"EQUATIONLINK\" href=\"\#equ(\d+)\_(\d+)\">((?:(?!<\/a>).)*?)<\/a>/$Curr/si;
	}
	$_=~s/<(\/)?Xa\b/<$1a/sgi;
	
	while($_ =~ m/<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>/sgi)
	{
		$_=~s/<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>/<$1>$3<\/$1>/sgi;
	}
	
	
	$_=~s/<(\w+)\[(\d+)\]/<$1/g;
	$_=~s/<\/(\w+)\[(\d+)\]>/<\/$1>/g;
	$_=~s/\s*<\/p>/<\/p>/g;
	$_=~s/  / /g;
	$_=~s/<divx /<div /g;
	$_=~s/<\/divx>/<\/div>/g;
	$_=~s/<supr>/<sup>/g;
	$_=~s/<\/supr>/<\/sup>/g;
	#$_=~s/<(\w+)><\/\1>//g;
	
	$Line=$_;
	$Variable="";
	while($Line =~/<head>(.*?)<\/head>/sgi)
	{
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/\&\#x0027\;/\'/gi;
		#print ERR "$Curr\n";
		
				
	$Variable .=$PreMatch .$Curr;
	}
	$Variable .=$Line;
	$_ = $Variable;	
	
	#print ERR $_;
	
	if($jname=~/^(MDY)$/ && $functiontype eq "14")
	{
		while($_=~/<span class=\"(ATITLE|CHAPTER)\">((?:(?!<\/span>).)*?)<\/span>/sgi)
		{
			my $jtl = $2;
			$jtl=~s/\s*\&\#x0?2019;\s*$//si;
			$jtl=~s/((?:\:|\&\#x0?2013;|\-|\?)\s+)([a-z])/$1\U$2\E/sg;
			$_=~s/<span class="(ATITLE|CHAPTER)">((?:(?!<\/span>).)*?)<\/span>/<xspan class="$1">$jtl<\/xspan>/si;
		}
		$_=~s/<(\/)?xspan/<$1span/sgi;
	}

	$_=~s/<span class\=\"QUERY\"><\/span>//gi;


	#exit;	
	
}


sub CITATIONSTYLE()
{
	if($jornalconfig =~m/<citationstyle>(.*?)<\/citationstyle>/i)
	{
		my $citetemp=$1;
		if($citetemp=~/<figure label=\"I\"\/>/i)
		{
			while($_=~/<a class=\"(FIGLINK)\" href=\"\#([^><]+)\">([^><]+) (\d)<\/a>/si)
			{
				my $roman = roman($4);
				$_=~s/<a class=\"(FIGLINK)\" href=\"\#([^><]+)\">([^><]+) (\d)<\/a>/<a class=\"$1\" href=\"\#$2\">$3 \U$roman\E<\/a>/si;
			}
			while($_=~/<a class=\"(FIGLINK)\" href=\"\#([^><]+)\">(\d)<\/a>/si)
			{
				my $roman = roman($3);
				$_=~s/<a class=\"(FIGLINK)\" href=\"\#([^><]+)\">(\d)<\/a>/<a class=\"$1\" href=\"\#$2\">\U$roman\E<\/a>/si;
			}
			while($_=~/<span class=\"FIG\-LABEL\" data\-element=\"label\">([^><]+) (\d+)<\/span>/si)
			{
			my $roman = roman($2);
			$_=~s/<span class=\"FIG\-LABEL\" data\-element=\"label\">([^><]+) (\d+)<\/span>/<span class=\"FIG\-LABEL\" data\-element=\"label\">$1 \U$roman\E<\/span>/si;
			}
		}
		if($citetemp=~/<table label=\"I\"\/>/i)
		{
			while($_=~/<a class=\"(TABLINK)\" href=\"\#([^><]+)\">([^><]+) (\d)<\/a>/si)
			{
				my $roman = roman($4);
				$_=~s/<a class=\"(TABLINK)\" href=\"\#([^><]+)\">([^><]+) (\d)<\/a>/<a class=\"$1\" href=\"\#$2\">$3 \U$roman\E<\/a>/si;
			}
			while($_=~/<a class=\"(TABLINK)\" href=\"\#([^><]+)\">(\d)<\/a>/si)
			{
				my $roman = roman($3);
				$_=~s/<a class=\"(TABLINK)\" href=\"\#([^><]+)\">(\d)<\/a>/<a class=\"$1\" href=\"\#$2\">\U$roman\E<\/a>/si;
			}
		}
	}	
}

sub TABLES2
{
	
	$_=~s/<b>/<b\[0000\] class\=\"dummy\">/gi;
	$_=~s/<i>/<i\[0000\] class\=\"dummy\">/gi;
	$_=~s/<sup>/<sup\[0000\] class\=\"dummy\">/gi;
	$_=~s/<sub>/<sub\[0000\] class\=\"dummy\">/gi;
	$_=~s/<\/b>/<\/b\[0000\]>/gi;
	$_=~s/<\/i>/<\/i\[0000\]>/gi;
	$_=~s/<\/sup>/<\/sup\[0000\]>/gi;
	$_=~s/<\/sub>/<\/sup\[0000\]>/gi;
	
	#move notes in table
	$_=~s/<\/table>\s*((<p\[(\d+)\] class\=\"normal\">\s*(<(b|i|sup)\[(\d+)\] class\=\"dummy\">\s*)?(notes?|\w<\/sup\[\6\]>|\W<\/sup\[\6\]>|<(b|i)\[(\d+)\] class\=\"dummy\">\s*(\w|\W)<\/\8\[\9\]><\/sup\[\6\]>)(.*?)<\/p\[\3\]>\s*)+)/\n<tfoot>\n$1<\/tfoot>\n<\/table>\n/sgi;
	
	
	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)\] class\=\"dummy\">Table(\d+)\. /<p\[$1\] class\=\"$2\"><b\[$3\] class\=\"dummy\">Table $4\: /gi;
	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b\[(\d+)\] class\=\"dummy\">Table\.(\d+)\. /<p\[$1\] class\=\"$2\"><b\[$3\] class\=\"dummy\">Table $4\: /gi;
	

	
	$_=~s/<span class\="Institution\" data\-element\=\"institution\">Corresponding Author\: /Corresponding Author\: <span class\="Institution\" data\-element\=\"institution\">/gi;
	
	
	
	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><a\[(\d+)\] class\=\"TABLINK\" href\=\"\#table(\-?\d+)">(.*?)<\/a\[\3\]>(\s*\:)/<p\[$1\] class\=\"$2\"><a\[$3\] class\=\"TABLINK\" href\=\"\#table$4">$5$6<\/a\[$3\]>/sgi;

	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><a\[(\d+)\] class\=\"TABLINK\" href\=\"\#table\-?(\w+)">(.*?)<\/a\[\3\]>(.*?)<\/p\[\1\]>\s*<table>(.*?)<\/table>/<div\[1000\] class\=\"TABLE\" data\-element\=\"table\-wrap\" data\-attribs\-id\=\"table\-$4\"><span class\=\"TABLE\-LABEL\" data\-element\=\"label\">Table $4<\/span><span class\=\"TABLE\-CAPTION\" data\-element\=\"caption\"><span class\=\"TABLE\-TITLE\" data\-element\=\"title\">$6<\/span><\/span>\n<table>$7<\/table>\n<\/div\[1000\]>/sgi;
	
	#new
	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<a\[(\d+)\] class\=\"TABLINK\" href\=\"([^\"]+)">(.*?)<\/a\[\3\]>(.*?)<\/p\[\1\]>\s*<table>(.*?)<\/table>/<div\[1000\] class\=\"TABLE\" data\-element\=\"table\-wrap\" data\-attribs\-id\=\"$4\"><span class\=\"TABLE\-LABEL\" data\-element\=\"label\">$5<\/span><span class\=\"TABLE\-CAPTION\" data\-element\=\"caption\"><span class\=\"TABLE\-TITLE\" data\-element\=\"title\">$6<\/span><\/span>\n<table>$7<\/table>\n<\/div\[1000\]>/sgi;
	
	
	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><[b|i]\[(\d+)\] class\=\"dummy\">Table\-? ?(\d+)\:?\.?<\/[b|i]\[\3\]>\:? ?(.*?)<\/p\[\1\]>\s*<table>(.*?)<\/table>/<div\[1000\] class\=\"TABLE\" data\-element\=\"table\-wrap\" data\-attribs\-id\=\"table\-$4\"><span class\=\"TABLE\-LABEL\" data\-element\=\"label\">Table $4<\/span><span class\=\"TABLE\-CAPTION\" data\-element\=\"caption\"><span class\=\"TABLE\-TITLE\" data\-element\=\"title\">$5<\/span><\/span>\n<table>$6<\/table>\n<\/div\[1000\]>/sgi;

	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><[b|i]\[(\d+)\] class\=\"dummy\">Tableau\-? ?(\d+)\:?\.?<\/[b|i]\[\3\]>\:? ?(.*?)<\/p\[\1\]>\s*<table>(.*?)<\/table>/<div\[1000\] class\=\"TABLE\" data\-element\=\"table\-wrap\" data\-attribs\-id\=\"table\-$4\"><span class\=\"TABLE\-LABEL\" data\-element\=\"label\">Tableau $4<\/span><span class\=\"TABLE\-CAPTION\" data\-element\=\"caption\"><span class\=\"TABLE\-TITLE\" data\-element\=\"title\">$5<\/span><\/span>\n<table>$6<\/table>\n<\/div\[1000\]>/sgi;
	
	#print ERR "$_";
	
	
	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><[b|i]\[(\d+)\] class\=\"dummy\">Table\-? ?(\d+)\:?\:?\.? ?(.*?)<\/[b|i]\[\3\]>\s*<\/p\[\1\]>\s*<table>(.*?)<\/table>/<div\[1000\] class\=\"TABLE\" data\-element\=\"table\-wrap\" data\-attribs\-id\=\"table\-$4\"><span class\=\"TABLE\-LABEL\" data\-element\=\"label\">Table $4<\/span><span class\=\"TABLE\-CAPTION\" data\-element\=\"caption\"><span class\=\"TABLE\-TITLE\" data\-element\=\"title\">$5<\/span><\/span>\n<table>$6<\/table>\n<\/div\[1000\]>/sgi;
	
	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><[b|i]\[(\d+)\] class\=\"dummy\">Table\-? ?(\d+)\:?\:?\.? ?(.*?)<\/[b|i]\[\3\]>(.*?)<\/p\[\1\]>\s*<table>(.*?)<\/table>/<div\[1000\] class\=\"TABLE\" data\-element\=\"table\-wrap\" data\-attribs\-id\=\"table\-$4\"><span class\=\"TABLE\-LABEL\" data\-element\=\"label\">Table $4<\/span><span class\=\"TABLE\-CAPTION\" data\-element\=\"caption\"><span class\=\"TABLE\-TITLE\" data\-element\=\"title\">$5$6<\/span><\/span>\n<table>$7<\/table>\n<\/div\[1000\]>/sgi;
	

	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">Table\-?\:?\.? ?(\d+)\:? ?(.*?)<\/p\[\1\]>\s*<table>(.*?)<\/table>/<div\[1000\] class\=\"TABLE\" data\-element\=\"table\-wrap\" data\-attribs\-id\=\"table\-$3\"><span class\=\"TABLE\-LABEL\" data\-element\=\"label\">Table $3<\/span><span class\=\"TABLE\-CAPTION\" data\-element\=\"caption\"><span class\=\"TABLE\-TITLE\" data\-element\=\"title\">$4<\/span><\/span>\n<table>$5<\/table>\n<\/div\[1000\]>/sgi;
	
	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">Table\-?\:?\.? ?(\d+)\:?\:? ?(.*?)\s*<\/p\[\1\]>\s*<table>(.*?)<\/table>/<div\[1000\] class\=\"TABLE\" data\-element\=\"table\-wrap\" data\-attribs\-id\=\"table\-$3\"><span class\=\"TABLE\-LABEL\" data\-element\=\"label\">Table $3<\/span><span class\=\"TABLE\-CAPTION\" data\-element\=\"caption\"><span class\=\"TABLE\-TITLE\" data\-element\=\"title\">$4<\/span><\/span>\n<table>$5<\/table>\n<\/div\[1000\]>/sgi;

	#print ERR "$_\n\n\n";


	$Line=$_;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"([^\"]+)\">\[\[table\-(\d+)\]\]<\/p\[\1\]>(.*?)<p\[(\d+)\] class\=\"([^\"]+)\">\[\[\/table\-\3\]\]<\/p\[\5\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		my $tbid="$3";
		
		
		if($Curr =~ m/<thead class\=\"TABLE\-HEAD\">\s*<tr>\s*<td colspan\=\"\d+\"><a\[\d+\] class\=\"TABLINK\" href\=\"\#table\-(\d+)\">Table (\d+)<\/a\[\d+\]>\.?\:? (.*?)<\/td><\/tr><\/thead>/i)
		{
			my $tbcaption="$3";
			$Curr=~s/<table>/<span\[00\] class\=\"TABLE\-LABEL\" data\-element\=\"label\">Table $tbid<\/span\[00\]><span\[00\] class\=\"TABLE\-CAPTION\" data\-element\=\"caption\"><span\[00\] class\=\"TABLE\-TITLE\" data\-element\=\"title\">$tbcaption<\/span\[00\]><\/span\[00\]>\n<table>/si;
			
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\[\[table\-$tbid\]\]<\/p\[\1\]>/<div\[00\] class\=\"TABLE\" data\-element\=\"table\-wrap\" data\-attribs\-id\=\"table\-$tbid\">/si;
			
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\[\[\/table\-$tbid\]\]<\/p\[\1\]>/<\/div\[00\]>/si;
			
			$Curr=~s/<thead class\=\"TABLE\-HEAD\">(.*?)<\/thead>\s*<tbody class\=\"TABLE\-BODY\">\s*(<tr(>| )(.*?)<\/tr>)/<thead class\=\"TABLE\-HEAD\">\n$2<\/thead>\n<tbody class\=\"TABLE\-BODY\">/si;

			#print ERR "$Curr\n\n\n";
		}
		else
		{
			#print ERR "$Curr\n";
			if($Curr !~ m/<span class\=\"TABLE\-LABEL\"/i)
			{
				$Curr=~s/<table>/<span\[00\] class\=\"TABLE\-LABEL\" data\-element\=\"label\">Table $tbid<\/span\[00\]><span\[00\] class\=\"TABLE\-CAPTION\" data\-element\=\"caption\"><span\[00\] class\=\"TABLE\-TITLE\" data\-element\=\"title\">Insert Table Caption Here<\/span\[00\]><\/span\[00\]>\n<table>/si;
			}
			if($Curr !~ m/<div\[(\d+)\] class\=\"TABLE\"/i)
			{
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\[\[table\-$tbid\]\]<\/p\[\1\]>/<div\[00\] class\=\"TABLE\" data\-element\=\"table\-wrap\" data\-attribs\-id\=\"table\-$tbid\">/si;
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\[\[\/table\-$tbid\]\]<\/p\[\1\]>/<\/div\[00\]>/si;
			}
			
			
		}

		
		
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	
	#print ERR "sss$_\n";
	#exit;

	$Line=$_;	
	$Variable="";	
	while($Line =~/<div\[(\d+)\] class\=\"(floats)\"(.*?)<\/div\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/<p\[(\d+)\] class\=\"normal\">\[\[table\-\d+\]\]<\/p\[\1\]>\s*//sgi;
		$Curr=~s/<p\[(\d+)\] class\=\"normal\">\[\[\/table\-\d+\]\]<\/p\[\1\]>\s*//sgi;
		
		while($Curr =~/<div\[(\d+)\] class\=\"TABLE\" (.*?)<\/div\[\1\]>\s*<p\[(\d+)\] class\=\"normal\">(.*?)<\/p\[\3\]>/sgi)
		{
		
			$Curr=~s/<div\[(\d+)\] class\=\"TABLE\" (.*?)<\/div\[\1\]>\s*<p\[(\d+)\] class\=\"normal\">(.*?)<\/p\[\3\]>/<div\[$1\] class\=\"TABLE\" $2<p\[$3\] class\=\"normal\">$4<\/p\[$3\]>\n<\/div\[$1\]>/sgi;
		} 
		#$Curr=~s/( |^|\-|\&lt\;|\&gt\;)(\d+\.?\d+) ?((m|kg\/m|rad\/s|W\/m|J\/m|m\/s|mol\/m|Kat\/m|A\/m|cd\/m|C\/m|F\/m|[A-Za-z]\/m)<sup\[(\d+)\] class\=\"dummy\">(\-?\d+)<\/sup\[\5\]>)/$1$2<ins class\=\"OPSPACE\"> <\/ins>$3/gi;
		
		#$Curr=~s/<span class\=\"TABLE\-TITLE\" data\-element\=\"title\">\. ?/<span class\=\"TABLE\-TITLE\" data\-element\=\"title\">/gi;
		#print ERR "$Curr\n";	
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	
	#exit;

	$Line=$_;	
	$Variable="";	
	while($Line =~/<div\[(\d+)\] class\=\"TABLE\" (.*?)<\/div\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		if($Curr =~/<\/table>\s*<\/div\[(\d+)\]>$/si)
		{
		}
		else
		{
			$Curr=~s/<\/table>(.+?)<\/div\[(\d+)\]>$/\n<tfoot>$1\n<\/tfoot>\n<\/table>\n<\/div\[$2\]>/sgi;
		}
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;

	#exit;


	
	$_=~s/<span class\=\"TABLE\-TITLE\" data\-element\=\"title\">\. /<span class\=\"TABLE\-TITLE\" data\-element\=\"title\">/gi;
	
	#####TABLE FOOTNOTE
	
	$_=~s/<p\[(\d+)\] class\=\"normal\">\[\[table\-\d+\]\]<\/p\[\1\]>\s*//sgi;
	$_=~s/<p\[(\d+)\] class\=\"normal\">\[\[\/table\-\d+\]\]<\/p\[\1\]>\s*//sgi;
	$_=~s/<\/tfoot>\s*<tfoot>/\n/sgi;
	#print ERR "$_";
	#exit;

	
}


sub TABLES
{
	$_=~s/<p\[(\d+)\] class\=\"[^\"]+\"><a class\=\"TABLINK\" href\=\"#table\-(\d+)\">Table\-(\d+)<\/a><\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\">/\n<p\[$1\] class\=\"$5\">Table $3\. /sgi;
	#print ERR "sss$_";
	#exit;
		
		#print ERR "$Curr\n\n";
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"[^\"]+\">\[\[table\-(\d+)\]\]<\/p\[\1\]>(.*?)<p\[(\d+)\] class\=\"[^\"]+\">\[\[\/table\-\2\]\]<\/p\[\4\]>/sg)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		my $tablecontent="$3";
		my $tableid="$2";
		
		
		#$Curr=~s/<p\[(\d+)\] class\=\"normal\"><a class\="TABLINK\" href\=\"\#table\-(\d+)\">(.*?)<\/a>\. Citation number corresponding with various percentiles</p[96]>
		#$_=~s/<\/h1>\s*<h1 class\=\"heading1\" data\-type\=\"([^\"]+)\">(.*?)<\/h1>/<\/h1>\n<h2 class\=\"heading2\">$2<\/h2>/sg;
		
		#print ERR "$tablecontent\n";
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;


	$Line=$_;	
	$Variable="";	
	while($Line =~/<table>(.*?)<\/table>/sg)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		#print ERR "$Curr\n";
		
		if($Curr=~/<\/colgroup>\s*<tr>\s*<td colspan\=\"\d+\">(<a class\=\"TABLINK\" href\=\"\#table\-\d+\">Table .*?)<\/td>(\s*<td><\/td>)?<\/tr>/sgi)
		{
			my $tcaption="$1";
			$Curr=~s/<\/colgroup>\s*<tr>\s*<td colspan\=\"\d+\">(<a class\=\"TABLINK\" href\=\"\#table\-\d+\">Table .*?)<\/td>(\s*<td><\/td>)?<\/tr>/<\/colgroup>\n/si;
			$Curr=~s/<table>/<p\[0000\] class\=\"TABLE-CAPTION\">$tcaption<\/p\[0000\]>\n<table>/i;
			#print ERR "$Curr\n";
		}
		
		
		
		$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	
	#$_=~s/<a class\=\"TABLINK\" href\=\"\#table\-(\d+)\">Table (\d+)<\/a>\.([A-z]+)/<a class\=\"TABLINK\" href\=\"\#table\-$1\">Table $2<\/a>\. $3/gi;

	#print ERR "$_";
	#exit;

	
	$_=~s/<p\[(\d+)\] class\=\"[^\"]+\">(.*?)<\/p\[\1\]>\s*<table>/<p\[$1\] class\=\"TABLE-CAPTION\">$2<\/p\[$1\]>\n<table>/sg;
	#$_=~s/<\/table>\s*<p\[(\d+)\] class\=\"normal\">(<b>|Note|\*)/<\/table>\n<p\[$1\] class\=\"TABLE-FOOT\">$2/gi;


	#print ERR "$_";
	#exit;

	$Line=$_;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"TABLE\-CAPTION\">(.*?)<\/p\[\1\]>/gi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/<a class\=\"TABLINK\" href\=\"\#table\-(\d+)\">Table (\d+)<\/a>\.([A-z]+)/<a class\=\"TABLINK\" href\=\"\#table\-$1\">Table $2<\/a>\. $3/sgi;
		#print ERR "$Curr\n";
		
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	
	#exit;
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<xdiv class="Algorithm">(.*?)<\/xdiv>/sg)	
	{
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		$Curr =~s/<(\/)?table/<$1xtable/sgi;
		
		$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	



	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<table>(.*?)<\/table>/sg)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		if($Curr=~/<thead class\=\"TABLE\-HEAD\">(.*?)<\/thead>/sg || $Curr=~/<tbody class\=\"TABLE\-BODY\">/sg)
		{
		}
		else
		{
			$Curr=~s/<\/tr>\s*<\/table>/<\/tr>\n<\/tbody><\/table>/i;
			$Curr=~s/<tbody>//i;
			$Curr=~s/<tr>(.*?)<\/tr>/<thead class\=\"TABLE\-HEAD\">\n<tr>$1<\/tr><\/thead>\n<tbody class\=\"TABLE-BODY\">/si;
	
		}
		
		$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	
	
	$_ =~s/<(\/)?xtable/<$1table/sgi;
	
	
	
	$_ =~s/(<td\b[^><]*>)\s*/$1/sgi;
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<table>(.*?)<\/table>/sg)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		if($Curr=~/ bgcolor\=\"\#auto\"/sg)
		{
			$Curr=~s/ bgcolor\=\"\#auto\"/ bgcolor\=\"auto\"/g;
			if($Curr!~/ bgcolor\=\"\#/sg)
			{
				$Curr=~s/ bgcolor\=\"auto\"//g;
			}

		}	

		if($Curr=~/<thead class\=\"TABLE\-HEAD\">(.*?)<\/thead>/sg)
		{
			my $theadcontent="$1";
			if($theadcontent=~/ rowspan\=\"5\"/)
			{
				$Curr=~s/<thead class\=\"TABLE\-HEAD\">(.*?)<\/tr>\s*<\/thead>\s*<tbody class\=\"TABLE-BODY\">(\s*<tr>(.*?)<\/tr>\s*<tr>(.*?)<\/tr>\s*<tr>(.*?)<\/tr>\s*<tr>(.*?)<\/tr>)/<thead class\=\"TABLE\-HEAD\">$1<\/tr>$2<\/thead>\n<tbody class\=\"TABLE-BODY\">/sg;
			}
			elsif($theadcontent=~/ rowspan\=\"4\"/)
			{
				$Curr=~s/<thead class\=\"TABLE\-HEAD\">(.*?)<\/tr>\s*<\/thead>\s*<tbody class\=\"TABLE-BODY\">(\s*<tr>(.*?)<\/tr>\s*<tr>(.*?)<\/tr>\s*<tr>(.*?)<\/tr>)/<thead class\=\"TABLE\-HEAD\">$1<\/tr>$2<\/thead>\n<tbody class\=\"TABLE-BODY\">/sg;
			}
			elsif($theadcontent=~/ rowspan\=\"3\"/)
			{
				$Curr=~s/<thead class\=\"TABLE\-HEAD\">(.*?)<\/tr>\s*<\/thead>\s*<tbody class\=\"TABLE-BODY\">(\s*<tr>(.*?)<\/tr>\s*<tr>(.*?)<\/tr>)/<thead class\=\"TABLE\-HEAD\">$1<\/tr>$2<\/thead>\n<tbody class\=\"TABLE-BODY\">/sg;
			}
			elsif($theadcontent=~/ rowspan\=\"2\"/)
			{
				$Curr=~s/<thead class\=\"TABLE\-HEAD\">(.*?)<\/tr>\s*<\/thead>\s*<tbody class\=\"TABLE-BODY\">(\s*<tr>(.*?)<\/tr>)/<thead class\=\"TABLE\-HEAD\">$1<\/tr>$2<\/thead>\n<tbody class\=\"TABLE-BODY\">/sg;
				#print ERR "$Curr\n";
				
			}
		}		
		

		$Curr=~s/<td>\-<\/td>/<td><del class\=\"crins\">\-<\/del><ins class\=\"crins\">\&ndash\;<\/ins><\/td>/g;
		$Curr=~s/<td (\w+)\=\"([^\"]+)\">\-<\/td>/<td $1\=\"$2\"><del class\=\"crins\">\-<\/del><ins class\=\"crins\">\&ndash\;<\/ins><\/td>/g;


		$Curr=~s/<td>(\d) (\d{3})<\/td>/<td>$1<del class\=\"crins\"> <\/del><ins class\=\"crins\">\,<\/ins>$2<\/td>/g;
		$Curr=~s/<td (\w+)\=\"([^\"]+)\">(\d) (\d{3})<\/td>/<td $1\=\"$2\">$3<del class\=\"crins\"> <\/del><ins class\=\"crins\">\,<\/ins>$4<\/td>/g;
		
		$Curr=~s/<td>(\d{2}) (\d{3})<\/td>/<td>$1<del class\=\"crins\"> <\/del><ins class\=\"crins\">\,<\/ins>$2<\/td>/g;
		$Curr=~s/<td bgcolor\=\"([^\"]+)\">(\d{2}) (\d{3})<\/td>/<td bgcolor\=\"$1\">$2<del class\=\"crins\"> <\/del><ins class\=\"crins\">\,<\/ins>$3<\/td>/g;
		

		$Curr=~s/<td>(\d{3}) (\d{3})<\/td>/<td>$1<del class\=\"crins\"> <\/del><ins class\=\"crins\">\,<\/ins>$2<\/td>/g;
		$Curr=~s/<td bgcolor\=\"([^\"]+)\">(\d{3}) (\d{3})<\/td>/<td bgcolor\=\"$1\">$2<del class\=\"crins\"> <\/del><ins class\=\"crins\">\,<\/ins>$3<\/td>/g;
		
		if($jornalconfig !~ m/<FILE type\=\"copyedited\"\/>/i)
		{
			$Curr=~s/<td><b>\-(\d+)\.(\d+)<\/b><\/td>/<td><b><del class\=\"crins\">\-<\/del><ins class\=\"crins\">\&\#x2212\;<\/ins>$1\.$2<\/b><\/td>/g;
			
			$Curr=~s/(<td[^><]*>)(\-)(\d+)/$1<del class\=\"crins\">$2<\/del><ins class\=\"crins\">\&\#x2212\;<\/ins>$3/g;
			
			$Curr=~s/<td (\w+)\=\"([^\"]+)\"><b>\-(\d+)\.(\d+)<\/b><\/td>/<td $1\=\"$2\"><b><del class\=\"crins\">\-<\/del><ins class\=\"crins\">\&\#x2212\;<\/ins>$3\.$4<\/b><\/td>/g;
			
			$Curr=~s/<td>\-(\d+)\.(\d+)<\/td>/<td><del class\=\"crins\">\-<\/del><ins class\=\"crins\">\&\#x2212\;<\/ins>$1\.$2<\/td>/g;
			
			$Curr=~s/<td (\w+)\=\"([^\"]+)\">\-(\d+)\.(\d+)<\/td>/<td $1\=\"$2\"><del class\=\"crins\">\-<\/del><ins class\=\"crins\">\&\#x2212\;<\/ins>$3\.$4<\/td>/g;
			
			
			$Curr=~s/<td>\-(\d+)<\/td>/<td><del class\=\"crins\">\-<\/del><ins class\=\"crins\">\&\#x2212\;<\/ins>$1<\/td>/g;
			
			$Curr=~s/<td (\w+)\=\"([^\"]+)\">\-(\d+)<\/td>/<td $1\=\"$2\"><del class\=\"crins\">\-<\/del><ins class\=\"crins\">\&\#x2212\;<\/ins>$3<\/td>/g;		
		}
		
		$Curr=~s/(<td rowspan\=\"(\d+)\">)\s*/$1/gi;
		
		
		#print ERR "aaaaaa$Curr\n\n";
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	

	$_=~s/<\/table>\s*/<\/table>\n/gi;	
	$_=~s/<floats>/<div class\=\"floats\">/gi;
	$_=~s/<\/floats>/<\/div>/gi;

	
	

}




sub FIGURES
{
		$dirs1=~s/\\/\//gi;
		$_=~s/ <span\[(\d+)\] class\=\"INLINEFIG\" id\=\"([^\"]+)\"><\/span\[\1\]><\/p\[(\d+)\]>/<\/p\[$3\]>\n<p\[10000\] class\=\"normal\"><span\[$1\] class\=\"INLINEFIG\" id\=\"$2\"><\/span\[$1\]><\/p\[10000\]>/sgi;
		
				
		if($pubname=~/^(SIAM)$/ || $jornalconfig=~/<FILE type="Tex"\/>/si)
		{
			$_=~s#<p\[(\d+)\] class\=\"([^\"]+)\">\s*<span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\3\]>\s*<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\">\s*(?:<[^<]+>)?(Figure|Fig)\.? ([A-Z][\.\-]?\d+|\d+\.\d+|(?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3})|\d+)\.?\:?\.?(?:<\/[^<]+>)?\.?\:? ?(.*?)<\/p\[\5\]>#
			my ($full, $fid) = ($&, $8);
			$fid=~s/(\d+)\.(\d+)/$1\_$2/si;
			$full=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\3\]>\s*<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\">\s*(?:<[^<]+>)?(Figure|Fig)\.? ([A-Z][\.\-]?\d+|\d+\.\d+|(?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3})|\d+)\.?\:?\.?(?:<\/[^<]+>)?\.?\:? ?(.*?)<\/p\[\5\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$fid\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$4\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">$7 $8<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$9<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$fid\"\/\]\]<\/button><\/p\[$1\]><\/div>/si;
			($full);#sgie;
		}
		
		if($pubname=~/^(SIAM)$/)
		{
			$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"[^\"]+\"><\/span\[\3\]> ?(Fig\. ?(\d+))\. (.*?)<\/p\[\1\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$5\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$5\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">$4<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$6<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$5\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
			
			$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"[^\"]+\"><\/span\[\3\]> ?(?:<[^<]+>)?(Fig\.? ?(\d+))\:?(?:<\/[^<]+>)?\.?(.*?)<\/p\[\1\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$5\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$5\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">$4<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$6<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$5\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
	
	
			
			$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\3\]>\s*<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"[^\"]+\">\s*(?:<[^<]+>)?(Fig\.? ?(\d+))\:?(?:<\/[^<]+>)?\.?\:? ?(.*?)<\/p\[\5\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$7\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$4\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">$6<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$8<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$7\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
			
			$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\3\]><\/p\[\1\]>\s*<p\[(\d+)\] class\=\"[^\"]+\"><b>(Fig\.? ?(\d+))\:<\/b>\.? ?(.*?)<\/p\[\5\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$7\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$4\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">$6<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$8<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$7\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
		}
		else
		{
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"([^\"]+)\"><\/span\[\3\]> ?Fig\. ?(\d+)\. (.*?)<\/p\[\1\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$5\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$5\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">Figure $5<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$6<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$5\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
        
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"([^\"]+)\"><\/span\[\3\]> ?(?:<[^<]+>)?Fig\.? ?(\d+)\:?(?:<\/[^<]+>)?\.?(.*?)<\/p\[\1\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$5\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$5\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">Figure $5<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$6<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$5\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;


		
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\3\]>\s*<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\">\s*(?:<[^<]+>)?Fig\.? ?(\d+)\:?(?:<\/[^<]+>)?\.?\:? ?(.*?)<\/p\[\5\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$7\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$4\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">Figure $7<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$8<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$7\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
        
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\3\]><\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\"><b>Fig\.? ?(\d+)\:<\/b>\.? ?(.*?)<\/p\[\5\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$7\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$4\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">Figure $7<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$8<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$7\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
		
		}
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b>Figure (\d+)\. /<p\[$1\] class\=\"$2\">Figure $3\. <b>/sgi;
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><i>Figure (\d+)\. /<p\[$1\] class\=\"$2\">Figure $3\. <i>/sgi;

		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b>Fig (\d+)\. /<p\[$1\] class\=\"$2\">Fig $3\. <b>/sgi;
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><i>Fig (\d+)\. /<p\[$1\] class\=\"$2\">Fig $3\. <i>/sgi;

		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b>Fig\. (\d+)\. /<p\[$1\] class\=\"$2\">Fig\. $3\. <b>/sgi;
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b>Fig\. (\d+)\. /<p\[$1\] class\=\"$2\">Fig\. $3\. <b>/sgi;
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><i>Fig\. (\d+)\. /<p\[$1\] class\=\"$2\">Fig\. $3\. <i>/sgi;
		
		$Line=$_;	
		$Variable="";	
		while($Line =~/<p\[(\d+)\] class\=\"[^\"]+\">\[\[figure\-(\d+)\]\]<\/p\[\1\]>(.*?)<p\[(\d+)\] class\=\"[^\"]+\">\[\[\/figure\-\2\]\]<\/p\[\4\]>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $figcontent="$3";
			my $figid="$2";
			
			$figcontent=~s/<p\[(\d+)\] class\=\"[^\"]+\"><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.(\w+)\"><\/span\[\2\]><\/p\[\1\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$figid\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$3\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">Figure $figid<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">Insert your Caption Here<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$figid\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
			
			$Curr="$figcontent";
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$_ = $Variable;
		
		#exit;
		
		if($_=~/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\3\]>\s*<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\">\s*(?:<[^<]+>)?Figure (\d+)\:?\.?(?:<\/[^<]+>)?\.?\:? ?(.*?)<\/p\[\5\]>/si)
		{
			
			$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\3\]>\s*<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\">\s*(?:<[^<]+>)?Figure (\d+)\:?\.?(?:<\/[^<]+>)?\.?\:? ?(.*?)<\/p\[\5\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$7\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$4\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">Figure $7<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$8<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$7\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;


		}

		if($_=~/<p\[(\d+)\] class\=\"([^\"]+)\"><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\3\]><\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\"><b>Figure (\d+)\:<\/b> ?(.*?)<\/p\[\5\]>/si)
		{
			$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\3\]><\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\"><b>Figure (\d+)\:<\/b>\.? ?(.*?)<\/p\[\5\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$7\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$4\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">Figure $7<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$8<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$7\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;


		}
		
		
		if($_=~/<span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\">/si)
		{

			
			$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*(<[^<]+>)Figure (\d+)\:?\.?(<\/[^<]+>)\.?\:? ?(.*?)<\/p\[\1\]>\s*<p\[\d+\] class\=\"([^\"]+)\"><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\d+\]><\/p\[\d+\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$4\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$4\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">Figure $4<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$6<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$4\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
			
			$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*(<[^<]+>)Figure (\d+)\:?(<\/[^<]+>)\.?\:? ?(.*?)<br\/><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\d+\]>(.*?)<\/p\[\1\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$4\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$4\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">Figure $4<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$6<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$4\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
		

			$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*(<[^<]+>)Fig\.? ?(\d+)\:?(<\/[^<]+>)\.?\:? ?(.*?)<\/p\[\1\]>\s*<p\[\d+\] class\=\"([^\"]+)\"><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\d+\]><\/p\[\d+\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$4\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$4\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">Figure $4<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$6<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$4\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
			
			$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*(<[^<]+>)Fig\.? ?(\d+)\:?(<\/[^<]+>)\.?\:? ?(.*?)<br\/><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.\w+\"><\/span\[\d+\]>(.*?)<\/p\[\1\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$4\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$4\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">Figure $4<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$6<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$4\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
			
			$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">Figure (\d+)\. (.*?)<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\"><span\[(\d+)\] class\=\"INLINEFIG\" id\=\"inline\-(\d+)\.png\"><\/span\[(\d+)\]><\/p\[\5\]>/<div class\=\"FIGBLOCK\"><p\[$1\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$3\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/$dirs1\/FIGS\/inline\-$8\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">Figure $3<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$4<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig-$3\"\/\]\]<\/button><\/p\[$1\]><\/div>/sgi;
				
		
			$_=~s/<span class\=\"FIG\-TITLE\" data\-element\=\"title\">\. /<span class\=\"FIG\-TITLE\" data\-element\=\"title\">/sgi;
			$_=~s/<span class\=\"FIG\-TITLE\" data\-element\=\"title\"><b>\. /<span class\=\"FIG\-TITLE\" data\-element\=\"title\"><b>/sgi;

			#print ERR "$_";
			
		}
		
		#exit;
		#print ERR "$_";
		$_=~s/<span class\=\"FIG\-TITLE\" data\-element\=\"title\"><\/b> /<span class\=\"FIG\-TITLE\" data\-element\=\"title\">/gi;
		$_=~s/<span class\=\"FIG\-TITLE\" data\-element\=\"title\"><b>\. /<span class\=\"FIG\-TITLE\" data\-element\=\"title\"><b>/sgi;

		
		my $dirs2="$dirs";
		$dirs2=~s/\//\\/g;


		if($pubname!~/^(SIAM)$/)
		{
			use File::Copy::Recursive qw(fcopy rcopy dircopy fmove rmove dirmove);
			my $num_of_files_and_dirs = dircopy("$dirs2\\$filenamex\\word\\FIGS\\", "$dirs2\\FIGS");
		}
		
		
		
		#chdir("$dirs2\\FIGS");
		my @files = glob("$dirs2\\FIGS\\*");
		if (scalar @files == 0)
		{
			#$_=~s/<img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/Files\/([^\"]+)\/FIGS\/fig\-(\d+)\.png\"><\/img>//gi;
			#print ERR "$_\n";
		}
		#exit;
		
		#print ERR "@files";
		#exit;
		
		chdir("$dirs2\\FIGS");

		mkdir("$dirs2\\FIGS\\Print");

		#foreach $figs (@files)
		#{
		#	if($figs!~/(\.png$)/)
		#	{
		#		my $figs1="$figs";
		#		my $fig_name = $1 if($figs1=~/([^\\\/]+)\.(\w+)$/);
		#		
		#		$figs1=~s/\.(\w+)$/\.png/g;
		#		
		#		#print ERR "\"C\:\\Program Files\\ImageMagick\-7\.0\.8\-Q16\\magick\.exe\" convert \"$figs\" \"$figs1\"";
		#		#exit;
		#		if($figs =~/\.eps$/)
		#		{
		#			$figs1=~s/([^\w]*)figure(\d+)/$1inline\-$2/sgi;
		#			$fig_name=~s/figure//gi;
		#			system("\"C\:\\Program Files\\gs\\gs9\.54\.0\\bin\\gswin64c\.exe\" \-q \-dSAFER \-dBATCH \-dNOPAUSE \-dNOPROMPT \-dEPSCrop \-sDEVICE=png16m \-sOutputFile\=$figs1 \"$figs\"");
		#			move($figs, "$dirs2\\FIGS\\Print\\$fig_name\.eps");
		#		}
		#		elsif($pubname!~/^(SIAM)$/ && $jornalconfig!~/<FILE type="Tex"\/>/si)
		#		{
		#			system("\"C\:\\Program Files\\ImageMagick\-7\.0\.8\-Q16\\magick\.exe\" convert \"$figs\" \"$figs1\"");
		#		}
		#		else
		#		{
		#			
		#			$figs1=~s/([^\w]*)figure(\d+)/$1inline\-$2/sgi;
		#			system("\"C\:\\Program Files\\ImageMagick\-7\.1\.0\-Q16\-HDRI\\magick\.exe\" convert \"$figs\" \"\-trim\" \"$figs1\"");
		#		}
		#		
		#		
		#		unlink("$figs");
		#		#print ERR "$figs\n";
		#		# print ERR "\"C\:\\Program Files\\ImageMagick\-7\.0\.10\-Q16\\magick\.exe\" convert $figs $figs1";
		#	}
		#	else
		#	{
		#		#$_=~s/<img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/Files\/([^\"]+)\/FIGS\/fig\-(\d+)\.png\"><\/img>//gi;
		#		#print ERR "sss$figs\n";
		#	}
		#}
		
		
		

		
		$Line=$_;	
		$Variable="";	
		while($Line =~/<p\[(\d+)\] class\=\"FIGURE\" (.*?)<\/p\[\1\]>/sgi)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			
			if($Curr=~/<img class\=\"FIG\" src\=\"([^<]+)\/FIGS\/(inline\-(\d+)\.png)\"\/>/i)
			{
				my $figid="$2";
				if($Curr=~/ data\-element\=\"fig\" data\-attribs\-id\=\"(fig\-\d+)\">/i)
				{
					my $newfigid="$1";
					#print "$figid\n";
					
					system("\"C\:\\Program Files\\ImageMagick\-7\.0\.8\-Q16\\magick\.exe\" convert $figid $newfigid\.tif\"");
					move("$newfigid\.tif", "Print\\$newfigid\.tif");
					
				}
				
				
				#print ERR "$figid\n\n";
				
			}
			
			
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$_ = $Variable;
				
		
		#exit;
		
		#print ERR "$_";
		#exit;
		
		
	#}
	

	$_=~s/<div\[(\d+)\] class\=\"floats\">(.*?)<\/div\[\1\]>/<floats>$2<\/floats>/sgi;
	
	
	#######FLOATS
	
	my $unwantedfloatspara="Lists of Figures|List of Tables|Figure Legends?|Tables";
	
	#print ERR "$_";
	#exit;
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<floats>(.*?)<\/floats>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		
		
		$Curr=~s/<p\[(\d+)\] class\=\"[^\"]+\"><a class\=\"TABLINK\" href\=\"\#table\-\d+">Table (\d+)\.?\:?\s*<\/a>\.?\:?\s*<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"[^\"]+\">/<p\[$3\] class\=\"normal\">Table $2\. /sgi;
		#print ERR "$Curr\n";
		$Curr=~s/<p\[(\d+)\] class\=\"[^\"]+\">(<\w+>)?Figure legends?\:?(<\/\w+>)?<br><\/br><b>/<p\[$1\] class\=\"normal\"><b>/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"[^\"]+\">(<\w+>)?($unwantedfloatspara)(<\/\w+>)?<\/p\[\1\]>//gi;
		#print ERR "$Curr\n";

		$Curr=~s/<h(\d+) class\=\"heading(\d+)\">/<p\[000] class\=\"normal\">/gi;
		$Curr=~s/<\/h(\d+)>/<\/p\[000]>/gi;
		
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><a class\=\"FIGLINK\" href\=\"\#fig\-\d+">Figure (\d+)<\/a>\;/<p\[$1\] class\=\"normal\">Figure $2\./gi; 
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><b>Fig\.(\d+)\(/<p\[$1\] class\=\"normal\">Fig\. $2\. <b>\(/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><b>Fig\. (\d+)\: /<p\[$1\] class\=\"normal\">Fig\. $2\: <b>/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><a class\=\"FIGLINK\" href\=\"\#fig\-\d+">Figure (\d+)<\/a>\&\#x02013\;\s*/<p\[$1\] class\=\"normal\">Figure $2\. /gi;
		#print ERR "$Curr\n";
		$Curr=~s/<p\[(\d+)\] class\=\"normal\">Figure (\d+)\;/<p\[$1\] class\=\"normal\">Figure $2\./gi; 
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><b>Figure(\d+)\. /<p\[$1\] class\=\"normal\"><b>Figure $2\. /gi;
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><b>Figure Legend\:<\/b><\/p\[\1\]>//gi;
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><b>List of figures\:?<\/b><\/p\[\1\]>//gi;
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><b>Figure(\d+)\.<\/b>([A-z]+)/<p\[$1\] class\=\"normal\">Figure $2\. $3/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><b>Table(\d+)\.([A-z]+)/<p\[$1\] class\=\"normal\">Table $2\. <b>$3/gi;
		
		# print ERR "$Curr\n";
		
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><a class\=\"FIGLINK\" href\=\"\#fig\-(\d+)\">Figure (\d+)<\/a>/<p\[$1\] class\=\"normal\">Figure $3/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><b>FIGURE (\d+)\:? ?/<p\[$1\] class\=\"normal\">FIGURE $2\. <b>/gi; 
		$Curr=~s/<p\[(\d+)\] class\=\"normal\">(List of Figures?|Figure legends?|LEGENDS|Figure Captions)\:?\.? ?<\/p\[\1\]>\s*//gi;
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><b>(Figure legends|LEGENDS|Figure Captions)\:?\.? ?<\/b><\/p\[\1\]>\s*//gi;
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><a class\=\"FIGLINK\" href\=\"\#fig\-\d+\">(.*?)<\/a>/<p\[$1\] class\=\"normal\">$2/gi;
		
		
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><b>(Fig\.?|Figure)\s*(\d+)\.?<\/b>\.? (.*?)<\/p\[\1\]>/<div class\=\"FIGBLOCKNEW\"><p class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$3\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/Journals\/$pubname\/$jname\/$dirnamex\/FIGS\/inline\-$3\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">$2 $3<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$4<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig\-$3\"\/\]\]<\/button><\/p><\/div>/gi;
		
		
		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><i>(Fig\.?|Figure)\s*(\d+)\.?<\/i>\.? (.*?)<\/p\[\1\]>/<div class\=\"FIGBLOCKNEW\"><p class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$3\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/Journals\/$pubname\/$jname\/$dirnamex\/FIGS\/inline\-$3\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">$2 $3<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$4<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig\-$3\"\/\]\]<\/button><\/p><\/div>/gi;
		
		
		$Curr=~s/<p\[(\d+)\] class\=\"normal\">(Fig\.?|Figure)\s*(\d+)\.?\.?\:? (.*?)<\/p\[\1\]>/<div class\=\"FIGBLOCKNEW\"><p class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$3\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/Journals\/$pubname\/$jname\/$dirnamex\/FIGS\/inline\-$3\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">$2 $3<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$4<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig\-$3\"\/\]\]<\/button><\/p><\/div>/gi;

		$Curr=~s/<p\[(\d+)\] class\=\"normal\"><b>(Fig\.?|Figure)\s*(\d+)\.?\.?\:?<\/b> (.*?)<\/p\[\1\]>/<div class\=\"FIGBLOCKNEW\"><p class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$3\"><img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\/Journals\/$pubname\/$jname\/$dirnamex\/FIGS\/inline\-$3\.png\"\/><span class\=\"FIG\-LABEL\" data\-element\=\"label\">$2 $3<\/span><span class\=\"FIG\-CAPTION\" data\-element\=\"caption\"><span class\=\"FIG\-TITLE\" data\-element\=\"title\">$4<\/span><\/span><button class\=\"hide\">\[\[transgraphic mimetype\=\"image\" mime\-subtype\=\"tif\" xlink\:href\=\"fig\-$3\"\/\]\]<\/button><\/p><\/div>/gi;

		# Figure source update 13-05-2023
		
		$Curr=~s/(<p(\[\d+\]) class\=\"normal\">.*?<\/p\2>\s*\n<table)/<FIG-SEP\/>\n$1/si;
		$Curr=~s/(<p(\[\d+\]) class\=\"normal\">\[\[table\-\d+\]\]<\/p\2>|<\/floats>)/<FIG-SEP\/>\n$1/si;
		$Curr=~s/(<\/span><button class\=\"hide\">[^<>]*<\/button><\/p><\/div>\s*)((<p(\[\d+\]) class\=\"normal\">.*?<\/p\4>\s*)+)/<FIGURESOURCE>$2<\/FIGURESOURCE>$1/sgi;
		$Curr=~s/<FIG-SEP\/>\s*//gsi;
		
		while($Curr =~/<FIGURESOURCE>((?:(?!<FIGURESOURCE>).)*?)<\/FIGURESOURCE>/sgi)	
		{
			my $fig_sruc = $&;
			$fig_sruc =~s/<\/p\[\d+\]>\s*<p\[\d+\] class\=\"normal\">/<br\/>/sgi;
			$fig_sruc =~s/(<\/p\[\d+\]>|<p\[\d+\] class\=\"normal\">)//sgi;
			$fig_sruc =~s/<FIGURESOURCE>/<span class="FIGURESOURCE">/sgi;
			$fig_sruc =~s/<\/FIGURESOURCE>/<\/span>/sgi;
			$fig_sruc =~s/\s*<\/span>/<\/span>/sgi;
			$Curr =~s/<FIGURESOURCE>((?:(?!<FIGURESOURCE>).)*?)<\/FIGURESOURCE>/$fig_sruc/si;
			
		}
		
		
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	

	$Line=$_;	
	$Variable="";	
	while($Line =~/<p class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-(\d+)\">/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		my $figid="$1";
		
		$_=~s/<div class\=\"FIGBLOCK\"><p\[(\d+)\] class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-$figid\">(.*?)<\/p\[\1\]><\/div>\s*//sgi;		
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	#$Variable .=$Line;	
	#$_ = $Variable;
	
	$_=~s/<div class\=\"FIGBLOCKNEW\">/<div class\=\"FIGBLOCK\">/gi;
	
	open(QXXQ, "<$dirs2\\FIGS\\Journal\_Specific\_Rename\.html");
	my $figdata = <QXXQ>;
	close (QXXQ);
	#print "$figdata\n";
	#exit;

	

	$Line=$_;	
	$Variable="";	
	while($Line =~/<p class\=\"FIGURE\" data\-element\=\"fig\" data\-attribs\-id\=\"fig\-(\d+)\">(.*?)<\/p>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		my $figid="$1";
		
		if($figdata=~/<td>($filenamex\_O\_F\d+$figid(\w)\.(\w+))<\/td>/i)
		{
			my $fullfilename="$1";
			$Curr=~s/\/(\w{4})\_(\w)\_(\w+)\/FIGS\/inline\-(\d+)\.png\"\/>/\/$1\_$2\_$3\/FIGS\/$fullfilename\"\/>/gi;
		}
		
		$Curr=~s/<img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Files\//<img class\=\"FIG\" src\=\"\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/\.\.\/Integra\/iPub3Files\/Files\//gi;
		#print ERR "$Curr\n";
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	
	#exit;
	$_=~s/<span class\=\"FIG\-TITLE\" data\-element\=\"title\"><\/b> /<span class\=\"FIG\-TITLE\" data\-element\=\"title\">/gi;
	$_=~s/<span class\=\"FIG\-TITLE\" data\-element\=\"title\"><b>\. /<span class\=\"FIG\-TITLE\" data\-element\=\"title\"><b>/sgi;

	# print ERR "$_";
	#exit;


}

sub SECCITATION
{
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<div(\[\d+\]) class="(?:bodymatter|ACK|floats|APP\-GROUP)">(.*?)<\/div\1>/sgi)	
	{
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
	
		#$Curr=~s/([> \(\[]+)(Sections? (\d+(\.\d+)*))( and | to )(\d+(\.\d+)*)/$1<a class=\"SECTIONLINK\" href=\"\#sec\-$3\">$2<\/a>$5<a class=\"SECTIONLINK\" href=\"\#sec\-$6\">$6<\/a>/sig;
		#$Curr=~s/([> \(\[]+)(Sections? (\d+(\.\d+)*))/$1<a class=\"SECTIONLINK\" href=\"\#sec\-$3\">$2<\/a>/sig;
		$Curr=~s/([> \(\[]+)((?:Sub)?Sections? (\d+(\.\d+)*))( and | to )(\d+(\.\d+)*)/$1<a class=\"SECTIONLINK\" href=\"\#sec\-$3\">$2<\/a>$5<a class=\"SECTIONLINK\" href=\"\#sec\-$6\">$6<\/a>/sig;
		$Curr=~s/([> \(\[]+)((?:Sub)?Sections? (\d+(\.\d+)*))/$1<a class=\"SECTIONLINK\" href=\"\#sec\-$3\">$2<\/a>/sig;
		
		while($Curr=~s/(<a class=\"SECTIONLINK\" href=\"[^\"]+\">[^<>]+<\/a>)(\, ?|\,? and | to )(\d+(\.\d+)*)/$1$2<a class=\"SECTIONLINK\" href=\"\#sec\-$3\">$3<\/a>/sig){}
		
		if($pubname=~/^(CUP)$/ && $jornalconfig=~/<FILE type="Tex"\/>/si)
		{
			#app link
			$Curr=~s/([> \(\[]+)(?<!<title>)(Appendix ([A-Z](\.?\d+)?))(\s+|\)|\.|\])/$1<a class=\"APPXLINK\" href=\"\#app$Name_NUM{$3}\">$2<\/a>$5/sig;
		}
				
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
		
	
}


sub EQNCITATION
{
	
	$_=~s/<(b|i)>((Equations?|Eqs?\.? \(?(\d+)([a-z])?\)?))<\/\1>/$2/gi;
	
	#print ERR "$_\n";
	#exit;
	
	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations ?|Equation ?)(\(?\d+ ?([A-Za-z])?\)?) and (\(?\d+ ?([A-Za-z])?\)?))/$1<EQN\-GRP>$2<\/EQN\-GRP>/g;
	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations ?|Equation ?)(\(?\d+ ?([A-Za-z])?\)?)\-(Eqs?\.? ?|Equations ?|Equation ?)(\(?\d+ ?([A-Za-z])?)\)?)/$1<EQN\-GRP>$2<\/EQN\-GRP>/g;


	$_=~s/Equation (\()?(\d+)<i>([A-zA-Z])\, ([A-zA-Z])(\))?<\/i>/Equation $1$2$3\, $4$5/g;
	$_=~s/Equation (\()?(\d+)<i>([A-zA-Z])<\/i>(\))?/Equation $1$2$3$4/g;
	$_=~s/Equation (\()?<i>(\d+)([A-zA-Z])<\/i>(\))?/Equation $1$2$3$4/g;
	$_=~s/Equation (\()?<i>(\d+)([A-zA-Z])\, ([A-zA-Z])(\))?<\/i>/Equation $1$2$3\, $4$5/g;
	#$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations ?)(\(?\d+ ?([A-Za-z])?\)?) (and|to) (\(?([A-Za-z])\)?))/$1<EQN\-GRP>$2<\/EQN\-GRP>/g;
#print ERR "$_\n";
	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations ?|equations ?)(\(?\d+ ?([A-Za-z])?\)?) (and|to) (\(?\d+ ?([A-Za-z])?\)?))/$1<EQN\-GRP>$2<\/EQN\-GRP>/g;
	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations ?|equations ?)(\(?\d+ ?([A-Za-z])?\)?) ?(\-|\&\#\x02013\;|\,) ?(\(?\d+ ?([A-Za-z])?\)?))/$1<EQN\-GRP>$2<\/EQN\-GRP>/g;

	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations ?)(\(?\d+ ?([A-Za-z])?\)?)\, (\(?\d+ ?([A-Za-z])?\)?)\, (\(?\d+ ?([A-Za-z])?\)?)\, (\(?\d+ ?([A-Za-z])?\)?))/$1<EQN\-GRP>$2<\/EQN\-GRP>/g;

	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations ?)(\(?\d+ ?([A-Za-z])?\)?)\, (\(?\d+ ?([A-Za-z])?\)?)\, (\(?\d+ ?([A-Za-z])?\)?))/$1<EQN\-GRP>$2<\/EQN\-GRP>/g;

	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations ?)(\(?\d+ ?([A-Za-z])?\)?)\, (\(?\d+ ?([A-Za-z])?\)?))/$1<EQN\-GRP>$2<\/EQN\-GRP>/g;
	
	#for (1.1)
	$_=~s/\((Equation\-(\d+\.\d+))\)/\(<EQNLINK>$1<\/EQNLINK>\)/g;
	
	$_=~s/\((Equation\-(\d+))\)/\(<EQNLINK>$1<\/EQNLINK>\)/g;

	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations? )(\(?\d+ ?([A-Za-z])\)?))(\b)/$1<EQNLINK>$2<\/EQNLINK>$6/gi;
	#print ERR "$_";
	
	#for (1.1)
	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations? |Formula )(\(\d+\.\d+\)?\)))/$1<EQNLINK>$2<\/EQNLINK>/gi;
	$_=~s/(<\/EQNLINK>\s*and\s*)(\(\d+\.\d+\))/$1<EQNLINK>$2<\/EQNLINK>/gi;
	
	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations? |Formula )(\(\d+\)?\)))/$1<EQNLINK>$2<\/EQNLINK>/gi;
	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations? |Formula )(\d+))/$1<EQNLINK>$2<\/EQNLINK>/gi;
	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations? |Formula )(\(?\d+\)?))(\b)/$1<EQNLINK>$2<\/EQNLINK>$5/gi;


	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations? |Formula )(\(?\d+ ?([A-Za-z])\)?))(\b)/$1<EQNLINK>$2<\/EQNLINK>$6/gi;
	$_=~s/( |\">|<p>|\()((Eqs?\.? ?|Equations? |Formula )(\(?\d+\)?))(\b)/$1<EQNLINK>$2<\/EQNLINK>$5/gi;
	
	$_=~s/<\/EQNLINK>((\,|\:|\-|\&\#\x02013\;) ?([A-Z])\.?)(\b)/$1<\/EQNLINK>$4/g;
	
	$_=~s/<EQNLINK>Eq\. (\(?\d+\)?)([A-Z])<\/EQNLINK> \&amp\; (\1([A-Z]))/<EQNLINK>Eq\. $1$2<\/EQNLINK> \&amp\; <EQNLINK>$3<\/EQNLINK>/g;	
	
	
	#print ERR "$_";
	#exit;


	$Line=$_;	
	$Variable="";	
	while($Line =~/<EQN\-GRP>(.*?)<\/EQN\-GRP>/g)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		#$Curr=~s/(\(?\d+ ?([A-Za-z])?\)?) and /<EQNLINK>$1<\/EQNLINK> and /g;
		
		if($Curr=~/<EQN\-GRP>Eq\.? (\d+)\-Eq\.? (\d+)<\/EQN\-GRP>/i)
		{
			$Curr=~s/<EQN\-GRP>Eq\.? (\d+)\-Eq\.? (\d+)<\/EQN\-GRP>/<EQN\-GRP><EQNLINK>Eq\. $1<\/EQNLINK>\-<EQNLINK>Eq\. $2<\/EQNLINK><\/EQN\-GRP>/g;
			
		}
		elsif($Curr=~/<EQN\-GRP>Eq\.? (\(?\d+\)?)\-Eq\.? (\(?\d+\)?)<\/EQN\-GRP>/i)
		{
			$Curr=~s/<EQN\-GRP>Eq\.? (\(?\d+\)?)\-Eq\.? (\(?\d+\)?)<\/EQN\-GRP>/<EQN\-GRP><EQNLINK>Eq\. $1<\/EQNLINK>\-<EQNLINK>Eq\. $2<\/EQNLINK><\/EQN\-GRP>/g;
			
		}
		#elsif($Curr=~/<EQN\-GRP>Eqs?\. ?((\d+)(\,|\-\&\#\x02013\;) ?(\d+))<\/EQN\-GRP>/i)
		#{
		#	$Curr=~s/<EQN\-GRP>Eqs\. ?\((\d+)(\,|\, |\-\&\#\x02013\;)(\d+)\)<\/EQN\-GRP>/<EQN\-GRP><EQNLINK>Eqs\. \($1<\/EQNLINK>$2<EQNLINK>$3\)<\/EQNLINK><\/EQN\-GRP>/g;
		#	
		#}
		else
		{
		#print ERR "$Curr\n\n";
		$Curr=~s/(\(?\d+ ?([A-Za-z])?\)?)/<EQNLINK>$1<\/EQNLINK>/g;
		$Curr=~s/<\/EQNLINK> (to|and) (\(?\d+ ?([A-Za-z])?\)?)<\/EQN-GRP>/<\/EQNLINK> $1 <EQNLINK>$2<\/EQNLINK><\/EQN-GRP>/g;
		$Curr=~s/ a<\/EQNLINK>nd /<\/EQNLINK> and /sgi;
		}
		#print ERR "$Curr\n\n";
		
		$Curr=~s/<EQN\-GRP>(.*?)<\/EQN\-GRP>/$1/g;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;		
	
	
	$_=~s/<\/EQNLINK>(\.(\d+))/$1<\/EQNLINK>/g;

	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<EQNLINK>(.*?)<\/EQNLINK>/g)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		
		#for (1.1)
		if($Curr=~/(\d+)\.(\d+)/)
		{
			my $eqnlabel="$1\_$2";
			$Curr=~s/<EQNLINK>(.*?)<\/EQNLINK>/<EQNLINK href\=\"\#equ$eqnlabel\">$1<\/EQNLINK>/g;
		}
		elsif($Curr=~/(\d+)/)
		{
			my $eqnlabel="$1";
			
			$Curr=~s/<EQNLINK>(.*?)<\/EQNLINK>/<EQNLINK href\=\"\#equ$eqnlabel\">$1<\/EQNLINK>/g;
		}
		
		
		$Curr=~s/\-(\(?\d+\)?)/<\/EQNLINK>\-<EQNLINK>$1/g;
		#print ERR "$Curr\n\n";
		
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;	
	


	$_=~s/<EQNLINK href\=\"\#(\w+)\">(\w+)<\/EQNLINK>( to | and |\-)<EQNLINK>/<EQNLINK href\=\"\#$1\">$2<\/EQNLINK>$3<EQNLINK href\=\"\#$1\">/g;	

	$_=~s/<EQNLINK href\=\"\#equ(\d+)\">/<EQNLINK href\=\"\#equ\-$1\">/g;
	
	
	
	#print ERR "$_";


	$_=~s/<EQNLINK /<a class\=\"EQUATIONLINK\" /g;	
	$_=~s/<\/EQNLINK>/<\/a>/g;	



	
	$_=~s/(\(|\,|\;| |\:|\))?(Eqs?\. ?|Equations ?)<a class\=\"EQUATIONLINK\" href\=\"\#equ\-(\d+)\">\s*/$1<a class\=\"EQUATIONLINK\" href\=\"\#equ\-$3\">$2 /g;
	$_=~s/  / /g;
	
	#print ERR "$_";
	#exit;
	
	
	$_=~s/<(\/)?hyperlink>//g;
	
	####StatementCITATION
	my $match_state = 'Statements?|Propositions?|Proofs?|Notations?|Proof_Theorem|Assumptions?|Questions?|Conditions?|Claims?|Problems?|Hypothesise?s?|Lemmas?|Theorems?|Examples?|Remarks?|facts?|Definitions?|Notes?|Property|Constraints?|Algorithms?|Observations?|Corollarys?';

	$_=~s/<(b|i)>(($match_state) \(?(\d+)([a-z])?\)?)<\/\1>/$2/gi;
	
	
	#for algorithm A.1
	$_=~s/( |\">|<p>|\()(($match_state) ?\(?([A-Z]\.?\d+))/$1<STMLINK type\=\"$3\">$2<\/STMLINK>/g;
	while($_=~s/(<STMLINK type\=\"([^\"]+)\">[^<>]+<\/STMLINK>\,? ?)(and|to)(\,? ?)(\(?([A-Z]\.?\d+))/$1$3$4<STMLINK type\=\"$2\">$5<\/STMLINK>/g){}
	while($_=~s/(<STMLINK type\=\"([^\"]+)\">[^<>]+<\/STMLINK>\,? ?)(\-|\&\#\x02013\;|\,)( ?)(\(?([A-Z]\.?\d+))/$1$3$4<STMLINK type\=\"$2\">$5<\/STMLINK>/g){}


	$_=~s/( |\">|<p>|\()(($match_state) ?(\(?([\d\.?]+)\)?))/$1<STMLINK type\=\"$3\">$2<\/STMLINK>/g;
	while($_=~s/(<STMLINK type\=\"([^\"]+)\">[^<>]+<\/STMLINK>\,? ?)(and|to)(\,? ?)(\(?[\d\.?]+\)?)/$1$3$4<STMLINK type\=\"$2\">$5<\/STMLINK>/g){}
	while($_=~s/(<STMLINK type\=\"([^\"]+)\">[^<>]+<\/STMLINK>\,? ?)(\-|\&\#\x02013\;|\,)( ?)(\(?[\d\.?]+\)?)/$1$3$4<STMLINK type\=\"$2\">$5<\/STMLINK>/g){}
	$_=~s/<STMLINK type\=\"($match_state)\">(($match_state) ?\.)<\/STMLINK>/$2/g;


	$Line=$_;	
	$Variable="";	
	while($Line =~/<STMLINK type\=\"([^\"]+)\">(.*?)<\/STMLINK>/g)
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		my $link_href= $1;
		my $link_cont= $2;
		
		
		$link_href=~s/(Statement|Proposition|Proof|Notation|Proof_Theorem|Assumption|Question|Condition|Claim|Problem|Lemma|Theorem|Hypothesis|Example|Remark|fact|Note|Definition|Algorithm|Constraint|Property|Observation|Corollary)s?/\L$1\E/gi;
		#'
		
		#for algorithm A.1
		if($link_cont=~s/( ?\(?)([A-Z]\.?\d+)(\)?)$/$1<a class\=\"STATEMENTLINK\" href\=\"\#$link_href\">$2<\/a>$3/gi){}	
		
		if($link_cont=~s/( ?\(?)([\d\.?]+)(\)? )(and|to)( \(?)([\d\.?]+)(\)?)$/$1<a class\=\"STATEMENTLINK\" href\=\"\#$link_href\">$2<\/a>$3$4$5<a class\=\"STATEMENTLINK\" href\=\"\#$link_href\">$6<\/a>$7/gi){}
		if($link_cont=~s/( ?\(?)([\d\.?]+)(\)? ?)(\-|\&\#\x02013\;|\,)( ?\(?)([\d\.?]+)(\)?)$/$1<a class\=\"STATEMENTLINK\" href\=\"\#$link_href\">$2<\/a>$3$4$5<a class\=\"STATEMENTLINK\" href\=\"\#$link_href\">$6<\/a>$7/gi){}
		if($link_cont=~s/( ?\(?)([\d\.?]+)(\)?)$/$1<a class\=\"STATEMENTLINK\" href\=\"\#$link_href\">$2<\/a>$3/gi){}
		
		$Curr= $link_cont;
		
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;	

	$Line=$_;	
	$Variable="";	
	while($Line =~/<a class\=\"STATEMENTLINK\" href\=\"([^\"]+)\">([^\><]+)<\/a>/ig)
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		my $anch_cont = $2;

		$anch_cont=~s/\.$//g;
		$anch_cont=~s/\./\-/g;

		$Curr=~s/<a class\=\"STATEMENTLINK\" href\=\"([^\"]+)\">/<a class\=\"STATEMENTLINK\" href\=\"$1\-$anch_cont\">/ig;
		$Curr=~s/\.<\/a>/<\/a>\./ig;

			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;	

	$Line=$_;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"(?:entitle|enlabel)\">(.*?)<\/p\[\1\]>/sig)
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';

		$Curr=~s/<a class\=\"STATEMENTLINK\" href\=\"([^\"]+)\">([^\><]+)<\/a>/$2/sig;

			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;	
	
	####/StatementCITATION
	
	$Line=$_;
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"refpara\">(.*?)<\/p\[\1\]>/sig)
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';

		$Curr=~s/<a class\=\"[^\"]+LINK\" href=\"[^\"]+\">((?:(?!<\/a>).)*?)<\/a>/$1/sig;
		

	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;	
	
	#exit;
	
}


sub TABLECITATION
{

	$_=~s/<(b|i)>(Table\-? ?(\d+)([a-z])?\)?\.?)<\/\1>/$2/gi;
	$_=~s/<(b|i)>(Tables?\-? ?(\d+)([a-z])?\)?\.?)<\/\1> and <(b|i)>(\d+)<\/\5>/$2 and $6/gi;
	$_=~s/<(b|i)>(Tables?\-? ?(\d+)([a-z])?\)?\.?)<\/\1> and <(b|i)>(\d+)\.<\/\5>/$2 and $6\./gi;
	#new
	$_=~s/<(b|i)>(Table\-? ?([A-Z\.\-]{2}\d+)\)?\.?)<\/\1>/$2/g;
	$_=~s/<b>\s*(<i>Table(?:(?!<\/i>).)*?<\/i>)\s*<\/b>/$1/sgi;
	$_=~s/<(b|i)>(Table\-? ?(\d+\.\d+)\)?\.?)<\/\1>/$2/g;
	$_=~s/<(b|i)>(Table\-? ?((?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3}))\)?\.?)<\/\1>/$2/g;
	
	$_=~s/( |\">|<p>|\()((Tabs\.? ?|Tables ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?))/$1<TAB\-GRP>$2<\/TAB\-GRP>/g;

	$_=~s/( |\">|<p>|\()((Tabs\.? ?|Tables ?)(\d+) and (\d+))/$1<TAB\-GRP>$2<\/TAB\-GRP>/g;
	

	$_=~s/( |\">|<p>|\()((Tabs\.? ?|Tables ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?))/$1<TAB\-GRP>$2<\/TAB\-GRP>/g;

	$_=~s/( |\">|<p>|\()((Tabs\.? ?|Tables ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?))/$1<TAB\-GRP>$2<\/TAB\-GRP>/g;

	$_=~s/( |\">|<p>|\()((Tabs?\.? ?|Tables ?)(\d+ ?([A-Za-z])?)\-(Tabs?\.? ?|Tables ?|Table ?)(\d+))/$1<TAB\-GRP>$2<\/TAB\-GRP>/g;
	
	

	$_=~s/( |\">|<p>|\()((Tabs?\. ?|Tables? |table\-|tableau )(\d+ ?([A-Za-z])))(\b)/$1<TABLINK>$2<\/TABLINK>$6/gi;
	$_=~s/( |\">|<p>|\()((Tabs?\. ?|Tables? |table\-|tableau )(\d+))(\b)/$1<TABLINK>$2<\/TABLINK>$5/gi;
	
	#new
	$_=~s/( |\">|<p>|\()((tabs?\. ?|tables? |Tabs?\. ?|Tables? |table\-|Table\-|tableau)([A-Z\.\-]{2}\d+))(\b)/$1<TABLINK>$2<\/TABLINK>$5/g;
	$_=~s/( |\">|<p>|\()((tabs?\. ?|tables? |Tabs?\. ?|Tables? |table\-|Table\-|tableau)(\d+\.\d+))(\b)/$1<TABLINK>$2<\/TABLINK>$5/g;
	$_=~s/( |\">|<p>|\()((?:tabs?\. ?|tables? |Tabs?\. ?|Tables? |table\-|Table\-)(\,?\s*(?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3}))+\s*(?:and|to|\&amp;|\&\#x0?0026;|\-|\&\#x0?002D;|\&\#x0?2013;)\s*((?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3})))/$1<TAB\-GRP>$2<\/TAB\-GRP>/g;
	$_=~s/( |\">|<p>|\()((tabs?\. ?|tables? |Tabs?\. ?|Tables? |table\-|Table\-)((?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3})))(\b)/$1<TABLINK>$2<\/TABLINK>$5/g;
	
	$_=~s/<\/TABLINK>((\,|\:|\-|\&\#x02013\;) ?([A-Za-z])\.?)(\b)/$1<\/TABLINK>$4/g;
	$_=~s/\((table\-(\d+))\)/\(<TABLINK>$1<\/TABLINK>\)/g;
	$_=~s/<TABLINK>Table (\d+)<\/TABLINK>\.(\d+) /<TABLINK>Table $1\.$2<\/TABLINK> /g;
	
	$_=~s/(<\/TABLINK>)(\.\d+)/$2$1/g;

	$Line=$_;	
	$Variable="";	
	while($Line =~/<TAB\-GRP>(.*?)<\/TAB\-GRP>/g)
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		if($Curr=~/<TAB\-GRP>Tab\.? (\d+)\-Tab\.? (\d+)<\/TAB\-GRP>/i)
		{
			$Curr=~s/<TAB\-GRP>Tab\.? (\d+)\-Tab\.? (\d+)<\/TAB\-GRP>/<TAB\-GRP><TABLINK>Tab\. $1<\/TABLINK>\-<TABLINK>Tab\. $2<\/TABLINK><\/TAB\-GRP>/g;
			#print ERR "$Curr\n";
		}
		elsif($Curr=~/((tabs?\. ?|tables? |Tabs?\. ?|Tables? |table\-|Table\-)((?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3})))/)
		{
			$Curr=~s/((?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3}))/<TABLINK>$1<\/TABLINK>/g;
		}
		else
		{
			if($Curr=~/(\d+ ?([A-Za-z])?) and (\d+ ?([A-Za-z])?)/si)
			{
			$Curr=~s/(\d+ ?([A-Za-z])?) and (\d+ ?([A-Za-z])?)/<TABLINK>$1<\/TABLINK> and <TABLINK>$3<\/TABLINK>/g;
			}
			else
			{
		$Curr=~s/(\d+ ?([A-Za-z])?)/<TABLINK>$1<\/TABLINK>/g;
			}
		}
		$Curr=~s/<TAB\-GRP>(.*?)<\/TAB\-GRP>/$1/g;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;		
	
	
	

	$Line=$_;	
	$Variable="";
	while($Line =~/<div\[(\d+)\] ([^<>]*)class\=\"(back)\"([^<>]*)>(.*?)<\/div\[\1\]>/sg)
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/<TABLINK>//sgi;
		$Curr=~s/<\/TABLINK>//sgi;
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;		


	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<TABLINK>(.*?)<\/TABLINK>/g)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		if($Curr=~/Table\-? ?([A-Z\.\-]{2}\d+)\)?\.?/)
		{
			my $tablabel="$1";
			$tablabel=~s/[\.\-]//sgi;
			$Curr=~s/<TABLINK>(Tabs?\.? ?|Tables ?|Table\-)/<TABLINK>$1/g;
			$Curr=~s/<TABLINK>(.*?)<\/TABLINK>/<a class\=\"TABLINK\" href\=\"\#table\-$tablabel\">$1<\/a>/g;
		}

		if($Curr=~/Table\-? ?(\d+\.\d+)\)?\.?/)
		{
			my $tablabel="$1";
			#$tablabel=~s/\./\_/sgi;
			$Curr=~s/<TABLINK>(Tabs?\.? ?|Tables ?|Table\-)/<TABLINK>$1/g;
			$Curr=~s/<TABLINK>(.*?)<\/TABLINK>/<a class\=\"TABLINK\" href\=\"\#table\-$tablabel\">$1<\/a>/g;
		}

		if($Curr=~/[Tt]able\-? ?((?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3}))\)?\.?/)
		{
			my $tablabel="$1";
			$Curr=~s/<TABLINK>(Tabs?\.? ?|Tables ?|Table\-)/<TABLINK>$1/g;
			$Curr=~s/<TABLINK>(.*?)<\/TABLINK>/<a class\=\"TABLINK\" href\=\"\#table\-$tablabel\">$1<\/a>/g;
		}
		
		if($Curr=~/<TABLINK>((?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3}))<\/TABLINK>/)
		{
			my $tablabel="$1";
			$Curr=~s/<TABLINK>(.*?)<\/TABLINK>/<a class\=\"TABLINK\" href\=\"\#table\-$tablabel\">$1<\/a>/g;
		}

		if($Curr=~/(\d+)/)
		{
			my $tablabel="$1";
			
			$Curr=~s/<TABLINK>(Tabs?\.? ?|Tables ?|Table\-)/<TABLINK>$1/g;
			$Curr=~s/<TABLINK>(.*?)<\/TABLINK>/<a class\=\"TABLINK\" href\=\"\#table\-$tablabel\">$1<\/a>/g;
		}
		
		#print ERR "$Curr\n\n";
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;	
	
	$_=~s/(Supplementary)(\s*|\&nbsp\;|\&\#x0?00A0\;)<a class\=\"(TABLINK|FIGLINK)\" href\=\"([^\"]*)\">([^<>]*)<\/a>/$1$2$5/gi;
		
	
}



sub FIGCITATION
{
	my $FIGURES;
	$Line=$_;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"FIG\-CAPTION\">(.*?)<\/p\[\1\]>/sg)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		$FIGURES .="$Curr\n";
		
		
		$Curr=~s/<p\[(\d+)\] class\=\"FIG\-CAPTION\">(.*?)<\/p\[\1\]>//sg;
		#print ERR "$Curr\n\n";
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;		
	
	
	$_=~s/<(b|i)>((Figs?\.? ?|Figures ?|Figure ?) (\d+)([a-z])?\-?(\d+)?([a-z])?\.?)<\/\1> and <(b|i)>(\d+)<\/\8>/$2 and $9/gi;
	$_=~s/<(b|i)>((Figs?\.? ?|Figures ?|Figure ?) (\d+)([a-z])?\-?(\d+)?([a-z])?\.?)<\/\1>/$2/gi;
	$_=~s/<(b|i)>(Figs?\.? ?|Figures ?|Figure ?)<\/\1> (\d+)([a-zA-Z])?/$2 $3$4/gi;
	
	#new - for fig D.1, D-1, VII, 1.1
	$_=~s/<(b|i)>((Figs?\.? ?|Figures ?|Figure ?) ([A-Z\.\-]{2}\d+)\.?)<\/\1>/$2/gi;
	$_=~s/<(b|i)>((Figs?\.? ?|Figures ?|Figure ?) (\d+\.\d+)\.?)<\/\1>/$2/gi;
	$_=~s/<(b|i)>((Figs?\.? ?|Figures ?|Figure ?) ((?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3}))\.?)<\/\1>/$2/g;
	$_=~s/<(b|i)>(Figs?\.? ?|Figures ?|Figure ?)<\/\1> ([A-Z\.\-]{2}\d+\.?)/$2 $3/gi;
	$_=~s/<(b|i)>(Figs?\.? ?|Figures ?|Figure ?)<\/\1> (\d+\.\d+\.?)/$2 $3/gi;
	$_=~s/<(b|i)>(Figs?\.? ?|Figures ?|Figure ?)<\/\1> ((?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3}))/$2 $3/g;
	
	
	#print ERR "$_\n";
	#exit;
	
	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?|Figure ?)(\d+ ?([A-Za-z])?) and (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;
	$_=~s/( |\">|<p>|\()((figs\.? ?|figures ?|figure ?)(\d+ ?([A-Za-z])?) and (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;	
	$_=~s/( |\">|<p>|\()((Figs?\.? ?|Figures ?|Figure ?)(\d+ ?([A-Za-z])?)\-(Figs?\.? ?|Figures ?|Figure ?)(\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;

	#new
	$_=~s/( |\">|<p>|\()((Figs\.?|Figures|Figure)(\,? [A-Z\.\-]{2}\d+\.?)+ (?:and|to|\&amp;|\&\#x0?0026;|\-|\&\#x0?002D;|\&\#x0?2013;) ([A-Z\.\-]{2}\d+\.?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/gsi;
	$_=~s/( |\">|<p>|\()((Figs\.?|Figures|Figure)(\,? \d+\.\d+\.?)+ (?:and|to|\&amp;|\&\#x0?0026;|\-|\&\#x0?002D;|\&\#x0?2013;) (\d+\.\d+\.?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/gsi;
	$_=~s/( |\">|<p>|\()((Figs\.?|Figures|Figure)(\,? (?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3}))+ (?:and|to|\&amp;|\&\#x0?0026;|\-|\&\#x0?002D;|\&\#x0?2013;) ((?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3})))/$1<FIG\-GRP>$2<\/FIG\-GRP>/gs;


	$_=~s/Figure (\d+)<i>([A-zA-Z])\, ([A-zA-Z])<\/i>/Figure $1$2\, $3/g;
	$_=~s/Figure (\d+)<i>([A-zA-Z])<\/i>/Figure $1$2/g;
	$_=~s/Figure <i>(\d+)([A-zA-Z])<\/i>/Figure $1$2/g;
	$_=~s/Figure <i>(\d+)([A-zA-Z])\, ([A-zA-Z])<\/i>/Figure $1$2\, $3/g;


	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?) (and|to|from|through) (([A-Za-z])))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;
	$_=~s/( |\">|<p>|\()((Fig\. ?|Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?))( and | to | from | through )((Fig\. ?|Figs\.? ?|Figures ?)(([0-9]+)?([A-Z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>$6<FIG\-GRP>$7<\/FIG\-GRP>/sgi;
	$_=~s/( |\">|<p>|\()((Fig\. ?|Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?) (and|to|from|through) (([0-9]+)?([A-Z])))/$1<FIG\-GRP>$2<\/FIG\-GRP>/sgi;
	$_=~s/( |\">|<p>|\()((Figs?\.? ?|Figures ?)(\d+ ?([A-Za-z])?) (and|to|from|through) (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;
	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)(\,|\, and| to| from| through) (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;
	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)(\,|\, and| to| from| through) (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;
	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)(\,|\, and| to) (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;
	
	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)(\,|\, and| to| from| through) (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;
	
	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)(\,|\, and| to| from| through) (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;
	
	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)(\,|\, and| to| from| through) (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;
	
	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)(\,|\, and| to| from| through) (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;

	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)(\,|\, and| to| from| through) (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;

	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)(\,|\, and| to| from| through) (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;

	$_=~s/( |\">|<p>|\()((Figs?\.? ?|Figures ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)(\,|\,? and| to| from| through) (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;

	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;

	$_=~s/( |\">|<p>|\()((Figs\.? ?|Figures ?)(\d+ ?([A-Za-z])?)\, (\d+ ?([A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/g;
	
	$_=~s/\((figure\-(\d+))\)/\(<FIGLINK>$1<\/FIGLINK>\)/g;
	
	$_=~s/( |\">|<p>|\()(Figs\.? ?|Figures? )(\d+)\&\#x02013\;(\d+)/$1$2<FIGLINK>$3<\/FIGLINK>\&\#x02013\;<FIGLINK>$4<\/FIGLINK>/gi;
	#print ERR "$_";
	$_=~s/( |\">|<p>|\()((Figs?\.? ?|Figures? )(\d+ ?([A-Za-z])))(\b)/$1<FIGLINK>$2<\/FIGLINK>$6/gi;
	$_=~s/( |\">|<p>|\()((Figs?\.? ?|Figures? )(\d+))(\b)/$1<FIGLINK>$2<\/FIGLINK>$5/gi;
	
	$_=~s/<\/FIGLINK>((\,|\:|\-|\&\#x02013\;) ?([A-Za-z])\.?)(\b)/$1<\/FIGLINK>$4/g;
	$_=~s/<FIGLINK>Fig\. (\d+)([A-Z])<\/FIGLINK> \&amp\; (\1([A-Z]))/<FIGLINK>Fig\. $1$2<\/FIGLINK> \&amp\; <FIGLINK>$3<\/FIGLINK>/g;	
	
	#new
	$_=~s/( |\">|<p>|\()(Figs?\.?|Figures|Figure)( [A-Z\.\-]{2}\d+\.?)/$1<FIGLINK>$2$3<\/FIGLINK>/gi;
	$_=~s/( |\">|<p>|\()(Figs?\.?|Figures|Figure)( \d+\.\d+\.?)/$1<FIGLINK>$2$3<\/FIGLINK>/gi;
	$_=~s/( |\">|<p>|\()(Figs?\.?|Figures|Figure)( (?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3}))/$1<FIGLINK>$2$3<\/FIGLINK>/g;
	
	#print ERR "$_";
	#exit;

	$_=~s/( |\">|<p>|\()((Figs?\.?|Figures\.?|Figure\.?)(\,? \d+\.? ?(?:[A-Za-z])?)+ (?:and|to|\&amp;|\&\#x0?0026;|\-|\&\#x0?002D;|\&\#x0?2013;) (\d+\.? ?(?:[A-Za-z])?))/$1<FIG\-GRP>$2<\/FIG\-GRP>/gsi;
	$_=~s/( |\">|<p>|\()(Figs?\.? ?|Figures?\.? )(\d+\.? ?(?:[A-Za-z])?)(\s*(?:\&\#x02013\;|and|to)\s*)(\d+\.? ?(?:[A-Za-z])?)/$1$2<FIGLINK>$3<\/FIGLINK>$4<FIGLINK>$5<\/FIGLINK>/gi;
	$_=~s/( |\">|<p>|\()(Figs?\.?|Figures\.?|Figure\.?)( \d+\.? ?(?:[A-Za-z])?)/$1<FIGLINK>$2$3<\/FIGLINK>/gi;
	$_=~s/( |\">|<p>|\()(Figs?\.?|Figures\.?|Figure\.?)( \d+\.? ?(?:[A-Za-z])?)/$1<FIGLINK>$2$3<\/FIGLINK>/gi;

	$Line=$_;	
	$Variable="";	
	while($Line =~/<FIG\-GRP>(.*?)<\/FIG\-GRP>/g)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		#$Curr=~s/(\d+ ?([A-Za-z])?) and /<FIGLINK>$1<\/FIGLINK> and /g;
		
		if($Curr=~/<FIG\-GRP>Fig\.? (\d+)\-Fig\.? (\d+)<\/FIG\-GRP>/i)
		{
			$Curr=~s/<FIG\-GRP>Fig\.? (\d+)\-Fig\.? (\d+)<\/FIG\-GRP>/<FIG\-GRP><FIGLINK>Fig\. $1<\/FIGLINK>\-<FIGLINK>Fig\. $2<\/FIGLINK><\/FIG\-GRP>/g;
			
		}
		else
		{
		#$Curr=~s/(\d+ ?([A-Za-z])?)/<FIGLINK>$1<\/FIGLINK>/sg;
		$Curr=~s/(\d+ ?([A-Za-z]|\.\d+)?\.?)/<FIGLINK>$1<\/FIGLINK>/sg;
		
		#new
		# if($Curr=~/<FIG\-GRP>(.*?)<\/FIG\-GRP>/si)
		# {	
			# my $temp=$1;
			# $temp=~s/([A-Z\.\-]{2}\d+\.?)/<FIGLINK>$1<\/FIGLINK>/sgi;
			# $temp=~s/(\d+\.\d+\.?)/<FIGLINK>$1<\/FIGLINK>/sgi;
			# $temp=~s/((?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3}))/<FIGLINK>$1<\/FIGLINK>/sg;
			# $Curr=~s/<FIG\-GRP>(.*?)<\/FIG\-GRP>/<FIG\-GRP>$temp<\/FIG\-GRP>/si;
		# }
		
		$Curr=~s/<\/FIGLINK> (to|and) ([A-Za-z])<\/FIG-GRP>/<\/FIGLINK> $1 <FIGLINK>$2<\/FIGLINK><\/FIG-GRP>/g;
		$Curr=~s/ a<\/FIGLINK>nd /<\/FIGLINK> and /sgi;
		$Curr=~s/ <\/FIGLINK>([a-z]+) /<\/FIGLINK> $1 /sgi;
		}
		
		$Curr=~s/<FIG\-GRP>(.*?)<\/FIG\-GRP>/$1/g;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;		
	
	
	$_=~s/<\/FIGLINK>(\.(\d+))/$1<\/FIGLINK>/g;

	$Line=$_;	
	$Variable="";
	while($Line =~/<div\[(\d+)\] ([^<>]*)class\=\"(back)\"([^<>]*)>(.*?)<\/div\[\1\]>/sg)
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/<FIGLINK>//sgi;
		$Curr=~s/<\/FIGLINK>//sgi;
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;		

	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<FIGLINK>(.*?)<\/FIGLINK>/g)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#print "\n$Curr";
		
		#new
		if($Curr=~/([A-Z\.\-]{2}\d+)/)
		{
			my $figlabel="$1";

			$figlabel=~s/[\.\-]//sgi;
			
			$Curr=~s/<FIGLINK>(Figs\.? ?|Figures ?)/$1<FIGLINK>/g;
			$Curr=~s/<FIGLINK>(.*?)<\/FIGLINK>/<FIGLINK href\=\"\#fig\-$figlabel\">$1<\/FIGLINK>/g;
		}
		if($Curr=~/(\d+\.\d+)/)
		{
			my $figlabel="$1";

			$figlabel=~s/\./\_/sgi;
			
			$Curr=~s/<FIGLINK>(Figs\.? ?|Figures ?)/$1<FIGLINK>/g;
			$Curr=~s/<FIGLINK>(.*?)<\/FIGLINK>/<FIGLINK href\=\"\#fig\-$figlabel\">$1<\/FIGLINK>/g;
		}
		
		if($Curr=~/(\d+)/)
		{
			my $figlabel="$1";

			$figlabel=~s/\./\-/sgi;
			
			$Curr=~s/<FIGLINK>(Figs\.? ?|Figures ?)/$1<FIGLINK>/g;
			$Curr=~s/<FIGLINK>(.*?)<\/FIGLINK>/<FIGLINK href\=\"\#fig$figlabel\">$1<\/FIGLINK>/g;
		}
		
		if($Curr=~/((?=[IVCMDXL]+)M{0,4}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3}))/)
		{
			my $figlabel="$1";

			$figlabel=~s/\./\-/sgi;
			
			$Curr=~s/<FIGLINK>(Figs\.? ?|Figures ?)/$1<FIGLINK>/g;
			$Curr=~s/<FIGLINK>(.*?)<\/FIGLINK>/<FIGLINK href\=\"\#fig\-$figlabel\">$1<\/FIGLINK>/g;
		}		

		
		#$Curr=~s/\-(\d+)/<\/FIGLINK>\-<FIGLINK>$1/g;
		#print ERR "$Curr\n\n";
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;	
	


	$_=~s/<FIGLINK href\=\"\#(\w+)\">(\w+)<\/FIGLINK>( to | and |\-)<FIGLINK>/<FIGLINK href\=\"\#$1\">$2<\/FIGLINK>$3<FIGLINK href\=\"\#$1\">/g;	

	$_=~s/<FIGLINK href\=\"\#fig(\d+)\">/<FIGLINK href\=\"\#fig\-$1\">/g;
	
	
	
	#print ERR "$_";


	$_=~s/<FIGLINK /<a class\=\"FIGLINK\" /g;	
	$_=~s/<\/FIGLINK>/<\/a>/g;	



	
	$_=~s/(\(|\,|\;| |\:|\)|>)(Figs?\.? ?|Figures? ?)<a class\=\"FIGLINK\" href\=\"([^\"]+)\">/$1<a class\=\"FIGLINK\" href\=\"$3\">$2/sg;
	$_=~s/  / /g;
	$_=~s/ <\/a>([a-z]+)/<\/a> $1/sg;
	$_=~s/ ([a-z])<\/a>([a-z]+)/<\/a> $1$2/sg;
$_=~s/<a class\=\"FIGLINK\" href\=\"([^\"]+)\">(.*?)<\/a>\&\#x02013\;(\d+) and (\d+)(\,|\;|\)|<)/<a class\=\"FIGLINK\" href\=\"$1\">$2<\/a>\&\#x02013\;<a class\=\"FIGLINK\" href\=\"\#fig\-$3\">$3<\/a> and <a class\=\"FIGLINK\" href\=\"\#fig\-$4\">$4<\/a>$5/sg;	
	
	
	#$_=~s/<\/div\[(\d+)\]>\s*<\/body>/<div class\=\"floats\">\n$FIGURES<\/div><\/div\[$1\]><\/body>/i;
	#$_=~s/<(\/)?floats>//g;
	$_=~s/<(\/)?hyperlink>//g;
	
	
	#exit;
	
}


sub BACK
{
	my $bckheading="Funding|Disclosure|Ethics and consent statement|Author Contributions|Institutional Review Board Statement|Informed Consent Statement|Funding|Disclosure|Ethical Consideration and consent form|Data Sharing Statement|Abbreviations|Consent Statement|Ethic Statement|Competing interests|Abbreviations|Disclosure Statement|Consent|Ethical approval|Funding and financial relationships|Competing Interest|Availability of data and material|Authors?\&\#x02019\; contributions|Authors?\&\#x02019\;s contributions|Data availability|Ethics approval and informed consent|Ethical Approval and Informed Consent|Data Sharing Management|Authorship Statement|Funding Statement|Ethics Approval and Informed Consent Statement|DATA SHARING AGREEMENT|Ethics approval and consent to participate|Declarations of interest";
	
	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b>($bckheading)\:?<\/b>\:? (.*?)<\/p\[\1\]>/<p\[$1\] class\=\"$2\"><b>$3<\/b><\/p\[$1\]>\n<p\[000\] class\=\"$2\">$4<\/p\[000\]>/gi;
	
	#print ERR "$_\n";
	#exit;
	
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<div\[(\d+)\] class\=\"bodymatter\">(.*?)<div\[(\d+)\] class\=\"back\">/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/<p\[(\d+)\] class\=\"normal\">((Financial Support|Conflicts of Interest|Financial Disclosure)\:? ?)<\/p\[\1\]>(.*?)<\/div\[(\d+)\]>\s*<div\[(\d+)\] class\=\"back\">/<\/div\[$5\]>\n<div\[$6\] class\=\"back\">\n<p\[$1\] class\=\"normal\">$2<\/p\[$1\]>$4/sgi;
		#print ERR "$Curr";
		#exit;
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	
	
	
	######BACK MATTER ADDITION
	
	
	
	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(Ethics and consent statement|Author Contributions|Institutional Review Board Statement|Informed Consent Statement|Funding|Disclosure|Ethical Consideration and consent form|Data Sharing Statement|Abbreviations|Consent Statement|Ethic Statement|Competing interests|Abbreviations|Disclosure Statement|Consent|Ethical approval|Funding and financial relationships|Competing Interest|Availability of data and material|Authors?\&\#x02019\; contributions|Authors?\&\#x02019\;s contributions|Data availability|Ethics approval and informed consent|Ethical Approval and Informed Consent|Data Sharing Management|Authorship Statement|Funding Statement|Ethics Approval and Informed Consent Statement|DATA SHARING AGREEMENT|Ethics approval and consent to participate|Declarations of interest)\:?\s*<\/p\[\1\]>/<h2 class\=\"heading2\"><b>$3<\/b><\/h2>/gi;
	
	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b>(Ethics and consent statement|Author Contributions|Institutional Review Board Statement|Informed Consent Statement|Funding|Disclosure|Ethical Consideration and consent form|Data Sharing Statement|Abbreviations|Consent Statement|Ethic Statement|Competing interests|Abbreviations|Disclosure Statement|Consent|Ethical approval|Funding and financial relationships|Competing Interest|Availability of data and material|Authors?\&\#x02019\; contributions|Authors?\&\#x02019\;s contributions|Data availability|Ethics approval and informed consent|Ethical Approval and Informed Consent|Data Sharing Management|Authorship Statement|Funding Statement|Ethics Approval and Informed Consent Statement|DATA SHARING AGREEMENT|Ethics approval and consent to participate|Declarations of interest)\:?<\/b>\:?\s*<\/p\[\1\]>/<h2 class\=\"heading2\"><b>$3<\/b><\/h2>/gi;
	
	$_=~s/<h(\d+) class\=\"heading\1\"><b>(Ethics and consent statement|Author Contributions|Institutional Review Board Statement|Informed Consent Statement|Funding|Disclosure|Ethical Consideration and consent form|Data Sharing Statement|Abbreviations|Consent Statement|Ethic Statement|Competing interests|Abbreviations|Disclosure Statement|Consent|Ethical approval|Funding and financial relationships|Competing Interest|Availability of data and material|Authors?\&\#x02019\; contributions|Authors?\&\#x02019\;s contributions|Data availability|Ethics approval and informed consent|Ethical Approval and Informed Consent|Data Sharing Management|Authorship Statement|Funding Statement|Ethics Approval and Informed Consent Statement|DATA SHARING AGREEMENT|Ethics approval and consent to participate|Declarations of interest)\:?<\/b>\:?\s*<\/h\1>/<h2 class\=\"heading2\"><b>$2<\/b><\/h2>/gi;
	
	$_=~s/<h(\d+) class\=\"heading\1\">(Ethics and consent statement|Author Contributions|Institutional Review Board Statement|Informed Consent Statement|Funding|Disclosure|Ethical Consideration and consent form|Data Sharing Statement|Abbreviations|Consent Statement|Ethic Statement|Competing interests|Abbreviations|Disclosure Statement|Consent|Ethical approval|Funding and financial relationships|Competing Interest|Availability of data and material|Authors?\&\#x02019\; contributions|Authors?\&\#x02019\;s contributions|Data availability|Ethics approval and informed consent|Ethical Approval and Informed Consent|Data Sharing Management|Authorship Statement|Funding Statement|Ethics Approval and Informed Consent Statement|DATA SHARING AGREEMENT|Ethics approval and consent to participate|Declarations of interest)\:?\s*<\/h\1>/<h2 class\=\"heading2\"><b>$2<\/b><\/h2>/gi;
	
	
	while ($_=~/<h2 class\=\"heading2\"><b>(Funding|Ethics approval and consent to participate|Availability of data and materials|Abbreviations|Ethics Statement|Data Sharing Statement|Ethics and consent statement|Informed Consent Statement|Institutional Review Board Statement|Author Contributions|Disclosure|Ethical Consideration and consent form|Data Sharing Statement|Consent Statement|Ethic Statement|Competing interests|Abbreviations|Disclosure Statement|Consent|Ethical approval|Funding and financial relationships|Competing Interest|Availability of data and material|Authors?\&\#x02019\; contributions|Authors?\&\#x02019\;s contributions|Data availability|Ethics approval and informed consent|Ethical Approval and Informed Consent|Data Sharing Management|Authorship Statement|Funding Statement|Ethics Approval and Informed Consent Statement|DATA SHARING AGREEMENT|Ethics approval and consent to participate|Declarations of interest)\:?<\/b>\:?<\/h2>\s*<p\[(\d+)\] class\=\"([^\"]+)\">(.*?)<\/p\[\2\]>\s*<\/div\[(\d+)\]>\s*<div\[(\d+)\] class\=\"back\">/sgi)
	{
		$_=~s/<h2 class\=\"heading2\"><b>(Funding|Ethics approval and consent to participate|Availability of data and materials|Abbreviations|Ethics Statement|Data Sharing Statement|Ethics and consent statement|Informed Consent Statement|Institutional Review Board Statement|Author Contributions|Disclosure|Ethical Consideration and consent form|Data Sharing Statement|Consent Statement|Ethic Statement|Competing interests|Abbreviations|Disclosure Statement|Consent|Ethical approval|Funding and financial relationships|Competing Interest|Availability of data and material|Authors?\&\#x02019\; contributions|Authors?\&\#x02019\;s contributions|Data availability|Ethics approval and informed consent|Ethical Approval and Informed Consent|Data Sharing Management|Authorship Statement|Funding Statement|Ethics Approval and Informed Consent Statement|DATA SHARING AGREEMENT|Ethics approval and consent to participate|Declarations of interest)<\/b>\:?<\/h2>\s*<p\[(\d+)\] class\=\"([^\"]+)\">(.*?)<\/p\[\2\]>\s*<\/div\[(\d+)\]>\s*<div\[(\d+)\] class\=\"back\">/<\/div\[$5\]>\n<div\[$6\] class\=\"back\">\n<p\[000\] class\=\"normal\"><b>$1<\/b><\/p\[000\]>\n<p\[$2\] class\=\"normal\">$4<\/p\[$2\]>/sgi;
		
	}
	
	$_=~s/<h(\d+) class\=\"heading(\d+)\">(<b>Disclosure\:?<\/b>)<\/h\1>\s*<\/div\[(\d+)\]>\s*<div\[(\d+)\] class\=\"back\">/<\/div\[$4\]>\n<div\[$5\] class\=\"back\">\n<h$1 class\=\"heading$2\">$3<\/h$1>/sgi;
	$_=~s/<h(\d+) class\=\"heading(\d+)\">(<b>Declaration\:?<\/b>)<\/h\1>\s*<\/div\[(\d+)\]>\s*<div\[(\d+)\] class\=\"back\">/<\/div\[$4\]>\n<div\[$5\] class\=\"back\">\n<h$1 class\=\"heading$2\">$3<\/h$1>/sgi;

	print ERR "$_";
	exit;


	
	######///BACK MATTER ADDITION
	

	#print ERR "$_";
	#exit;

	

#print ERR "$_";
#exit;
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<div\[(\d+)\] class\=\"back\">(.*?)<\/div\[\1\]>/sg)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*Figure\.(\d+)\:/<p\[$1\] class\=\"$2\">Figure $3\:/gi; 
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\*\*\*\*?\*?\*?<\/p\[\1\]>//gi;
		$Curr=~s/\s*<\/p\[(\d+)\]>/<\/p\[$1\]>/g;
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b><i>Table (.*?)<\/i><\/b><\/p\[\1\]>/<p\[$1\] class\=\"$2\"><b>Table $3<\/b><\/p\[$1\]>/sgi;
		$Curr=~s/<h(\d+) class\=\"heading(\d+)\">(Figure Legends?)<\/h\1>/<p\[000\] class\=\"normal\">$3<\/p\[000\]>/gi;
		
		
		#$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(?:<\w+>)?References?\:?(?:<\/(?:\w+)>)?<\/p\[\1\]>(.*?)(<p\[\d+\] class\=\"([^\"]+)\">(<b>)?(Figure legends|Captions|Figure Captions|Figures?|LEGENDS?|Table captions|Graphic Abstract|Tables?|Table\-|Figure |Figure\-|Fig\.? |Notes|List of Figures:?|List of|Appendi|Abbreviat|\[\[figure|\[\[table|Supplementary Material|<span\[\d+\] class\="INLINEFIG\")|<ul\[\d+\] style\=\"list\-style\-type\:none\;\">|<table|<fig|<figure|<app|<a |<div\[\d+\] |<divx |<xdiv|<p\[\d+\] class\=\"FRAMETEXT\">)/<ref-list><p\[$1\] class\=\"$2\">References<\/p\[$1\]>$3<\/ref\-list>\n$4/si;
		#print ERR "$Curr";
		#exit
		
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(?:<\w+>)?References?\:?(?:<\/(?:\w+)>)?<\/p\[\1\]>(.*?)(<p\[\d+\] class\=\"([^\"]+)\">(<b>)?(Figure legends?|Captions|Figure Captions|Figures?|LEGENDS?|Table captions|Graphic Abstract|Tables?|Table\-|Figure |Figure\-|Fig\.? |Notes|List of Figures:?|List of|Appendi|Abbreviat|\[\[figure|\[\[table|Supplementary Material|<span\[\d+\] class\="INLINEFIG\")|<ul\[\d+\] style\=\"list\-style\-type\:none\;\">|<table|<fig|<figure|<app|<a |<div\[\d+\] |<divx |<xdiv|<p\[\d+\] class\=\"FRAMETEXT\">)/<ref-list><p\[$1\] class\=\"$2\">References<\/p\[$1\]>$3<\/ref\-list>\n$4/si;
		
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(?:<\w+>)?References? and Notes\:?(?:<\/(?:\w+)>)?<\/p\[\1\]>(.*?)(<p\[\d+\] class\=\"([^\"]+)\">(<b>)?(Figure legends?|Captions|Graphic Abstract|Figure Captions|Figures?|LEGENDS?|Table captions|Tables?|Figure |Fig\.? |Notes|List of Figures:?|List of|Appendi|Abbreviat|\[\[figure|\[\[table|Supplementary Material|<span\[\d+\] class\="INLINEFIG\")|<ul\[\d+\] style\=\"list\-style\-type\:none\;\">|<table|<fig|<figure|<app|<a |<div\[\d+\] |<divx |<xdiv|<p\[\d+\] class\=\"FRAMETEXT\">)/<ref-list><p\[$1\] class\=\"$2\">References and Notes<\/p\[$1\]>$3<\/ref\-list>\n$4/si;
		
		#print ERR "$Curr\n\n";
		$Curr=~s/<p\[(\d+)\] class\=\"ref\-para\"><\/ref\-list>\s*/<\/ref\-list>\n<p\[$1\] class\=\"ref\-para\">/sg;


		
		
		
		#$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b>References and Notes\:?<\/b><\/p\[\1\]>(.*?)<p\[(\d+)\] class\=\"normal\">((<\w+>)?(Table|Figure) )/<ref-list><p\[$1\] class\=\"$2\">References and Notes<\/p\[$1\]>$3<\/ref\-list><p\[$4\] class\=\"normal\">$5/sg;
		

		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b>References? and Notes\:?<\/b><\/p\[\1\]>(.*?)(<p\[\d+\] class\=\"([^\"]+)?\">(<b>)?Figure legends?|Captions|Figure Captions|Figures?|Table captions|Graphic Abstract|Tables?|Figure |Fig\.? |Notes|List of Figures:?|List of|Appendi|Abbreviat|\[\[figure|\[\[table|Supplementary Material|<span\[\d+\] class\="INLINEFIG\"|<ul\[\d+\] style\=\"list\-style\-type\:none\;\">|<table|<fig|<figure|<app|<\/div\[\d+\]>|<p\[\d+\] class\=\"FRAMETEXT\">)/<ref-list><p\[$1\] class\=\"$2\">References and Notes<\/p\[$1\]>\n<\/ref\-list>$3$4/si;

		if($Curr!~/<ref\-list>/)
		{
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(?:<\w+>)?References?\:?(?:<\/(?:\w+)>)?<\/p\[\1\]>(.*?)<\/div\[(\d+)\]>/<ref-list><p\[$1\] class\=\"$2\">References<\/p\[$1\]>$3<\/ref\-list>\n<\/div\[$4\]>/si;
			#print ERR "$Curr\n\n";
			#exit;
			
		}

		

		if($Curr=~/<ref\-list>/)
		{
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((?:<\w+>)?Acknowledge?ments?(?:.*?))<\/p\[\1\]>(.*?)<ref\-list>/<ACK>\n<p\[$1\] class\=\"ACKPARA\">$3<\/p\[$1\]>$4<\/ACK>\n<ref\-list>/sgi;
		}
		else
		{
			#$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((?:<\w+>)?Acknowledgments(?:.*?))<\/p\[\1\]>\s*<p\[(\d+)\] class\=\"([^\"]+)\">/<ACK>\n<p\[$1\] class\=\"ACKPARA\">$3<\/p\[$1\]>\n<\/ACK>\n<ref\-list>/sg;
		}
		
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;		
	#exit;
	


	$Line=$_;	
	$Variable="";	
	while($Line =~/<ACK>(.*?)<\/ACK>/sg)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((<\w+>)?Abbreviations\:?(<\/\w+>)?)<\/p\[\1\]>\s*<table>/<p\[$1\] class\=\"$2\">$3<\/p\[$1\]>\n<xtable>/sgi;
		
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"ACKPARA\">/gi;
		
		
		if ($Curr=~/<table>/si)
		{
			print "Table content present in ACK, move to the end of manuscript";
			exit;
		}
		
		
		$Curr=~s/<xtable>/<table>/sgi;
		$Curr=~s/<p\[(\d+)\] class\=\"(?:ACKPARA|normal)\">\s*<\/p\[\1\]>\s*//sgi;
		$Curr=~s/<p\[(\d+)\] class\=\"(?:ACKPARA|normal)\">(?:<\w+>)?(Financial supports?|Conflicts? of interest( Disclosure)?|Ethical standards|Funding Sources?)?\:?\.?(?:<\/(\w+)>)?<\/p\[\1\]>/<h1 class\=\"heading1\">$2<\/h1>/sgi;

		if ($Curr=~/<p\[(\d+)\] class\=\"(?:ACKPARA|normal)\">(<\w+>)?(Acknowledge?ments?)\:?\.?(<\/(\w+)>)?<\/p\[\1\]>((?:(?!(<h1|<\/ack)).)*?)(?:<h1|<\/ack)/si)
		{
			my $temp = $&;
			$temp=~s/<p\[(\d+)\] class\=\"normal\">/<p\[$1\] class\=\"ACKPARA\">/sgi;
			$temp=~s/<p\[(\d+)\] class\=\"ACKPARA\">(<\w+>)?(Acknowledge?ments?)\:?\.?(<\/(\w+)>)?<\/p\[\1\]>\s*/<h1 class\=\"heading1\">$3<\/h1>\n/sgi;
			$Curr=~s/<p\[(\d+)\] class\=\"(?:ACKPARA|normal)\">(<\w+>)?(Acknowledge?ments?)\:?\.?(<\/(\w+)>)?<\/p\[\1\]>((?:(?!(<h1|<\/ack)).)*?)(?:<h1|<\/ack)/$temp/si;
		}

		$Curr=~s/<ACK>(.*?)<\/ACK>/<div class\=\"ACK\">$1<\/div>/sgi;
		
		#print ERR $Curr;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;	
	#exit;	

	
	if($_=~/<ref\-list><p\[(\d+)\] class\=\"[^\"]+\">(.*?)<\/p\[\1\]>\s*<\/ref\-list>\s*<ul\[(\d+)\] (.*?)<\/ul\[\3\]>/si)
	{
		$_=~s/<ref\-list><p\[(\d+)\] class\=\"[^\"]+\">(.*?)<\/p\[\1\]>\s*<\/ref\-list>\s*<ul\[(\d+)\] (.*?)<\/ul\[\3\]>/<ref\-list><p\[$1\] class\=\"normal\">$2<\/p\[$1\]>\n<ul\[$3\] $4<\/ul\[$3\]><\/ref\-list>\n/si;
	}
	if($_=~/<ref\-list><p\[(\d+)\] class\=\"[^\"]+\">(.*?)<\/p\[\1\]>\s*<\/ref\-list>\s*<ol\[(\d+)\] (.*?)<\/ol\[\3\]>/si)
	{
		$_=~s/<ref\-list><p\[(\d+)\] class\=\"[^\"]+\">(.*?)<\/p\[\1\]>\s*<\/ref\-list>\s*<ol\[(\d+)\] (.*?)<\/ol\[\3\]>/<ref\-list><p\[$1\] class\=\"normal\">$2<\/p\[$1\]>\n<ol\[$3\] $4<\/ol\[$3\]><\/ref\-list>\n/si;
	}	
	
	
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<ref\-list>(.*?)<\/ref\-list>/sg)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		#print ERR "$Curr\n";
		
		
		$Curr=~s/<ul\[(\d+)\] style\=\"[^\"]+\">(.*?)<\/ul\[\1\]>/$2/sg;
		$Curr=~s/<ol\[(\d+)\] style\=\"[^\"]+\">(.*?)<\/ol\[\1\]>/$2/sg;
		
		$Curr=~s/<list type\=\"(\d+)\_(\d+)\">//gi;
		$Curr=~s/<\/list(\d+)\_(\d+)>//gi;
		$Curr=~s/<ol\[(\d+)\] type\=\"[^\"]+\">(.*?)<\/ol\[\1\]>/$2/sg;
		$Curr=~s/<ul\[(\d+)\] type\=\"[^\"]+\">(.*?)<\/ul\[\1\]>/$2/sg;
		$Curr=~s/<ul>(.*?)<\/ul>/$1/sg;
		$Curr=~s/<li>(.*?)<\/li>/<p class\=\"normal\">$1<\/p>/sg;
		$Curr=~s/<p\[(\d+)\] class\=\"[^\"]+\">(<\w+>)?References?\:?(<\/(\w+)>)?<\/p\[\1\]>//gi;
		$Curr=~s/<p\[(\d+)\] class\=\"[^\"]+\">(<\w+>)?References? and Notes\:?(<\/(\w+)>)?<\/p\[\1\]>//gi;
		
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">/<p\[$1\] class\=\"refpara\">/g;
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((:?<\w+>)?\[?(\d+)\.?\]?(:?<\/(\w+)>)?) /<p\[$1\] class\=\"refpara\">/g;

		$Curr=~s/<\/b>\)<\/p>/\)<\/b><\/p>/g;
		$Curr=~s/<\/b>\.<\/p>/\.<\/b><\/p>/g;
		$Curr=~s/\(<b>/<b>\(/g;
		$Curr=~s/ ((\d+)\:? ?)<\/i>/<\/i> <i>$1<\/i>/g;
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><\/ref\-list>\s*/<\/ref\-list>\n<p\[$1\] class\=\"$2\">/g;
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(\d+)\- ?/<p\[$1\] class\=\"$2\">/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\((\d+)\.?\)\.? ?/<p\[$1\] class\=\"$2\">/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\[(\d+)\.?\]\.? ?/<p\[$1\] class\=\"$2\">/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><sup\[(\d+)\] class\=\"dummy\">\(?\[?(\d+)\)?\]? ?<\/sup\[\3\]> ?/<p\[$1\] class\=\"$2\">/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><sup>\(?\[?(\d+)\)?\]? ?<\/sup> ?/<p\[$1\] class\=\"$2\">/gi;
		$Curr=~s/<p\[(\d+)\] class\=\"refpara\">\s*<\/p\[\1\]>\s*//sgi;
		$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(\d+)\./<p\[$1\] class\=\"$2\">/gi;
		$Curr=~s/<span class="sec-label">((?:(?!<\/span>).)*?)<\/span>/$1/gi;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;		
	
	
	
	my $footnotes="";
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<xdiv class\=\"footnote\" id\=\"footnote(\d+)\">((?:(?!<\/xdiv>).)*?)<\/xdiv>/sgi)	
	{
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';

		$Curr=~s/<x(div class\=\"footnote\" id\=\"footnote\d+\")>((?:(?!<\/xdiv>).)*?)<\/xdiv>/<$1>$2<\/div>/si;
		$Curr=~s/<(\/)?div/<$1div\[0\]/sgi;
		
		$footnotes .="$Curr\n";
		
		$Curr=~s/<(div\[0\] class\=\"footnote\" id\=\"footnote\d+\")>((?:(?!<\/div\[0\]>).)*?)<\/div\[0\]>//si;

	$Variable .=$PreMatch .$Curr;
	}	
	$Variable .=$Line;	
	$_ = $Variable;	
	
	
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<div\[(\d+)\] class\=\"footnote\" id\=\"footnote(\d+)\">(.*?)<\/div\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		

		$footnotes .="$Curr\n";
		
		$Curr=~s/<div\[(\d+)\] class\=\"footnote\" id\=\"footnote(\d+)\">(.*?)<\/div\[\1\]>//sgi;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;			

	
	$footnotes=~s/<p\[(\d+)\] class\=\"normal\"> /<p\[$1\] class\=\"normal\">/gi;
	
	if($footnotes=~/<div\[(\d+)\] class\=\"footnote/i)
	{
		if($_=~/<div\[(\d+)\] class\=\"back\">/i)
		{
			$_=~s/<div\[(\d+)\] class\=\"back\">/<div class\=\"fn\-block\">\n$footnotes<\/div>\n<div\[$1\] class\=\"back\">/si;
		}
		
	}	
	#print ERR "$_\n";
	#exit;
	
	if($_!~/<\/ref\-list>\s*<p\[(\d+)\] class\=\"NOTES\-TITLE\">/i)
	{
	
		$_=~s/<\/ref\-list>\s*<p\[(\d+)\] class\=\"NOTES\-TITLE\">//sgi;
		$_=~s/<\/ref\-list>(.*?)<\/div\[(\d+)\]>/<\/ref\-list><\/div\[$2\]>\n<floats>$1<\/floats>/sg;
	}

	$_=~s/<ref\-list>(.*?)<\/ref\-list>/<div class\=\"references\">$1<\/div>\n/sg;
	
	$_=~s/<p\[(\d+)\] class\=\"ref\-para\">(Figures? |<b>Figures? |<b>Abbreviations?|Abbreviations?)/<p\[$1\] class\=\"normal\">$2/gi;
	$_=~s/<p\[(\d+)\] class\=\"normal\">Figure Legends?\:?<\/p\[\1\]>//gi;	
	
	#print ERR "$_";	
	#exit;
}




sub Sections
{
	open(SCT, "<", "$serverpath/sections\.txt") or die print("$serverpath/sections\.txt NOT FOUND!!!");
	my $sctypes = <SCT>;
	close (SCT);
	
	$_=~s/<p\[(\d+)\] class\=\"heading1\"><b> /<p\[$1\] class\=\"heading1\"><b>/gi;
	$_=~s/<p\[(\d+)\] class\=\"heading2\">(.*?)<\/p\[\1\]>/<h2 class\=\"heading2\">$2<\/h2>/sgi;
	$_=~s/<p\[(\d+)\] class\=\"heading3\">(.*?)<\/p\[\1\]>/<h3 class\=\"heading3\">$2<\/h3>/sgi;
	$_=~s/<p\[(\d+)\] class\=\"heading4\">(.*?)<\/p\[\1\]>/<h4 class\=\"heading4\">$2<\/h4>/sgi;
	$_=~s/<p\[(\d+)\] class\=\"heading5\">(.*?)<\/p\[\1\]>/<h5 class\=\"heading5\">$2<\/h5>/sgi;
	$_=~s/<h2 class=\"heading2\">ABSTRACT<\/h2>/<p class=\"heading2\">ABSTRACT<\/p>/sgi;
	$_=~s/<h3 class=\"heading3\">Keywords<\/h3>/<p class=\"heading3\">Keywords<\/p>/sgi;
	$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">(\d+)\.(Results|Conclusion|Discussion)<\/p\[\1\]>/<p\[$1\] class\=\"$2\">$3\. $4<\/p\[$1\]>/sgi;


	$Line=$_;	
	$Variable="";	
	while($Line =~/<h(\d+) class\=\"heading\1\">(.*?)<\/h\1>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'

		if ($Curr=~/\. \w+ /i)
		{
			$Curr=~s/<h(\d+) class\=\"heading\1\">(.*?)<\/h\1>/<p\[000\] class\=\"normal\">$2<\/p\[000\]>/gi;
			#print ERR "$Curr\n\n";
		}


		#$Curr=~s/<div\[(\d+)\] class\=\"footnote\" id\=\"footnote(\d+)\">(.*?)<\/div\[\1\]>//sgi;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	#exit;
	
	
	#print ERR $_;
	#exit;
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<p\[(\d+)\] class\=\"heading\d+\">(.*?)<\/p\[\1\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'

		if ($Curr=~/\. \w+ /i)
		{
			$Curr=~s/<p\[(\d+)\] class\=\"heading\d+\">/<p\[$1\] class\=\"normal\">/gi;
			#print ERR "$Curr\n\n";
		}


		#$Curr=~s/<div\[(\d+)\] class\=\"footnote\" id\=\"footnote(\d+)\">(.*?)<\/div\[\1\]>//sgi;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	#exit;
	
	
	
	
	$Line=$sctypes;	
	$Variable="";	
	while($Line =~/<sec type\=\"([^\"]+)\">(.*?)<\/sec>/sg)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		my $sctype="$1";
		my $sctext="$2";
		
		
		
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((<b>)(\d+\.? )?$sctext\:?\.? ?(<\/b>)\.? ?)<\/p\[(\1)\]>/<h1 class\=\"heading1\" data\-type\=\"$sctype\">$3<\/h1>/gi;
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((<i>)(\d+\.? )?$sctext\:?\.? ?(<\/i>)\.? ?)<\/p\[(\1)\]>/<h1 class\=\"heading1\" data\-type\=\"$sctype\">$3<\/h1>/gi;
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((\d+\.? )?$sctext\:?\.? ?)<\/p\[(\1)\]>/<h1 class\=\"heading1\"  data\-type\=\"$sctype\">$3<\/h1>/gi;
		$_=~s/<p\[(\d+)\] class\=\"([^\"]+)\">((?:<(?:b|i)>)?(\d+\.? )?$sctext\:?\.? ?)(.*?)<\/p\[(\1)\]>/<h1 class\=\"heading1\" data\-type\=\"$sctype\">$3$5<\/h1>/gi;
		$_=~s/<\/h1>\s*<h1 class\=\"heading1\" data\-type\=\"([^\"]+)\">(.*?)<\/h1>/<\/h1>\n<h2 class\=\"heading2\">$2<\/h2>/sg;
		
	$_=~s/(<div\[\d+\] class=\"front\">\s*)<(h[1-6])\b[^<>]*>((?:(?!<\/\2>).)*?)<\/\2>/$1<p\[0218\] class\=\"normal\">$3<\/p\[0218\]>/sgi;	
		
			
	#$Variable .=$PreMatch .$Curr;	
	}	
	#$Variable .=$Line;	
	#$_ = $Variable;

	#Need to move below lines after abstract identify, for retain headings in abstract
	# $Line=$_;
	# $Variable="";	
	# while($Line =~/<div\[(\d+)\] class\=\"front\">(.*?)<\/div\[\1\]>/sgi)	
	# {	
		# $PreMatch = $`;
		# $Curr = $&;
		# $Line = $';
		# #'



		# $Curr=~s/<h1 class\=\"heading1\" data\-type\=\"[^\"]+\">(.*?)<\/h1>/<p\[000\] class\=\"normal\">$1<\/p\[000\]>/gi;
		# $Curr=~s/<h2 class\=\"heading2\">(.*?)<\/h2>/<p\[000\] class\=\"normal\">$1<\/p\[000\]>/gi;
		# #print ERR $Curr;
		
			
	# $Variable .=$PreMatch .$Curr;	
	# }	
	# $Variable .=$Line;	
	# $_ = $Variable;

	
	#exit;

		
	if($_=~/<div\[(\d+)\] class\=\"bodymatter\">(.*?)<\/div\[\1\]>/s)
	{
		my $articlebody="$2";
		#print ERR "$articlebody\n\n";
		
		$Line=$articlebody;	
		$Variable="";	
		while($Line =~/<xdiv class="(Statement|Proposition|Property|Proof|Notation|Proof_Theorem|Assumption|Question|Condition|Claim|Problem|Lemma|Theorem|Hypothesis|Example|Remarks?|facts?|Definition|Note|Algorithm|Constraint|Corollary)">((?:(?!<\/xdiv>).)*?)<\/xdiv>/sgi)
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			
			$Curr=~s/<(\/)?(p\[\d+\])/<$1X$2/sgi;

			
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;
		$articlebody = $Variable;
		
		
		my $unwantedparabody="";
		
		
		$Line=$articlebody;	
		$Variable="";	
		while($Line =~/<p\[(\d+)\] class\=\"([^\"]+)\">(.*?)<\/p\[\1\]>/sg)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			$Curr=~s/<p\[(\d+)\] class\=\"normal\">(\&\#x0003C\;\&\#x0003C\;Insert Figure (\d+) about here\&\#x0003E\;\&\#x0003E\;|\&\#x0003C\;\&\#x0003C\;Insert Table (\d+) about here\&\#x0003E\;\&\#x0003E\;|\&\#x0003C\;\&\#x0003C\;Insert Figure \d+ about here\&\#x0003E\;\&\#x0003E\;|\[<i>Figure (\d+) here<\/i>]|\[<i>Table \d+ here<\/i>\])<\/p\[\1\]>//gi;
			#print ERR "$Curr\n";
			#exit;
			$Curr=~s/<p\[(\d+)\] class\=\"ref\-para\">/<p\[$1\] class\=\"normal\">/gi;
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<b>(LETTER)<\/b><\/p\[\1\]>/<h1 class\=\"heading1\"><b>$3<\/b><\/h1>/sg;

			# $Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<i>\s*((\d+)\.(\d+) (.*?))<\/i><\/p\[\1\]>/<h2 class\=\"heading2\"><i>$3<\/i><\/h2>/sg;

			# $Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<i>\s*((\d+)\.(\d+)\.(\d+) (.*?))<\/i><\/p\[\1\]>/<h3 class\=\"heading3\"><i>$3<\/i><\/h3>/sg;

			# $Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<b>\s*((\d+)\.(\d+) (.*?))<\/b><\/p\[\1\]>/<h2 class\=\"heading2\"><b>$3<\/b><\/h2>/sg;

			# $Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<b>\s*((\d+)\.(\d+)\.(\d+) (.*?))<\/b><\/p\[\1\]>/<h3 class\=\"heading3\"><i>$3<\/i><\/h3>/sg;

			#sec sup bold fix, Dont update on live
			$Curr=~s/<\/b>(<((?:sub|sup)\[\d+\]) class="dummy">)<b>(.*?)<\/b>(<\/\2>)<b>/$1$3$4/sgi;

			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<i>\s*((\d+)\.\s*(\d+) (.*?))<\/i><\/p\[\1\]>/<h2 class\=\"heading2\"><span class\=\"sec-label\">$4\.$5<\/span> <i>$6<\/i><\/h2>/sg;
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<i>\s*((\d+)\.\s*(\d+)\.\s*(\d+) (.*?))<\/i><\/p\[\1\]>/<h3 class\=\"heading3\"><span class\=\"sec-label\">$4\.$5\.$6<\/span> <i>$7<\/i><\/h3>/sg;

			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<i>\s*((\d+)\.\s*(\d+)\.\s*(\d+) (.*?))<\/i><\/p\[\1\]>/<h3 class\=\"heading3\"><span class\=\"sec-label\">$4\.$5\.$6<\/span> <i>$7<\/i><\/h3>/sg;
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<b>\s*((\d+)\.\s*(\d+) (.*?))<\/b><\/p\[\1\]>/<h2 class\=\"heading2\"><span class\=\"sec-label\">$4\.$5<\/span> <b>$6<\/b><\/h2>/sg;
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<b>\s*((\d+)\.\s*(\d+)\.\s*(\d+) (.*?))<\/b><\/p\[\1\]>/<h3 class\=\"heading3\"><span class\=\"sec-label\">$4\.$5\.$6<\/span> <i>$7<\/i><\/h3>/sg;

			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*((\d+)\.\s*(\d+)\.\s*(\d+)\.\s*(\d+)\. (.*?))<\/p\[\1\]>/<h4 class\=\"heading4\"><span class\=\"sec-label\">$4\.$5\.$6\.$7<\/span> $8<\/h4>/sg;
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*((\d+)\.\s*(\d+)\.\s*(\d+)\. (.*?))<\/p\[\1\]>/<h3 class\=\"heading3\"><span class\=\"sec-label\">$4\.$5\.$6<\/span> $7<\/h3>/sg;
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*((\d+)\.\s*(\d+)\. (.*?))<\/p\[\1\]>/<h2 class\=\"heading2\"><span class\=\"sec-label\">$4\.$5<\/span> $6<\/h2>/sg;

			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*((\d+)\.\s*(\d+)\.\s*(\d+)\.\s*(\d+) (.*?))<\/p\[\1\]>/<h4 class\=\"heading4\"><span class\=\"sec-label\">$4\.$5\.$6\.$7<\/span> $8<\/h4>/sg;
	
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*((\d+)\.\s*(\d+)\.\s*(\d+) (.*?))<\/p\[\1\]>/<h3 class\=\"heading3\"><span class\=\"sec-label\">$4\.$5\.$6<\/span> $7<\/h3>/sg;
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*((\d+)\.\s*(\d+) (.*?))<\/p\[\1\]>/<h2 class\=\"heading2\"><span class\=\"sec-label\">$4\.$5<\/span> $6<\/h2>/sg;
			



			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<b><i>\s*((\d+)\.(\d+) (.*?))<\/i><\/b><\/p\[\1\]>/<h2 class\=\"heading2\"><b><i>$3<\/i><\/b><\/h2>/sg;

			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<b><i>\s*((\d+)\.(\d+)\.(\d+) (.*?))<\/i><\/b><\/p\[\1\]>/<h3 class\=\"heading3\"><b><i>$3<\/i><\/b><\/h3>/sg;

			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<b><i>\s*((\d+)\.(\d+)\.(\d+)\. (.*?))<\/i><\/b><\/p\[\1\]>/<h3 class\=\"heading3\"><b><i>$3<\/i><\/b><\/h3>/sg;



			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<b><i>\s*((\d+)\.(\d+) (.*?))<\/i><\/b><\/p\[\1\]>/<h2 class\=\"heading2\"><b><i>$3<\/i><\/b><\/h2>/sg;

			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<b><i>\s*((\d+)\.(\d+)\.(\d+) (.*?))<\/i><\/b><\/p\[\1\]>/<h3 class\=\"heading3\"><b><i>$3<\/i><\/b><\/h3>/sg;

			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<b><i>\s*((\d+)\.(\d+)\.(\d+)\.(\d+) (.*?))<\/i><\/b><\/p\[\1\]>/<h4 class\=\"heading4\"><b><i>$3<\/i><\/b><\/h4>/sg;
			
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<i>\s*(\d+)\.(\d+)\. (.*?)<\/i>\s*<\/p\[\1\]>/<h2 class\=\"heading2\"><i>$3\.$4\. $5<\/i><\/h2>/gi;
			
			#print ERR "$Curr\n";



			
			if($Curr!~/(\.|<p\[(\d+)\] class\=\"([^\"]+)\">(<b>)?(Figure Captions|Table Captions)(<\/b>)?|<p\[(\d+)\] class\=\"([^\"]+)\"><m\:|\:<\/p\[\d+\]>| class\=\"heading)/i)
			{
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b>(.*?)<\/b><\/p\[\1\]>/<h2 class\=\"heading2\"><b>$3<\/b><\/h2>/sg;
				
				if($Curr=~/<h2 class\=\"heading2\"><b>/i)
				{
					$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><i>(.*?)<\/i><\/p\[\1\]>/<h3 class\=\"heading3\"><i>$3<\/i><\/h3>/sg;
				}
				
				#print ERR "$Curr\n\n";
			}
			
			
			$Curr=~s/<h2 class\=\"heading2\">\s*(<b>\s*(\d+) ([A-z])(.*?)<\/b>)<\/h2>/<h1 class\=\"heading1\">$1<\/h1>/gi;
			$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\">\s*<b>\s*((\d+)\.(\d+)\. (.*?))<\/b> ?<\/p\[\1\]>/<h2 class\=\"heading2\"><b>$3<\/b><\/h2>/sg;
			$Curr=~s/<p\[(\d+)\] class\=\"normal\">((\d+)\.(\d+)\. ([A-Za-z])(.*?))<\/p\[\1\]>/<h2 class\=\"heading2\">$2<\/h2>/sgi;
			$Curr=~s/<p\[(\d+)\] class\=\"normal\"><i>((\d+)\.(\d+)\.(\d+)\. ([A-Za-z])(.*?))<\/p\[\1\]>/<h3 class\=\"heading3\"><i>$2<\/h3>/sgi;
			
			
			
			#print ERR "sss$Curr\n";
			
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$articlebody = $Variable;


		#print ERR "$articlebody\n";

		$Line=$articlebody;	
		$Variable="";	
		while($Line =~/<p\[(\d+)\] class\=\"([^\"]+)\">(.*?)<\/p\[\1\]>/sg)	
		{	
			$PreMatch = $`;
			$Curr = $&;
			$Line = $';
			#'
			
			my $paracontent="$2";
			
			my $wordcounter=0;
			while($Curr=~/ /g){$wordcounter++;}	
			if ($wordcounter <= 15 && $Curr!~/class\=\"(?:entitle|enlabel)\"/i && $jornalconfig!~/<FILE type="Tex"\/>/si)
			{
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><i>(.*?)<\/i><\/p\[\1\]>/<h2 class\=\"heading2\"><i>$3<\/i><\/h2>/sg;
				$Curr=~s/<p\[(\d+)\] class\=\"([^\"]+)\"><b>(.*?)<\/b><\/p\[\1\]>/<h1 class\=\"heading1\"><b>$3<\/b><\/h1>/sg;
				#print ERR "$Curr\n";
			}
			
			
			#print "$wordcounter\n";
			


			
			
				
		$Variable .=$PreMatch .$Curr;	
		}	
		$Variable .=$Line;	
		$articlebody = $Variable;

		$articlebody=~s/<(\/)?X(p\[\d+\])/<$1$2/sgi;
		#exit;
		
		$articlebody=~s/<h1 class\=\"heading1\"\s*data\-type\=\"([^\"]+)\">(.*?)<\/h1>\s*<h1 class\=\"heading1\"\s*data\-type\=\"([^\"]+)\">(.*?)<\/h1>/<h1 class\=\"heading1\" data\-type\=\"$1\">$2<\/h1>\n<h2 class\=\"heading2\" data\-type\=\"$3\">$4<\/h2>/sgi;
		
		$articlebody=~s/<p\[(\d+)\] class\=\"heading7\">/<p\[$1\] class\=\"heading2\">/gi;
		$articlebody=~s/<p\[(\d+)\] class\=\"heading8\">/<p\[$1\] class\=\"heading3\">/gi;
		$articlebody=~s/<h2 class\=\"heading2\">(.*?)<\/h2>\s*<h2 class\=\"heading2\">(.*?)<\/h2>/<h2 class\=\"heading2\">$1<\/h2>\n<h3 class\=\"heading3\">$2<\/h3>/sgi;
		#$articlebody=~s/<h3 class\=\"heading3\">(.*?)<\/h3>\n<h2 class\=\"heading2\">(.*?)<\/h2>/<h2 class\=\"heading2\">$1<\/h2>\n<h3 class\=\"heading3\">$2<\/h3>/sgi;
		#print ERR "$articlebody";
		#exit;

		
		
		#$_=~s/<h3 class\=\"heading3\">(.*?)<\/h3>/<p class\=\"heading3\">$1<\/p>/g;
		#$_=~s/<h2 class\=\"heading2\">(.*?)<\/h2>/<p class\=\"heading2\">$1<\/p>/g;
		#$_=~s/<h1 class\=\"heading1\" data\-type\=\"([^\"]+)\">(.*?)<\/h1>/<p class\=\"heading1\" data\-type\=\"$1\">$2<\/p>/g;
		
		$_=~s/<div\[(\d+)\] class\=\"bodymatter\">(.*?)<\/div\[\1\]>/<div\[$1\] class\=\"bodymatter\">$articlebody<\/div\[$1\]>/si;
		
		
	}	

	#sec label
	$_=~s/<h(\d+) ([^<>]*)>(\s*<[ib]>)?(\d+\s*\.\s*([\d+]\.)*)/<h$1 $2><span class\=\"sec-label\">$4<\/span>$3/sgi;
	$_=~s/<p(\[\d+\] class\=\"heading\d+"[^<>]*)>(\s*<[ib]>)?(\d+\s*\.([\d+]\.)*)/<p$1><span class\=\"sec-label\">$3<\/span>$2/sgi;
	$_=~s/<p(\[\d+\] class\=\"heading\d+"[^<>]*)>([A-Z]\.\d+)(\.) (\w+)/<p$1><span class\=\"sec-label\">$2$3<\/span> $4/sgi;		

	#app label
	$_=~s/<h(\d+) ([^<>]*)>(\s*<[ib]>)?((?:\d+|[A-Z]|[A-Z](?:\.\d+)+)\.)(\s)/<h$1 $2><span class\=\"sec-label\">$4<\/span>$5$3/sgi;
	
	#print ERR "$sctypes\n\n";
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<h(\d+) class\=\"heading\1\"([^<>]*)>(.*?)<\/h\1>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		

		if ($Curr=~/\. \w+/i)
		{
			$Curr=~s/<h(\d+) class\=\"heading\1\"[^<>]*>(.*?)<\/h\1>/<p\[000\] class\=\"normal\">$2<\/p\[000\]>/gi;
			#print ERR "$Curr\n\n";
		}

		#print ERR "$Curr\n\n";

		#$Curr=~s/<div\[(\d+)\] class\=\"footnote\" id\=\"footnote(\d+)\">(.*?)<\/div\[\1\]>//sgi;
		
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;
	#exit;
	
	
	#print ERR "$_";
	#exit;

	#exit;

}



sub TBL2EQNS
{
	#print ERR "$_";
	#exit;
	
	$Line=$_;	
	$Variable="";	
	while($Line =~/<table>(.*?)<\/table>/s)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		
		
		$Curr=~s/<table>(.*?)<\/colgroup>\s*<tr>\s*<td>(\(?\[?\w+\]?\)?)<\/td>\s*<td><TempMT id\=\"M(\d+)\">\s*<\/td>\s*<\/tr>\s*<\/table>/<p class\=\"DISP\-EQUATION\"><TempMT id\=\"M$3\"><span class\=\"EQLABEL\">$2<\/span><\/p>/sgi;
		
		
		$Curr=~s/<table>\s*<colgroup>\s*<col width\=\"[^\"]+\"\/>\s*<col width\=\"[^\"]+\"\/>\s*<\/colgroup>\s*<tr>\s*<td>(\(?\[?\w+\]?\)?)<\/td>\s*<td><TempMT id\=\"M(\d+)\">(.*?)<\/td>\s*<\/tr>\s*<\/table>/<p class\=\"DISP\-EQUATION\"><TempMT id\=\"M$2\">$3<span class\=\"EQLABEL\">$1<\/span><\/p>/sgi;
		
		
		$Curr=~s/<table>\s*<colgroup>(.*?)<\/colgroup>\s*<tr>\s*<td>\s*<TempMT id\=\"M(\d+)\">\s*<\/td>\s*<td>(\(?\[?\w+\]?\)?)<\/td>\s*<\/tr>\s*<\/table>/<p class\=\"DISP\-EQUATION\"><TempMT id\=\"M$2\"><span class\=\"EQLABEL\">$3<\/span><\/p>/sgi;
		
		$Curr=~s/<table>\s*<colgroup>(.*?)<\/colgroup>\s*<tr>\s*<td>\s*<TempMT id\=\"M(\d+)\">(.*?)<\/td>\s*<td>(\(?\[?\w+\]?\)?)<\/td>\s*<\/tr>\s*<\/table>/<p class\=\"DISP\-EQUATION\"><TempMT id\=\"M$2\">$3<span class\=\"EQLABEL\">$4<\/span><\/p>/sgi;
		
		#print ERR "$Curr\n\n";

		
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;	
	
	#exit;

	
	
}



sub DOUBLETAG
{

	$Line=$_;	
	$Variable="";	
	while($Line =~/<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'

		my $etype="$1";
		my $text="$3";
		
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$Curr=~s/^<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>$/<$1\[$2\] class\=\"dummy\">$text<\/$1\[$2\]>/sgi;


		#print ERR "$Curr\n\n";


	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;	


	$Line=$_;	
	$Variable="";	
	while($Line =~/<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'

		my $etype="$1";
		my $text="$3";
		
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$Curr=~s/^<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>$/<$1\[$2\] class\=\"dummy\">$text<\/$1\[$2\]>/sgi;


		#print ERR "$Curr\n\n";


	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;	


	$Line=$_;	
	$Variable="";	
	while($Line =~/<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>/sgi)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'

		my $etype="$1";
		my $text="$3";
		
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$text=~s/<$etype\[(\d+)\] class\=\"dummy\">(.*?)<\/$etype\[\1\]>/$2/sgi;
		$Curr=~s/^<(\w+)\[(\d+)\] class\=\"dummy\">(.*?)<\/\1\[\2\]>$/<$1\[$2\] class\=\"dummy\">$text<\/$1\[$2\]>/sgi;


		#print ERR "$Curr\n\n";


	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$_ = $Variable;		
	
	$_=~s/<(b|i)\[(\d+)\] class\=\"dummy\">/<$1>/g;
	$_=~s/<\/(b|i)\[(\d+)\]>/<\/$1>/g;
	
}




sub MERGEDWORDS
{
	#$_=~s///g;
	
	
	my $temptext="$_";


	
	
	
	my $Mwords="";
	
	while($temptext=~/(([A-z]+)<i>([A-z]+))/sg)
	{
		$Mwords .="<input class\=\"RPSMERGED\" type\=\"checkbox\" name\=\"check\" value\=\"$1<\/i>\" title\=\"$2 <i>$3<\/i>\">$1<\/i><\/input><br\/>\n";
		#$Mwords .="<span class\=\"RPSMERGED\" title\=\"Possible Merged Word\" data\-sugg\=\"$2 <i>$3<\/i>\">$1<\/i><\/span>\n";
	}
	
	
	$temptext=~s/<!--(.*?)-->//sg;
	
	$Line=$temptext;	
	$Variable="";	
	while($Line =~/<(\/)?([^<]+)>/g)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		
		$Curr=~s/<(\/)?([^<]+)>//g;

				
			
	$Variable .=$PreMatch .$Curr;	
	}	
	$Variable .=$Line;	
	$temptext = $Variable;
	
	
	while($temptext=~/(([A-z]+)(et al\.))/sg)
	{
		my $pword="$1";
		
		$pword =~s/^x(\d+)$//gi;
		
		$Mwords .="<input class\=\"RPSMERGED\" type\=\"checkbox\" name\=\"check\" value\=\"$pword\" title\=\"$2 $3\">$pword<\/input><br\/>\n";
		#$Mwords .="<span class\=\"RPSMERGED\" title\=\"Possible Merged Word\" data\-sugg\=\"$2 $3\">$pword<\/span>\n";
	}
	
	while($temptext=~/(([A-Z]+)([A-Z])([a-z]+))/sg)
	{
		my $pword="$1";
		
		$pword =~s/^x(\d+)$//gi;
		if ($ww > 3)
		{
			$Mwords .="<input class\=\"RPSMERGED\" type\=\"checkbox\" name\=\"check\" value\=\"$pword\" title\=\"$2 $3$4\">$pword<\/input><br\/>\n";
			#$Mwords .="<span class\=\"RPSMERGED\" title\=\"Possible Merged Word\" data\-sugg\=\"$2 $3$4\">$pword<\/span>\n";
		}
	}
	
	while($temptext=~/( ([a-z]+)([A-Z])([a-z]+) )/sg)
	{
		my $pword="$1";
		
		$pword =~s/^x(\d+)$//gi;
		if ($ww > 3)
		{
			$Mwords .="<input class\=\"RPSMERGED\" type\=\"checkbox\" name\=\"check\" value\=\"$pword\" title\=\" $2 $3$4 \">$pword<\/input><br\/>\n";
			#$Mwords .="<span class\=\"RPSMERGED\" title\=\"Possible Merged Word\" data\-sugg\=\" $2 $3$4 \">$pword<\/span>\n";
		}
	}
	
	while($temptext=~/(([A-Z])([a-z]+)([A-Z])([a-z]+))/sg)
	{
		my $pword="$1";
		
		$pword =~s/^x(\d+)$//gi;
		my $ww=length($pword);
		if ($ww > 3)
		{
			$Mwords .="<input class\=\"RPSMERGED\" type\=\"checkbox\" name\=\"check\" value\=\"$pword\" title\=\"$2$3 $4$5\">$pword<\/input><br\/>\n";
			#$Mwords .="<span class\=\"RPSMERGED\" title\=\"Possible Merged Word\" data\-sugg\=\"$2$3 $4$5\">$pword<\/span>\n";
		}
	}
	
	while($temptext=~/(([A-Z])([a-z]+)([0-9]+))/sg)
	{
		my $pword="$1";
		
		$pword =~s/^x(\d+)$//gi;
		my $ww=length($pword);
		if ($ww > 3)
		{
			$Mwords .="<input class\=\"RPSMERGED\" type\=\"checkbox\" name\=\"check\" value\=\"$pword\" title\=\"$2$3 $4\">$pword<\/input><br\/>\n";
			#$Mwords .="<span class\=\"RPSMERGED\" title\=\"Possible Merged Word\" data\-sugg\=\"$2$3 $4\">$pword<\/span>\n";
		}
	}
	
	while($temptext=~/(([a-z]+)([0-9]+))/sg)
	{
		my $pword="$1";
		
		$pword =~s/^x(\d+)$//gi;
		my $ww=length($pword);
		if ($ww > 3)
		{
			$Mwords .="<input class\=\"RPSMERGED\" type\=\"checkbox\" name\=\"check\" value\=\"$pword\" title\=\"$2 $3\">$pword<\/input><br\/>\n";
			#$Mwords .="<span class\=\"RPSMERGED\" title\=\"Possible Merged Word\" data\-sugg\=\"$2 $3\">$pword<\/span>\n";
		}
	}
	

	while($temptext=~/(^(?!\&\w+)\;([A-z]+))/sg)
	{
		my $pword="$1";
		
		$pword =~s/^x(\d+)$//gi;
		my $ww=length($pword);
		if ($ww > 3)
		{
			$Mwords .="<input class\=\"RPSMERGED\" type\=\"checkbox\" name\=\"check\" value\=\"$pword\" title\=\"\; $2\">$pword<\/input><br\/>\n";
			#$Mwords .="<span class\=\"RPSMERGED\" title\=\"Possible Merged Word\" data\-sugg\=\"\; $2\">$pword<\/span>\n";
		}
	}
	
	while($temptext=~/( (\,|\;|\.))/sg)
	{
		my $pers="$1";
		my $pers11="$1";
		my $pers1="$2";
		
		$pers=~s/ /<span style\=\"background\-color\:red\;display\:inline\;\">\&nbsp\;<\/span>/g;
		
		$Mwords .="<input class\=\"RPSMERGED\" type\=\"checkbox\" name\=\"check\" value\=\"$pers11\" title\=\"$pers1\">$pers<\/input><br\/>\n";
		#$Mwords .="<span class\=\"RPSMERGED\" title\=\"Punctuation Errors\" data\-sugg\=\"$pers1\">$pers<\/span>\n";
	}	
	
	my $fecounter=0;
	
	while($Mwords=~/<input class\=\"RPSMERGED/sg)
	{
		$fecounter++;
	}	
	

	#$Mwords=~s/^/<span class="RPSFECOUNT">$fecounter<\/span>\n/i;

	if($fecounter ne 0)
	{
		#print "Content Validation Error\: $fecounter\n";
	}	
	#print "$fecounter";
	#exit;

	# 
	
	my $divtext='<div class="col-md-4 col-sm-4">
<div class="media">
<div class="media-object media-left wow fadeIn" data-wow-delay="0.8s">
<i class="fa fa-exclamation" style="width:45px;"></i>
</div>
<div class="media-body wow fadeIn" data-wow-delay="0.6s">
<h3 class="media-heading" style="font-size:17px">Content Check</h3>
<div class="DIVSCROLL">
<RPTFERRORS/>
</div>
</div>
</div>
</div>';
	
	$divtext=~s/<RPTFERRORS\/>/$Mwords/i;
	

	open(XMLCONTENT, ">:encoding(UTF-8)", "$outfpath1-FERRORS\.html")|| die print("Can't open input file!!!");
	print XMLCONTENT "$divtext";
	close(XMLCONTENT);	
	
	#print ERR "$Mwords";
	#exit;

}


sub MOVE_OUT_QUERY
{
	my $temp = shift;
	my %ref_hash;
	if($temp == 1)
	{
		if($_=~/<div\[(\d+)\] class="references">(.*?)<\/div\[\1\]>/si)
		{
			my $ref_cnt = $2;
			if($ref_cnt=~/<span\[(\d+)\] class="QUERY">/si)
			{
				my $count = 1;
				
				$Line=$ref_cnt;	
				$Variable="";	
				#while($Line =~/<p\[(\d+)\] class=\"ref[^\"]+\">(.*?)<\/p\[\1\]>/sgi)	
				while($Line =~/<p\[(\d+)\] class=\"[^\"]+\">(.*?)<\/p\[\1\]>/sgi)	
				{	
					$PreMatch = $`;
					$Curr = $&;
					$Line = $';
				
					if($Line=~/^(\s*(?:<span\[(\d+)\] class="QUERY">.*?<\/span\[\2\]>\s*)+)/si)
					{
						$ref_hash{$count} = $1;
						$Line=~s/^(\s*(?:<span\[(\d+)\] class="QUERY">.*?<\/span\[\2\]>\s*)+)//si;
					}
					$count++;
				
				$Variable .=$PreMatch .$Curr;	
				}	
				$Variable .=$Line;	
				$ref_cnt = $Variable;	
				
				$ref_cnt=~s/(<\/p\[\d+\]>)\n\s*(<p\b)/$1\n$2/sgi;
				$ref_cnt=~s/(<\/p\[\d+\]>)\s*(<p\b)/$1\n$2/sgi;
				$ref_cnt=~s/><p/>\n<p/si;
		#print $ref_cnt;
				$_=~s/<div\[(\d+)\] class="references">(.*?)<\/div\[\1\]>/<div\[$1\] class="references">$ref_cnt<\/div\[$1\]>/si;
			}
		}

		return %ref_hash;
	}
	else
	{
		$_ =~s/((?:\s*<span\[(\d+)\] class\=\"QUERY\">.*?<\/span\[\2\]>\s*)+)(<\/p\[\d+\]>)/$3$1/sgi;
	}
}


sub ELEMENTNUMBERING
{
	
	
	open(ELIST, "<", "$serverpath/elements\.txt") or die print("$serverpath/elements\.txt NOT FOUND!!!");
	my $elements = <ELIST>;
	close (ELIST);

	$_=~s/\&\#x0?2103\;/\&\#x00B0\;C/g;
	$_=~s/<\/i>\.<i>/\./g;
	$_=~s/<(span|strong|sup|sub|sc|monospace)>/<$1 class\=\"dummy\">/g;
	
	#print "$elements\n";
	
	#print ERR "$_";
	#exit;
	
	$Line=$elements;	
	$Variable="";	
	while($Line =~/(\w+)/g)	
	{	
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		my $e2="$1";
		
		#print "$Curr\n";
		my $strongcount = 0;
		strongStart:
		$_ =~ s{<$e2\s+([^<>]*>((?:(?!<$e2\s+\b).)*?))<\/$e2>}
				{
					my $strong = $&;
					#print "$strong\n\n";
					$strongcount++;
					$strong =~ s/<$e2\s+([^<>]*>((?:(?!<$e2\s+\b).)*?))<\/$e2>/<$e2\[$strongcount\] $1<\/$e2\[$strongcount\]>/msi;
					$strong;
				}emsgi;
		goto strongStart if($_ =~ m/<$e2\s+/msi);		
				
		
			
	#$Variable .=$PreMatch .$Curr;	
	}	
	#$Variable .=$Line;	
	#$_ = $Variable;


	
		while($_=~/<span\[(\d+)\] class\=\"dummy\">(.*?)<\/span\[\1\]>/sgi)
		{
			$_=~s/<span\[(\d+)\] class\=\"dummy\">(.*?)<\/span\[\1\]>/$2/sgi;	
		}	

	if ($functiontype ne "14" && $functiontype ne "41")
	{
		if ($functiontype ne "44" && $functiontype ne "201")
		{
			REMOVEMATHTAG();
		}
	}
}


sub INSERTMATHTAG
{

	$_=~s/<head>(.*?)<\/head>/<head>$headcss<\/head>/sgi;
	#print "Yes\n";
	#print ERR "$_";
	#exit;
	
	
	while (my ($key,$val) = each %math_remov_ins )
	{
		$_=~s/\Q$key\E/$val/s;
	}


}




sub REMOVEMATHTAG
{
	
	$Line=$_;
	$Variable="";
	while($Line =~/<head>(.*?)<\/head>/sgi)
	{
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		
		$headcss ="$1\n";
		
		$Curr=~s/<head>(.*?)<\/head>/<head><\/head>/sgi;
		#print ERR "$Curr\n";
		
				
	$Variable .=$PreMatch .$Curr;
	}
	$Variable .=$Line;
	$_ = $Variable;	
		
	
	undef %math_remov_ins;
	
	if($_ =~/<(p|span)\[(\d+)\] ([^<>]*)class\=\"(DISP\-EQUATION|inline)\"([^<>]*)>/si)
	{
		my $i = 1;
		while($_ =~/<(p|span)\[(\d+)\] ([^<>]*)class\=\"(DISP\-EQUATION|inline)\"([^<>]*)>(.*?)<\/\1\[\2\]>/sgi)
		{	
			$math_remov_ins{"<TempMT id\=\"M$i\">"} = $&;
			# push(@mathconten, $&);
			# push(@tempmt, "<TempMT id\=\"M$i\">");
			$i++;
		}
		# my $j = 1;
		# my $k = 0;
		# while(scalar @mathconten >= $j)
		# {
			# $_=~s/\Q$mathconten[$k]\E/$tempmt[$k]/s;
			# $j++;
			# $k++;
		# }
		while (my ($key,$val) = each %math_remov_ins )
		{
			$_=~s/\Q$val\E/$key/s;
		}
	}
	

}



sub NAMED2ENTITY
{
	
	
	$_=~s/\'/\&apos\;/g;
	
	
	
	$Line=$entities;
	$Variable="";
	while($Line =~/<entity><named>(.*?)<\/named><hex>(.*?)<\/hex><tex>(.*?)<\/tex><\/entity>/g)
	{
		$PreMatch = $`;
		$Curr = $&;
		$Line = $';
		#'
		my $find="$1";
		my $replace="$2";
		my $tex="$3";
		
		
		#print "$find\n\n";
		while($_=~/(\Q$find\E)/)
		{
			#print "$find\n\n";
			$_=~s/\Q$find\E/$replace/g;
		}
		
		
				
	#$Variable .=$PreMatch .$Curr;
	}
	#$Variable .=$Line;
	#$_ = $Variable;
	
	$_=~s/>\&\#x000A0\;<\//><\//g;

}



sub CHAR2ENTITY
{
	while($_ =~ m/[\x{A0}-\x{FFDC}]/g)
	{
		my $findchar = $&;
		my $ent = uc(sprintf("%x", ord($findchar)));

		if(defined $ent)
		{
			if(length($ent) == 1)
			{
				$ent = "&#x0000$ent;";
			}
			elsif(length($ent) == 2)
			{
				$ent = "&#x000$ent;";
			}
			elsif(length($ent) == 3)
			{
				$ent = "&#x00$ent;";
			}
			elsif(length($ent) == 4)
			{
				$ent = "&#x0$ent;";
			}
			$_ =~ s/$findchar/$ent/g;
		}
		else
		{
			$_ =~ s/$findchar/<SRN\/>/;
		}
	}
	#print "yes\n" while($_ =~ m/\x{0089}/gi);

	$_ =~ s/<NOTCONVERTED>([\&\#\w\;]+)<\/NOTCONVERTED>/$1/gi;

	$_ =~ s{<NOTCONVERTED>\\x(\w+)<\/NOTCONVERTED>}
	{
		my $NTent = "&#x0000" . $1;
		$NTent =~ s/^\&\#x0+([a-z0-9]{4})$/<NOTCONVERTED>\&\#x$1\;<\/NOTCONVERTED>/gi;
		$NTent;
	}iseg;

	$_ =~ s{<NOTCONVERTED>((\\x|\w)+)<\/NOTCONVERTED>}
	{
		my $test = $1;
		my @NTent = map {$_ =~ s/\\x(\w+)/\&\#x0000$1/i;$_ =~ s/^\&\#x0+([a-z0-9]{4})$/<NOTCONVERTED>\&\#x$1\;<\/NOTCONVERTED>/gi; $_} split(/(\\x\w+)/i, $test);
		my $finjoin = join "", @NTent;
		$finjoin;
	}iseg;


	$_ =~ s{<NOTCONVERTED>(&[\#\w]+;| )+<\/NOTCONVERTED>}
		{
			my $notconv = $&;
			$notconv =~ s/<\/?NOTCONVERTED>//gi;
			$notconv;
		}gie;

	$_ =~ s{<NOTCONVERTED>([^<>]+)<\/NOTCONVERTED>}
	{
		my $notc = $1;
		$notc =~ s{.}
			{
				my $findchar = $&;
				my $ent = uc(sprintf("%x", ord($findchar)));
				#print "$ent\n";
				if(defined $ent)
				{
					if(length($ent) == 1)
					{
						$ent = "&#x0000$ent;";
					}
					elsif(length($ent) == 2)
					{
						$ent = "&#x000$ent;";
					}
					elsif(length($ent) == 3)
					{
						$ent = "&#x00$ent;";
					}
					elsif(length($ent) == 4)
					{
						$ent = "&#x0$ent;";
					}
				}
				$ent;
			}eg;
		$notc;
	}iseg;
	

}



sub GeneralCleanup
{
	
	$_=~s/(<p( class\=\"normal\")?>)\s*<br>\s*<\/br>/$1/gi;
	$_=~s/(<p( class\=\"normal\")?>)\s*<br\/>/$1/gi;
	$_=~s/<\/p>\s*<p class\=\"normal\">\.<\/p>/\.<\/p>\n/sgi;
	
	$_=~s/<b><b>(.*?)<\/b><\/b>/<b>$1<\/b>/gi;
	$_=~s/\&\#x02010\;/\-/gi;
	$_=~s/\&\#x0026\;/\&amp\;/g;
	$_=~s/<i>\&\#x000A0\;<\/i>/ /g;
	$_=~s/<b>\&\#x000A0\;<\/b>/ /g;
	$_=~s/<u>//sgi;
	$_=~s/<\/u>//sgi;
	$_=~s/<u>(.*?)<\/u>/$1/g;
	$_=~s/<\/b><b>//g;
	$_=~s/<\/b> <b>/ /g;
	$_=~s/<\/i><i>//g;
	$_=~s/<\/i> <i>/ /g;
	$_=~s/\&\#x000B9\;/<sup>1<\/sup>/gi;
	$_=~s/\&\#x000B2\;/<sup>2<\/sup>/gi;
	$_=~s/ \,/\,/gi;
	#$_=~s/\, ?/\, /gi;
	$_=~s/<i>\-<\/i>/\-/gi;
	####SHORTTAGS CLEANUP
	$_=~s/<b>Abstract<\/b><\/p>\s*<p class\=\"normal\">Introduction/<b>Abstract<\/b><\/p>\n<p class\=\"normal\">DUMMYINTEGRAduction/sgi;
	$_=~s/<b>Abstract<\/b><\/p>\s*<p class\=\"normal\"><b>Introduction/<b>Abstract<\/b><\/p>\n<p class\=\"normal\"><b>DUMMYINTEGRAduction/sgi;
	$_=~s/<p class\=\"normal\"><b>Key words\:<\/b>/<p class\=\"normal\">Keywords\:/gi;
	#print ERR "$_\n";
	#exit;


	
	$_=~s/<b>Introduction<\/b><\/b><\/p>/Introduction<\/b><\/p>/gi;
	
	$_=~s/<p class\=\"([^\"]+)\"><b>Acknowledgment statement<\/b><\/p>/<p class\=\"$1\"><b>Acknowledgements<\/b><\/p>/gi;
	#print ERR "$_";
	#exit;
	$_=~s/<p class\=\"([^\"]+)\"><b>Acknowledgement<\/b>s/<p class\=\"$1\"><b>Acknowledgements<\/b>/gi;
	$_=~s/<p class\=\"heading2\">ACKNOWLEDGMENTS<\/p>/<p class\=\"heading1\">ACKNOWLEDGMENTS<\/p>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b>\[ ?<i>H(\d+)\]/<p class\=\"$1\"><b><i>\[H$2\]/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b>\[(Title|Authors)\]/<p class\=\"$1\"><b>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><i>\[(Title|Authors)\]/<p class\=\"$1\"><b><i>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b>\[H1\]<\/b><\/p>(<mergepara\/>)?//sgi;
	$_=~s/<p class\=\"([^\"]+)\">\[H1\]<\/p>(<mergepara\/>)?//sgi;
	
	$_=~s/<p class\=\"([^\"]+)\"><b><b><i>\[H2\] ?(Objective|Methods|Results|Conclusion)/<p class\=\"$1\"><b><b><i>$2/sgi;
	$_=~s/<p class\=\"([^\"]+)\"><b><i>\[H2\] ?(Objective|Methods|Results|Conclusion)/<p class\=\"$1\"><b><i>$2/sgi;
	$_=~s/<p class\=\"([^\"]+)\"><b>\[H2\] ?(Objective|Methods|Results|Conclusion)/<p class\=\"$1\"><b>$2/sgi;
	$_=~s/<p class\=\"([^\"]+)\">\[H2\] ?(Objective|Methods|Results|Conclusion)/<p class\=\"$1\">$2/sgi;

	$_=~s/<p class\=\"([^\"]+)\"><b><b><i>\[H1\] ?(keywords)/<p class\=\"$1\"><b><b><i>$2/sgi;
	$_=~s/<p class\=\"([^\"]+)\"><b><i>\[H1\] ?(keywords)/<p class\=\"$1\"><b><i>$2/sgi;
	$_=~s/<p class\=\"([^\"]+)\"><b>\[H1\] ?(keywords)/<p class\=\"$1\"><b>$2/sgi;
	$_=~s/<p class\=\"([^\"]+)\">\[H1\] ?(keywords)/<p class\=\"$1\">$2/sgi;
	
	$_=~s/<p class\=\"([^\"]+)\"><b>\[H1\] ?<b>I<\/b>ntroduction<\/b><\/p>/<p class\=\"$1\">Introduction<\/p>/sgi;
	
	
	$_=~s/<p class\=\"([^\"]+)\"><b>\[H1\] ?/<p class\=\"heading1\"><b>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><b><i>\[H1\] ?/<p class\=\"heading1\"><b><b><i>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><i>\[H1\] ?/<p class\=\"heading1\"><b><i>/gi;
	$_=~s/<p class\=\"([^\"]+)\">\[H1\] ?/<p class\=\"heading1\">/gi;


	$_=~s/<p class\=\"([^\"]+)\"><b>\[H2\] ?/<p class\=\"heading2\"><b>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><b><i>\[H2\] ?/<p class\=\"heading2\"><b><b><i>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><i>\[H2\] ?/<p class\=\"heading2\"><b><i>/gi;
	$_=~s/<p class\=\"([^\"]+)\">\[H2\] ?/<p class\=\"heading2\">/gi;


	$_=~s/<p class\=\"([^\"]+)\"><b>\[H3\] ?/<p class\=\"heading3\"><b>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><b><i>\[H3\]/ ?<p class\=\"heading3\"><b><b><i>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><i>\[H3\] ?/<p class\=\"heading3\"><b><i>/gi;
	$_=~s/<p class\=\"([^\"]+)\">\[H3\] ?/<p class\=\"heading3\">/gi;

	$_=~s/<p class\=\"([^\"]+)\"><b>\[H4\] ?/<p class\=\"heading4\"><b>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><b><i>\[H4\] ?/<p class\=\"heading4\"><b><b><i>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><i>\[H4\] ?/<p class\=\"heading4\"><b><i>/gi;
	$_=~s/<p class\=\"([^\"]+)\">\[H4\] ?/<p class\=\"heading4\">/gi;


	$_=~s/<p class\=\"([^\"]+)\"><b>\[H5\] ?/<p class\=\"heading5\"><b>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><b><i>\[H5\] ?/<p class\=\"heading5\"><b><b><i>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><i>\[H5\] ?/<p class\=\"heading5\"><b><i>/gi;
	$_=~s/<p class\=\"([^\"]+)\">\[H5\] ?/<p class\=\"heading5\">/gi;

	$_=~s/<p class\=\"([^\"]+)\"><b>(references)/<p class\=\"normal\"><b>$2/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><b>(references)/<p class\=\"normal\"><b><b>$2/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><i>(references)/<p class\=\"normal\"><b><i>$2/gi;
	$_=~s/<p class\=\"([^\"]+)\">(references)/<p class\=\"normal\">$2/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><b>References<\/b><\/b><\/p>/<p class\=\"$1\">References<\/p>/sgi;

	

	####/SHORTTAGS CLEANUP	
	
	$_=~s/<p class\=\"([^\"]+)\">\s*/<p class\=\"$1\">/gi;
	
	$_=~s/<p class\=\"([^\"]+)\">(Cited Literature|Literature Cited|FULL REFERENCES|Research Proposal References)<\/p>/<p class\=\"$1\">REFERENCES<\/p>/gi;
	$_=~s/<p class\=\"([^\"]+)\"> ?<b> ?(Cited Literature|Literature Cited|FULL REFERENCES|Research Proposal References) ?<\/b> ?<\/p>/<p class\=\"$1\">REFERENCES<\/p>/gi;
	$_=~s/<p class\=\"([^\"]+)\"> ?<b> ?(Abstract|Introduction|Discussion|Acknowledgments|References|Figure legends?)\.? ?<\/b>\.? ?<\/p>/<p class\=\"$1\">$2<\/p>/gi;
	$_=~s/<w\:(\w+)><\/w\:(\w+)>//g;
	$_=~s/<b>Fig\. (\w+)<\/b>/Fig\. $1/g;
	$_=~s/<p class\=\"\w+\">\s*<\/p>//gi;
	$_=~s/<p\[\d+\] class\=\"\w+\">\s*<\/p\[\d+\]>//gi;
	$_=~s/<p class\=\"normal\"><u><b>(Tables?|Figures?|Legends?)<\/b><\/u><\/p>/<p class\=\"normal\">$1<\/p>/gi;
	$_=~s/<p class\=\"normal\"><b><i>Keywords\: (.*?)<\/i><\/b><\/p>/<p class\=\"normal\">Keywords\: $1<\/p>/gi;
	$_=~s/<p class\=\"normal\"><b><i>References<\/i><\/b><\/p>/<p class\=\"normal\">References<\/p>/gi;
	$_=~s/<p class\=\"normal\"><b><i>((Conflicts of Interest|Ethical standards|Financial support|Acknowledgments) ?\: ?)<\/i><\/b>/<p class\=\"normal\"><b>$1<\/b>/gi;
	
	
	
	$_=~s/<p class\=\"([^\"]+)\">\s*\[\[TABLE ID\=\"table\-(\d+)\"\]\]\s*<\/p>/<divx class\=\"TABLE\" data\-element\=\"table\-wrap\" data\-attribs\-id\=\"table\-$2\">/g;


	$_=~s/<p class\=\"([^\"]+)\">1\.?0? ?Introduction/<p class\=\"$1\">Introduction/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b>1\.?0? ?Introduction/<p class\=\"$1\"><b>Introduction/gi;
	
	$_=~s/<p class\=\"([^\"]+)\"><b>1\.0 Introductions/<p class\=\"$1\"><b>Introductions/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b>Introduction ?\:<\/b>/<p class\=\"$1\"><b>Introduction<\/b>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b>Introductions ?\:<\/b>/<p class\=\"$1\"><b>Introductions<\/b>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><i>Introductions? ?\:?<\/i>/<p class\=\"$1\"><b>Introduction<\/b>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b><i>Introductions? ?\:?<\/i><\/b>/<p class\=\"$1\"><b>Introduction<\/b>/gi;
	$_=~s/<p class\=\"([^\"]+)\"><b>FIGURE (\d+)\:/<p class\=\"$1\"><b>FIGURE $2\: /gi;
	$_=~s/<p class\=\"([^\"]+)\">FIGURE (\d+)\:/<p class\=\"$1\">FIGURE $2\: /gi;

	$_=~s/<p class\=\"([^\"]+)\">\s*\[\[\/TABLE ID\=\"table\-(\d+)\"\]\]\s*<\/p>/<\/divx>/g;
	
	
	if($_=~/<p class\=\"([^\"]+)\">(<[b|i]>)?(\w+)?\.? ?\.?(\&\#x02003\;)?Introductions? ?(<\/[b|i]>)? ?<\/p>(.*?)<p class\=\"([^\"]+)\">(<[b|i]>)?(\w+)?\.? ?\.?(\&\#x02003\;)?Introductions? ?(<\/[b|i]>)? ?<\/p>/si)
	{
		$_=~s/<p (class\=\"([^\"]+)\">(<[b|i]>)?(\w+)?\.? ?\.?(\&\#x02003\;)?Introductions? ?(<\/[b|i]>)? ?<\/p>(.*?)<p class\=\"([^\"]+)\">(<[b|i]>)?(\w+)?\.? ?\.?(\&\#x02003\;)?Introductions? ?(<\/[b|i]>)? ?<\/p>)/<xp $1/si;
		#print ERR "$_";
		#exit;
	}
	
	
	
	if($_=~/(<p class\=\"FMEND\">)/si)
	{
		$_=~s/<div class\=\"body\">(.*?)(<p class\=\"FMEND\">)/<div class\=\"body\">\n<div class\=\"front\">$1<\/div>\n$2/si;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		#$_=~s/<p class\=\"([^\"]+)\">((<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)?)/<p class\=\"$1\">$2<\/p>\n<p class="normal">/gi;
		
		
		$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)? ?<\/p>)/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n$3/si;
		
		
		$_=~s/<div class\=\"bodymatter\">(.*?)<\/div>(.*?)<\/div>\s*<\/body>\s*<\/html>/<div class\=\"bodymatter\">$1<\/div>\n<div class\=\"back\">$2<\/div>\n<\/div>\n<\/body><\/html>/si;
		
		
		if($_!~/<div class\=\"bodymatter\">/si)
		{
			$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)<\/body>/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n<div class\=\"back\"><\/div>\n<\/body>/si;
			
		}


	}		
	elsif($_=~/(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?Learning Objectives ?\:?(<\/b>)? ?)/si)
	{
		$_=~s/<div class\=\"body\">(.*?)(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?Learning Objectives ?\:?(<\/b>)? ?)/<div class\=\"body\">\n<div class\=\"front\">$1<\/div>\n$2/si;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		#$_=~s/<p class\=\"([^\"]+)\">((<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)?)/<p class\=\"$1\">$2<\/p>\n<p class="normal">/gi;
		
		
		$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)? ?<\/p>)/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n$3/si;
		
		
		$_=~s/<div class\=\"bodymatter\">(.*?)<\/div>(.*?)<\/div>\s*<\/body>\s*<\/html>/<div class\=\"bodymatter\">$1<\/div>\n<div class\=\"back\">$2<\/div>\n<\/div>\n<\/body><\/html>/si;
		
		
		if($_!~/<div class\=\"bodymatter\">/si)
		{
			$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)<\/body>/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n<div class\=\"back\"><\/div>\n<\/body>/si;
			
		}


	}		
	elsif($_=~/(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?\.?(\&\#x02003\;)?Introductions? ?(<\/b>)? ?<\/p>)/si)
	{
	
		$_=~s/<div class\=\"body\">(.*?)(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?\.?(\&\#x02003\;)?Introductions? ?(<\/b>)? ?<\/p>)/<div class\=\"body\">\n<div class\=\"front\">$1<\/div>\n$2/si;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		
		
		#$_=~s/<p class\=\"([^\"]+)\">((<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)?)/<p class\=\"$1\">$2<\/p>\n<p class="normal">/gi;
		
		
		$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?|Conflicts? of interests?|Data Availability Statements?|Supporting Information)\:?\.? ?(<\/b>)? ?<\/p>)/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n$3/si;
		
		
		$_=~s/<div class\=\"bodymatter\">(.*?)<\/div>(.*?)<\/div>\s*<\/body>\s*<\/html>/<div class\=\"bodymatter\">$1<\/div>\n<div class\=\"back\">$2<\/div>\n<\/div>\n<\/body><\/html>/si;
		
		
		if($_!~/<div class\=\"bodymatter\">/si)
		{
			$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)<\/body>/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n<div class\=\"back\"><\/div>\n<\/body>/si;
			
		}

		#print ERR "sss$_";
		#exit;

	}
	elsif($_=~/(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?Introduction ?\:?(<\/b>)? ?)/si)
	{
		$_=~s/<div class\=\"body\">(.*?)(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?Introduction ?\:?(<\/b>)? ?)/<div class\=\"body\">\n<div class\=\"front\">$1<\/div>\n$2/si;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		#$_=~s/<p class\=\"([^\"]+)\">((<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)?)/<p class\=\"$1\">$2<\/p>\n<p class="normal">/gi;
		
		
		$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)? ?<\/p>)/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n$3/si;
		
		
		$_=~s/<div class\=\"bodymatter\">(.*?)<\/div>(.*?)<\/div>\s*<\/body>\s*<\/html>/<div class\=\"bodymatter\">$1<\/div>\n<div class\=\"back\">$2<\/div>\n<\/div>\n<\/body><\/html>/si;
		
		
		if($_!~/<div class\=\"bodymatter\">/si)
		{
			$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)<\/body>/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n<div class\=\"back\"><\/div>\n<\/body>/si;
			
		}


	}
	elsif($_=~/(<p class\=\"([^\"]+)\"><(i|b)>LETTER<\/(i|b)>\s*)/si)
	{
		$_=~s/<div class\=\"body\">(.*?)(<p class\=\"([^\"]+)\"><(i|b)>LETTER<\/(i|b)>)/<div class\=\"body\">\n<div class\=\"front\">$1<\/div>\n$2/si;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		#$_=~s/<p class\=\"([^\"]+)\">((<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)?)/<p class\=\"$1\">$2<\/p>\n<p class="normal">/gi;
		
		
		$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)? ?<\/p>)/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n$3/si;
		
		
		$_=~s/<div class\=\"bodymatter\">(.*?)<\/div>(.*?)<\/div>\s*<\/body>\s*<\/html>/<div class\=\"bodymatter\">$1<\/div>\n<div class\=\"back\">$2<\/div>\n<\/div>\n<\/body><\/html>/si;
		
		
		if($_!~/<div class\=\"bodymatter\">/si)
		{
			$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)<\/body>/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n<div class\=\"back\"><\/div>\n<\/body>/si;
			
		}


	}
	elsif($_=~/(<p class\=\"([^\"]+)\"><(i|b)>Brief communication<\/(i|b)>\s*)/si)
	{
		$_=~s/<div class\=\"body\">(.*?)(<p class\=\"([^\"]+)\"><(i|b)>Brief communication<\/(i|b)>)/<div class\=\"body\">\n<div class\=\"front\">$1<\/div>\n$2/si;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		#$_=~s/<p class\=\"([^\"]+)\">((<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)?)/<p class\=\"$1\">$2<\/p>\n<p class="normal">/gi;
		
		
		$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)? ?<\/p>)/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n$3/si;
		
		
		$_=~s/<div class\=\"bodymatter\">(.*?)<\/div>(.*?)<\/div>\s*<\/body>\s*<\/html>/<div class\=\"bodymatter\">$1<\/div>\n<div class\=\"back\">$2<\/div>\n<\/div>\n<\/body><\/html>/si;
		
		
		if($_!~/<div class\=\"bodymatter\">/si)
		{
			$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)<\/body>/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n<div class\=\"back\"><\/div>\n<\/body>/si;
			
		}


	}
	elsif($_=~/(<p class\=\"([^\"]+)\"><i>To the Editor<\/i>)/si)
	{
		$_=~s/<div class\=\"body\">(.*?)(<p class\=\"([^\"]+)\"><i>To the Editor<\/i>)/<div class\=\"body\">\n<div class\=\"front\">$1<\/div>\n$2/si;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		#$_=~s/<p class\=\"([^\"]+)\">((<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)?)/<p class\=\"$1\">$2<\/p>\n<p class="normal">/gi;
		
		
		$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)? ?<\/p>)/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n$3/si;
		
		
		$_=~s/<div class\=\"bodymatter\">(.*?)<\/div>(.*?)<\/div>\s*<\/body>\s*<\/html>/<div class\=\"bodymatter\">$1<\/div>\n<div class\=\"back\">$2<\/div>\n<\/div>\n<\/body><\/html>/si;
		
		
		if($_!~/<div class\=\"bodymatter\">/si)
		{
			$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)<\/body>/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n<div class\=\"back\"><\/div>\n<\/body>/si;
			
		}

		
	}
	elsif($_=~/(<p class\=\"([^\"]+)\">(?:<\w+>)?Keywords\:?(?:<\/\w+>)?( |\w+)(.*?)<\/p>)/i)
	{
		$_=~s/<div class\=\"body\">(.*?<p class\=\"([^\"]+)\">(?:<\w+>)?Keywords\:?(?:<\/\w+>)?( |\w+)(.*?)<\/p>)\s*<p class\=\"([^\"]+)\">/<div class\=\"body\">\n<div class\=\"front\">$1<\/div>\n<p class\=\"$5\">/si;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		



		#$_=~s/<p class\=\"([^\"]+)\">((<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)?)/<p class\=\"$1\">$2<\/p>\n<p class="normal">/gi;
		
		
		$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)? ?<\/p>)/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n$3/si;
		
		
		$_=~s/<div class\=\"bodymatter\">(.*?)<\/div>(.*?)<\/div>\s*<\/body>\s*<\/html>/<div class\=\"bodymatter\">$1<\/div>\n<div class\=\"back\">$2<\/div>\n<\/div>\n<\/body><\/html>/si;
		
		
		if($_!~/<div class\=\"bodymatter\">/si)
		{
			$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)<\/body>/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n<div class\=\"back\"><\/div>\n<\/body>/si;
			
		}
		#exit;
		
	}
	elsif($_=~/(<p class\=\"([^\"]+)\">(?:<\w+>)?Dear Editor\:?\,?(?:<\/\w+>)?(.*?)<\/p>)/i)
	{
		$_=~s/<div class\=\"body\">(.*?)(<p class\=\"([^\"]+)\">(?:<\w+>)?Dear Editor\:?\,?(?:<\/\w+>)?(.*?)<\/p>)/<div class\=\"body\">\n<div class\=\"front\">$1<\/div>\n$2/si;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		$_=~s/<p class\=\"normal\"><b>Acknowledge?ments?\:?<\/b>\:?\.? /<p class\=\"normal\"><b>Acknowledgements<\/b><\/p>\n<p class="normal">/gi;
		



		#$_=~s/<p class\=\"([^\"]+)\">((<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)?)/<p class\=\"$1\">$2<\/p>\n<p class="normal">/gi;
		
		
		$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)(<p class\=\"([^\"]+)\">(<b>)?(\w+)?\.? ?(Acknowledge?ments?|acknowledgments?|References?|References? and Notes?)\:?\.? ?(<\/b>)? ?<\/p>)/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n$3/si;
		
		
		$_=~s/<div class\=\"bodymatter\">(.*?)<\/div>(.*?)<\/div>\s*<\/body>\s*<\/html>/<div class\=\"bodymatter\">$1<\/div>\n<div class\=\"back\">$2<\/div>\n<\/div>\n<\/body><\/html>/si;
		
		
		if($_!~/<div class\=\"bodymatter\">/si)
		{
			$_=~s/<div class\=\"front\">(.*?)<\/div>(.*?)<\/body>/<div class\=\"front\">$1<\/div>\n<div class\=\"bodymatter\">$2<\/div>\n<div class\=\"back\"><\/div>\n<\/body>/si;
			
		}
		#exit;
		
	}
	else
	{
		print "Unable to identify Body start, Apply Body start tag";
		exit;
	}

	$_=~s/<(strong|sup|sub|sc|monospace|b|i)>/<$1 class\=\"dummy\">/g;
	$_=~s/<xp class/<p class/gi;
	$_=~s/DUMMYINTEGRAduction/Introduction/gi;
	

}

